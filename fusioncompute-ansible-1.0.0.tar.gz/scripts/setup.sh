#!/bin/bash

# Get the absolute path of the current script
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
PLUGINS_DIR="$SCRIPT_DIR/../plugins"  # plugins is in the parent directory
ROLES_DIR="$SCRIPT_DIR/../roles"  # roles is in the parent directory
CONFIG_FILE="$SCRIPT_DIR/../config.ini"  # config.ini file in the parent directory
DEST_DIR="/etc/ansible/fusioncompute"  # Destination directory for config.ini
DEST_ROLE_DIR="$SCRIPT_DIR/../../../../../roles"
# Ensure the plugins directory exists
if [ ! -d "$PLUGINS_DIR" ]; then
    echo "Error: '$PLUGINS_DIR' directory does not exist."
    exit 1
fi

# Ensure the destination directory exists, create if not
if [ ! -d "$DEST_DIR" ]; then
    echo "Directory '$DEST_DIR' does not exist. Creating it now..."
    sudo mkdir -p "$DEST_DIR"
    if [ $? -ne 0 ]; then
        echo "Error: Failed to create directory '$DEST_DIR'."
        exit 1
    fi
    # Set permissions for the newly created directory
    sudo chmod 750 "$DEST_DIR"
    if [ $? -ne 0 ]; then
        echo "Error: Failed to set permissions for '$DEST_DIR'."
        exit 1
    fi
    echo "Directory '$DEST_DIR' created successfully and permissions set to 750."
fi

# Check if config.ini exists in the parent directory and copy to /etc/ansible/fusioncompute/
if [ ! -f "$CONFIG_FILE" ]; then
    echo "Error: 'config.ini' file does not exist in the parent directory."
    exit 1
else
    # Check if config.ini already exists in the destination directory
    if [ -f "$DEST_DIR/config.ini" ]; then
        echo "Warning: 'config.ini' already exists in '$DEST_DIR'. No action taken."
    else
        echo "Copying 'config.ini' to '$DEST_DIR'..."
        sudo cp "$CONFIG_FILE" "$DEST_DIR/"
        if [ $? -eq 0 ]; then
            echo "'config.ini' has been successfully copied to '$DEST_DIR'."
        else
            echo "Error: Failed to copy 'config.ini' to '$DEST_DIR'."
            exit 1
        fi
        sudo chmod 640 "$DEST_DIR/config.ini"
        if [ $? -ne 0 ]; then
        echo "Error: Failed to set permissions for '$DEST_DIR/config.ini'."
        exit 1
        fi
        echo "File '$DEST_DIR/config.ini' created successfully and permissions set to 640."
    fi
fi

# Ensure we are working with valid directories and files
if ! cd "$SCRIPT_DIR/.."; then
    echo "Error: Unable to access parent directory."
    exit 1
fi

# Set the permissions of Python files in the plugins directory to 550
find "$PLUGINS_DIR" -type f -name "*.py" -exec chmod 550 {} \;

# Set the permissions of directories in the plugins directory and its subdirectories to 550
find "$PLUGINS_DIR" -type d -exec chmod 550 {} \;

# Set the permissions of all other files and directories outside of plugins (same level directories and files) to 440
# Ensure only files and directories outside of the 'plugins' directory are changed
find "$SCRIPT_DIR/.." -mindepth 1 -type d ! -path "$PLUGINS_DIR" ! -path "$PLUGINS_DIR/*" -exec chmod 440 {} \;
find "$SCRIPT_DIR/.." -mindepth 1 -type f ! -path "$PLUGINS_DIR" ! -path "$PLUGINS_DIR/*" -exec chmod 440 {} \;

echo "Permissions have been successfully updated."

echo "Copy roles from $ROLES_DIR to $DEST_ROLE_DIR"
sudo cp -rf "$ROLES_DIR" "$DEST_ROLE_DIR" 
