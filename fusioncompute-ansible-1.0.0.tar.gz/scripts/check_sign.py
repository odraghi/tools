#!/usr/bin/env python
# -*- coding:utf-8 -*-
#  Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.
import json
import hashlib
import os

# Get the parent directory of the current script
script_dir = os.path.dirname(os.path.abspath(__file__))
parent_dir = os.path.dirname(script_dir)

# Path to the MANIFEST.json file
manifest_path = os.path.join(parent_dir, "MANIFEST.json")


def calculate_sha256(file_path):
    """Calculate the SHA256 checksum of a file."""
    hasher = hashlib.sha256()
    with open(file_path, "rb") as f:
        while True:
            chunk = f.read(8192)
            if not chunk:
                break
            hasher.update(chunk)
    return hasher.hexdigest()


# Supported checksum types
SUPPORTED_TYPES = {
    'sha256': calculate_sha256,
}


def verify_manifest():
    """Verify the integrity of MANIFEST.json."""
    try:
        # Load the MANIFEST.json file
        with open(manifest_path, "r", encoding="utf-8") as f:
            manifest_data = json.load(f)

        # Extract file information from the manifest
        file_entry = manifest_data.get("file_manifest_file", {})
        files_json_name = file_entry.get("name")
        expected_checksum = file_entry.get("chksum_sha256")
        checksum_type = file_entry.get('chksum_type')

        # Check for missing fields in MANIFEST.json
        if not files_json_name or not expected_checksum or not checksum_type:
            print("[ERROR] MANIFEST.json is missing necessary fields")
            return None

        files_json_path = os.path.join(parent_dir, files_json_name)

        # Ensure the checksum type is supported
        if checksum_type not in SUPPORTED_TYPES:
            print(
                f'[ERROR] MANIFEST.json checksum type not supported. Supported types: \
                {SUPPORTED_TYPES}, found: {checksum_type}')
            return None

        # Calculate the actual checksum of the FILES.json file
        if not os.path.exists(files_json_path):
            print(f"[ERROR] FILES.json file does not exist: {files_json_path}")
            return None

        checksum_fn = SUPPORTED_TYPES[checksum_type]
        actual_checksum = checksum_fn(files_json_path)

        # Compare the expected and actual checksum
        if actual_checksum != expected_checksum:
            print(
                f"[ERROR] MANIFEST.json checksum mismatch! Expected: {expected_checksum}, Actual: {actual_checksum}")
            return None

        print("[SUCCESS] MANIFEST.json integrity check passed")
        return files_json_path

    except Exception as e:
        print(f"[ERROR] Failed to read MANIFEST.json: {e}")
        return None


def verify_files(files_json_path):
    """Verify the integrity of each file listed in FILES.json."""
    try:
        # Load the FILES.json file
        with open(files_json_path, "r", encoding="utf-8") as f:
            files_data = json.load(f)

        file_list = files_data.get("files", [])
        fail_cnt = 0

        for file_entry in file_list:
            file_name = file_entry.get("name")
            file_type = file_entry.get("ftype")
            checksum_type = file_entry.get('chksum_type')
            expected_checksum = file_entry.get("chksum_sha256")

            # Skip directory type entries
            if file_type == "dir":
                continue

            file_path = os.path.join(parent_dir, file_name)

            # Check if the file exists
            if not os.path.exists(file_path):
                print(f"[ERROR] File missing: {file_name}")
                continue

            # Ensure the checksum type is supported
            if checksum_type not in SUPPORTED_TYPES:
                print(
                    f"[ERROR] File: {file_path} checksum type not supported. Supported types: \
                        {SUPPORTED_TYPES}, found: {checksum_type}")
                continue

            # Calculate checksum and compare
            checksum_fn = SUPPORTED_TYPES[checksum_type]
            actual_checksum = checksum_fn(file_path)

            if actual_checksum != expected_checksum:
                print(
                    f"[ERROR] File integrity check failed: {file_name} (Expected: {expected_checksum}, \
                        Actual: {actual_checksum})")
                fail_cnt += 1

        # If all files passed the integrity check
        if fail_cnt == 0:
            print('[SUCCESS] File integrity check all passed')

    except Exception as e:
        print(f"[ERROR] Failed to read FILES.json: {e}")


if __name__ == "__main__":
    # Start the verification process
    files_json_path = verify_manifest()
    if files_json_path:
        verify_files(files_json_path)
