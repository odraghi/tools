# fc_login Role

## Description
This role is responsible for authenticating to the FusionCompute system by obtaining an authentication token. After obtaining the token, it sets the `fc_token` and `fc_site_id` as global variables (facts) for use in other parts of the playbook.

## Requirements
- Ansible 2.15 or higher
- Access to a FusionCompute environment
- `huawei.fusioncompute.fc_token_manager` module

## Role Variables
This role doesn't require any input variables directly, but it will output the following facts:
- `fc_token`: The authentication token obtained from FusionCompute.
- `fc_site_id`: The site ID associated with the current session.

## Example Playbook

```yaml
- name: Example playbook using the fc_login role
  hosts: localhost
  environment:
    FUSIONCOMPUTE_HOST: '{{ fc_hostname }}'
    FUSIONCOMPUTE_USERNAME: '{{ fc_username }}'
    FUSIONCOMPUTE_PASSWORD: '{{ fc_password }}'
    FUSIONCOMPUTE_VERIFY: '{{ fc_verify }}'
  roles:
    - fc_login  # The role will set fc_token and fc_site_id
