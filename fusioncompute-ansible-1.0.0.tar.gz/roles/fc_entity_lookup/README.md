# fc\_entity\_lookup Role

## Description

This role is responsible for parsing and resolving a list of FusionCompute entities into their corresponding unique IDs.

Each entity must be passed as a string in the format `type:name`, where `type` is the resource type and `name` is the display name .


## Requirements

* Ansible 2.15 or higher
* Access to a Huawei FusionCompute environment
* `huawei.fusioncompute.fc_generic` module

## Role Variables

### Input

* `fc_entities` (required):
  A list of entity strings in the format `type:name`.
  Supported types: `datastore`, `host`, `cluster`, `dvs`, `portgroup`, `vm`.

* `fc_full_urn` (optional, default: true):
  If true, return the full URN string (e.g. `urn:sites:xxxxxx:vms:i-xxxxxxx`).
    If false or omitted, only the ID part of the URN is returned (e.g. `i-xxxxxxxx`).


  Example:

  ```yaml
  fc_entities:
    - cluster:DefaultCluster
    - datastore:local-2
    - portgroup:pg-test
  ```

### Output

* `fc_query_result`:
  A list of dictionaries, each containing:

  * `entity`: A list in the format `[type, name]`
  * `id`: The resolved FusionCompute object ID

  Example output:

  ```yaml
  fc_query_result:
    - entity: ["datastore", "local-2"]
      ids: ["3"]
    - entity: ["cluster", "DefaultCluster"]
      ids: ["1234"]
  ```

## Example Playbook

```yaml
- name: Use fc_entity_lookup role
  hosts: localhost
  roles:
    - role: fc_entity_lookup
      vars:
        fc_entities:
          - cluster:DefaultCluster
          - datastore:local-2
          - portgroup:pg-test

  tasks:
    - name: Output resolved entity IDs
      debug:
        var: fc_query_result
```