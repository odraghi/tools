# fc\_task\_wait Role

## Description

This role waits for a FusionCompute asynchronous task to complete by polling its status.
It extracts the task ID from the provided task output and uses the `huawei.fusioncompute.fc_task_manager` module to monitor task completion.
It sets facts about the task ID, task status, and task response data for use in downstream tasks.
The role can optionally fail the playbook if the task fails unless `fc_allow_fail` is set to true.

## Requirements

* Ansible 2.15 or higher
* Access to a FusionCompute environment
* `huawei.fusioncompute.fc_task_manager` module

## Role Variables

### Inputs

* `fc_output` (dict, required):
  The output dictionary from a prior FusionCompute API call that contains the task URN.
* `fc_wait_timeout` (int, optional, default: 60):
  Maximum time in seconds to wait for the task to complete.
* `fc_pull_interval` (int, optional, default: 5):
  Interval in seconds between polling attempts.
* `fc_allow_fail` (bool, optional, default: false):
  Whether to allow the task failure without failing the playbook.

### Outputs (set as facts)

* `fc_task_id` (int):
  Extracted FusionCompute task ID being monitored.
* `fc_task_status` (string):
  Task completion status, either `"success"` or `"failed"`.
* `fc_task_data` (dict):
  Response data from the completed task, or empty dict if failed or no data.

## Example Playbook

```yaml
- name: Wait for FusionCompute task to complete
  hosts: localhost
  roles:
    - role: fc_task_wait
      vars:
        fc_output: "{{ previous_fc_api_call_output }}"
        fc_wait_timeout: 120
        fc_pull_interval: 10
        fc_allow_fail: false
```
