# `fc_install_tools` Role

## Description

This role automates the installation of `fctools` on a standard virtual machine managed by Huawei FusionCompute. It performs the following operations:

1. Mounts the built-in `fctools` ISO to the specified VM via FusionCompute API.
2. Waits for the asynchronous mount task to complete using the `fc_task_wait` role.
3. Waits for the VM to become reachable via ping and SSH.
4. Uploads and executes a predefined `install_fctools.sh` script on the VM using SSH.
5. Verifies that the `fctools` (PV driver) status becomes `running`.
6. Unmounts the `fctools` ISO after installation is complete.

This role is intended for use with regular Linux virtual machines, to prepare the VM with the necessary FusionCompute drivers.

## Requirements

* FusionCompute environment
* FusionCompute Ansible collection installed (`huawei.fusioncompute`)
* The `install_fctools.sh` script must exist in the `files/` directory of this role
* SSH access from the controller to the VM

## Role Variables

| Variable Name            | Description                                                       | Required | Example             |
| ------------------------ | ----------------------------------------------------------------- | -------- | ------------------- |
| `fc_vm_id`               | ID of the VM on which to install `fctools`                        | Yes      | `503`               |
| `fc_vm_ip`               | IP address of the VM                                              | Yes      | `192.168.1.10`      |
| `fc_vm_username`         | SSH username to log into the VM                                   | Yes      | `root`              |
| `fc_vm_private_key_file` | Path to the private key file used for SSH login                   | Yes      | `/root/.ssh/id_rsa` |
| `fc_timeout`             | Timeout in seconds for VM to become reachable and `fctools` ready | Yes      | `300`               |
| `fc_ping_interval`       | Interval between ping retries in seconds                          | Yes      | `5`                 |

## Output

This role does not return new facts. It ensures `fctools` is installed and running on the target VM.

## Example Playbook

```yaml
- name: Install fctools on a newly cloned VM
  hosts: localhost
  roles:
    - role: fc_install_tools
      vars:
        fc_vm_id: i-xxxxxxxx
        fc_vm_ip: x.x.x.x
        fc_vm_username: demo
        fc_vm_private_key_file: /root/.ssh/id_rsa
        fc_timeout: 300
        fc_ping_interval: 5
```

## Notes

* This role depends on `fc_task_wait` to monitor FusionCompute asynchronous task completion.
* The installation script is executed remotely via SSH; if SSH is not available, the process will fail.
* The ISO is mounted automatically via the FusionCompute API and unmounted after use.

