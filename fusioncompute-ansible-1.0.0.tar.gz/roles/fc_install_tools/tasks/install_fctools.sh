#!/bin/bash
set -e

umask 077
trap '
  [ -n "$tmp_dir" ] && rm -rf "$tmp_dir"
  [ -n "$install_dir" ] && rm -rf "$install_dir"
' EXIT
tmp_dir=$(mktemp -d)
install_dir=$(mktemp -d)

sudo mount /dev/sr0 "$tmp_dir"
sudo cp "$tmp_dir"/vmtools-*.tar.gz "$install_dir"
sudo umount "$tmp_dir"

sudo tar -xzvf "$install_dir"/vmtools-*.tar.gz -C "$install_dir" > /dev/null 2>&1
sudo "$install_dir"/vmtools/install > /dev/null 2>&1

res=$(systemctl is-active vm-agent)

if [ "$res" = "active" ]; then
    exit 0
else
    exit 1
fi