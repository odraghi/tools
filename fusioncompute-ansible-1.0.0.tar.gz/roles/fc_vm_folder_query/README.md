# fc\_vm\_folder\_query Role

## Description

This role is responsible for locating a folder in the FusionCompute environment based on a specified folder path. It starts from the site root and recursively traverses the folder hierarchy. Upon success, it outputs the URN (Uniform Resource Name) of the specified folder as a fact.

## Requirements

* Ansible 2.15 or higher
* Access to a FusionCompute environment
* `huawei.fusioncompute.fc_folder_manager` module
* `fc_site_id` must be set prior to calling this role (typically set by `fc_login`)

## Role Variables

### Input Variables

* `vm_folder_path`:
  The hierarchical path of the folder to query, e.g., `/test/sub-folder`.

### Output Facts

* `vm_folder_urn`:
  The URN of the queried folder. If the folder path does not exist, this will be an empty string.

## Example Playbook

```yaml
- name: Query a VM folder URN
  hosts: localhost
  vars:
    vm_folder_path: "/test/sub-folder"
  roles:
    - fc_vm_folder_query
  environment:
    FUSIONCOMPUTE_HOST: '{{ fc_hostname }}'
    FUSIONCOMPUTE_USERNAME: '{{ fc_username }}'
    FUSIONCOMPUTE_PASSWORD: '{{ fc_password }}'
    FUSIONCOMPUTE_VERIFY: '{{ fc_verify }}'
```

This role is typically used when you need to retrieve the URN of an existing folder to use it in subsequent VM or template-related operations.
