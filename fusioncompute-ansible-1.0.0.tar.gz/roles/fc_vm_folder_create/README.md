# fc\_vm\_folder\_create Role

## Description

This role creates a nested VM folder path in Huawei FusionCompute by recursively creating each folder level under the site root.
It sets the resulting folder URN as a fact for use in subsequent tasks (e.g., VM provisioning or template creation).

## Requirements

* Ansible 2.15 or higher
* Access to a FusionCompute environment
* `huawei.fusioncompute.fc_folder_manager` module
* The `fc_site_id` fact must be available (typically from the `fc_login` role)

## Role Variables

### Inputs

* `vm_folder_path` (string, required):
  The full VM folder path to create. Supports nested paths like `/ocp-test/sub-1`.

### Prerequisites

* `fc_site_id` (string, required):
  Must be set before running this role. This is typically set by the `fc_login` role.

### Outputs (set as facts)

* `vm_folder_urn` (string):
  The URN of the final folder created or located.

## Example Playbook

```yaml
- name: Create VM folder structure
  hosts: localhost
  roles:
    - role: fc_login
    - role: fc_vm_folder_create
      vars:
        vm_folder_path: "/test/sub-1"
```

In the example above, the folder structure `/test/sub-1` will be created in the environment, and `vm_folder_urn` will contain the URN of the leaf folder `sub-1`.
