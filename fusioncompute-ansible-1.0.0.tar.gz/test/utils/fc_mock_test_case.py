#!/usr/bin/env python
# -*- coding:utf-8 -*-
#  Copyright (c) Huawei Technologies Co., Ltd. 2024-2024. All rights reserved.
from http import HTTPStatus
import unittest
from unittest.mock import patch
from ansible.module_utils.basic import AnsibleModule
from ansible_collections.huawei.fusioncompute.plugins.module_utils.core.fusincompute \
    import DefaultFcHttpClient, FcHttpBase
from ansible_collections.huawei.fusioncompute.test.utils.basic import exit_json, fail_json, get_bin_path


class FcTestCase(unittest.TestCase):
    def setUp(self):
        patchers = []
        patcher = patch.multiple(AnsibleModule,
                                 exit_json=exit_json,
                                 fail_json=fail_json,
                                 get_bin_path=get_bin_path)
        self.mock_module_helper = patcher.start()
        patchers.append(patcher)
        patcher = patch.object(FcHttpBase, 'site_id',
                               new_callable=lambda: 'ffffff')
        self.mock_site_id = patcher.start()
        patchers.append(patcher)
        patcher = patch.object(
            FcHttpBase, 'update_auth_token', return_value=HTTPStatus.OK)
        self.mock_update_auth_token = patcher.start()
        patchers.append(patcher)
        patcher = patch.object(DefaultFcHttpClient, 'post',
                               return_value=(HTTPStatus.OK, {}))
        self.mock_post = patcher.start()
        patchers.append(patcher)
        patcher = patch.object(DefaultFcHttpClient, 'put',
                               return_value=(HTTPStatus.OK, {}))
        self.mock_put = patcher.start()
        patchers.append(patcher)
        patcher = patch.object(DefaultFcHttpClient, 'get',
                               return_value=(HTTPStatus.OK, {}))
        self.mock_get = patcher.start()
        patchers.append(patcher)
        patcher = patch.object(DefaultFcHttpClient,
                               'delete', return_value=(HTTPStatus.OK, {}))
        self.mock_delete = patcher.start()
        patchers.append(patcher)
        for patcher in patchers:
            self.addCleanup(patcher.stop)
