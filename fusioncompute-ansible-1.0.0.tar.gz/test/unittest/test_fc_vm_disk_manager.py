from unittest.mock import call
from ansible_collections.huawei.fusioncompute.test.utils.basic import AnsibleExitJson, AnsibleFailJson, set_module_args
from ansible_collections.huawei.fusioncompute.test.utils.fc_mock_test_case import FcTestCase
from ansible_collections.huawei.fusioncompute.plugins.module_utils.env_fallback import AnsibleFallbackNotFound
from ansible_collections.huawei.fusioncompute.plugins.modules import fc_vm_disk_manager


class TestFcVmDiskManager(FcTestCase):

    def test_module_fail_when_required_args_missing(self):
        with self.assertRaises(AnsibleFallbackNotFound):
            set_module_args({})
            fc_vm_disk_manager.main()

    def test_success_with_volume_create_and_attach(self):
        set_module_args({
            'fc_hostname': '127.0.0.1',
            'fc_username': 'test',
            'vm_id': 'i-xxxxxxxx',
            'action': 'create_attach',
            'name': 'vol-1',
        })
        with self.assertRaises(AnsibleExitJson) as result:
            fc_vm_disk_manager.main()
        # ensure result is changed
        self.mock_post.assert_called_once_with(
            'https://127.0.0.1:7443/service/sites/ffffff/vms/i-xxxxxxxx/action/createattachvol',
            {'name': 'vol-1'}
        )
        self.assertTrue(result.exception.args[0]['changed'])

    def test_success_with_volume_attach(self):
        set_module_args({
            'fc_hostname': '127.0.0.1',
            'fc_username': 'test',
            'vm_id': 'i-xxxxxxxx',
            'action': 'attach',
            'volUrn': 'vol-1',
        })
        with self.assertRaises(AnsibleExitJson) as result:
            fc_vm_disk_manager.main()
        # ensure result is changed
        self.mock_post.assert_called_once_with(
            'https://127.0.0.1:7443/service/sites/ffffff/vms/i-xxxxxxxx/action/attachvol',
            {'volUrn': 'vol-1'}
        )
        self.assertTrue(result.exception.args[0]['changed'])

    def test_success_with_volume_detach(self):
        set_module_args({
            'fc_hostname': '127.0.0.1',
            'fc_username': 'test',
            'vm_id': 'i-xxxxxxxx',
            'action': 'detach',
            'volUrn': 'vol-1',
        })
        with self.assertRaises(AnsibleExitJson) as result:
            fc_vm_disk_manager.main()
        # ensure result is changed
        self.mock_post.assert_called_once_with(
            'https://127.0.0.1:7443/service/sites/ffffff/vms/i-xxxxxxxx/action/detachvol',
            {'volUrn': 'vol-1'}
        )
        self.assertTrue(result.exception.args[0]['changed'])
