from unittest.mock import call
from ansible_collections.huawei.fusioncompute.test.utils.basic import AnsibleExitJson, AnsibleFailJson, set_module_args
from ansible_collections.huawei.fusioncompute.test.utils.fc_mock_test_case import FcTestCase
from ansible_collections.huawei.fusioncompute.plugins.module_utils.env_fallback import AnsibleFallbackNotFound
from ansible_collections.huawei.fusioncompute.plugins.modules import fc_vm_nic_manager


class TestFcVmNicManager(FcTestCase):

    def test_module_fail_when_required_args_missing(self):
        with self.assertRaises(AnsibleFallbackNotFound):
            set_module_args({})
            fc_vm_nic_manager.main()

    def test_success_with_query(self):
        set_module_args({
            'fc_hostname': '127.0.0.1',
            'fc_username': 'test',
            'vm_id': 'i-12345678',
            'action': 'query',
            'nic_id': 234,
        })
        with self.assertRaises(AnsibleExitJson) as result:
            fc_vm_nic_manager.main()
        # ensure result is changed
        self.mock_get.assert_called_once_with(
            'https://127.0.0.1:7443/service/sites/ffffff/vms/i-12345678/nics/234/network-info'
        )
        self.assertFalse(result.exception.args[0]['changed'])

    def test_success_with_create(self):
        set_module_args({
            'fc_hostname': '127.0.0.1',
            'fc_username': 'test',
            'vm_id': 'i-12345678',
            'action': 'create',
            'name': 'demo',
        })
        with self.assertRaises(AnsibleExitJson) as result:
            fc_vm_nic_manager.main()
        # ensure result is changed
        self.mock_post.assert_called_once_with(
            'https://127.0.0.1:7443/service/sites/ffffff/vms/i-12345678/virtualNics',
            {'name': 'demo'}
        )
        self.assertTrue(result.exception.args[0]['changed'])

    def test_success_with_delete(self):
        set_module_args({
            'fc_hostname': '127.0.0.1',
            'fc_username': 'test',
            'vm_id': 'i-12345678',
            'action': 'delete',
            'nic_id': 234,
        })
        with self.assertRaises(AnsibleExitJson) as result:
            fc_vm_nic_manager.main()
        # ensure result is changed
        self.mock_delete.assert_called_once_with(
            'https://127.0.0.1:7443/service/sites/ffffff/vms/i-12345678/virtualNics/234'
        )
        self.assertTrue(result.exception.args[0]['changed'])

    def test_success_with_modify(self):
        set_module_args({
            'fc_hostname': '127.0.0.1',
            'fc_username': 'test',
            'vm_id': 'i-12345678',
            'action': 'modify',
            'nic_id': 234,
            'name': 'nic-1',
        })
        with self.assertRaises(AnsibleExitJson) as result:
            fc_vm_nic_manager.main()
        # ensure result is changed
        self.mock_put.assert_called_once_with(
            'https://127.0.0.1:7443/service/sites/ffffff/vms/i-12345678/nics/234',
            {'name': 'nic-1'}
        )
        self.assertTrue(result.exception.args[0]['changed'])

    def test_success_with_config(self):
        set_module_args({
            'fc_hostname': '127.0.0.1',
            'fc_username': 'test',
            'vm_id': 'i-12345678',
            'action': 'config',
            'nic_id': 234,
            'nicSpecification': {
                'ip': '1.2.3.4',
            },
        })
        with self.assertRaises(AnsibleExitJson) as result:
            fc_vm_nic_manager.main()
        # ensure result is changed
        self.mock_put.assert_called_once_with(
            'https://127.0.0.1:7443/service/sites/ffffff/vms/i-12345678/nics/234/network-info',
            {'nicSpecification': {'ip': '1.2.3.4'}}
        )
        self.assertTrue(result.exception.args[0]['changed'])

    def test_success_with_config_sg(self):
        set_module_args({
            'fc_hostname': '127.0.0.1',
            'fc_username': 'test',
            'vm_id': 'i-12345678',
            'action': 'config_sg',
            'nic_id': 234,
            'enableSecurityGroup': True,
            'securityGroupId': 1,
        })
        with self.assertRaises(AnsibleExitJson) as result:
            fc_vm_nic_manager.main()
        # ensure result is changed
        self.mock_put.assert_called_once_with(
            'https://127.0.0.1:7443/service/sites/ffffff/vms/i-12345678/nics/234/securitygroup',
            {'enableSecurityGroup': True, 'securityGroupId': 1}
        )
        self.assertTrue(result.exception.args[0]['changed'])
