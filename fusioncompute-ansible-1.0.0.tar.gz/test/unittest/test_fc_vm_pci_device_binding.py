from unittest.mock import call
from ansible_collections.huawei.fusioncompute.test.utils.basic import AnsibleExitJson, AnsibleFailJson, set_module_args
from ansible_collections.huawei.fusioncompute.test.utils.fc_mock_test_case import FcTestCase
from ansible_collections.huawei.fusioncompute.plugins.module_utils.env_fallback import AnsibleFallbackNotFound
from ansible_collections.huawei.fusioncompute.plugins.modules import fc_vm_pci_device_binding


class TestFcVmPciDeviceBinding(FcTestCase):

    def test_module_fail_when_required_args_missing(self):
        with self.assertRaises(AnsibleFallbackNotFound):
            set_module_args({})
            fc_vm_pci_device_binding.main()

    def test_success_with_pci_device_binding(self):
        set_module_args({
            'fc_hostname': '127.0.0.1',
            'fc_username': 'test',
            'action': 'bind',
            'vm_id': 'i-12345678',
            'pciUrn': 'xxxx',
        })
        with self.assertRaises(AnsibleExitJson) as result:
            fc_vm_pci_device_binding.main()
        # ensure result is changed
        self.mock_post.assert_called_once_with(
            'https://127.0.0.1:7443/service/sites/ffffff/vms/i-12345678/pcis',
            {'pciUrn': 'xxxx'}
        )
        self.assertTrue(result.exception.args[0]['changed'])

    def test_success_with_pci_device_unbinding(self):
        set_module_args({
            'fc_hostname': '127.0.0.1',
            'fc_username': 'test',
            'action': 'unbind',
            'vm_id': 'i-12345678',
            'pci_id': '234',
        })
        with self.assertRaises(AnsibleExitJson) as result:
            fc_vm_pci_device_binding.main()
        # ensure result is changed
        self.mock_delete.assert_called_once_with(
            'https://127.0.0.1:7443/service/sites/ffffff/vms/i-12345678/pcis/234')
        self.assertTrue(result.exception.args[0]['changed'])
