from unittest.mock import call
from ansible_collections.huawei.fusioncompute.test.utils.basic import AnsibleExitJson, AnsibleFailJson, set_module_args
from ansible_collections.huawei.fusioncompute.test.utils.fc_mock_test_case import FcTestCase
from ansible_collections.huawei.fusioncompute.plugins.module_utils.env_fallback import AnsibleFallbackNotFound
from ansible_collections.huawei.fusioncompute.plugins.modules import fc_vm_cdrom_manager


class TestFcVmCdromManager(FcTestCase):

    def test_module_fail_when_required_args_missing(self):
        with self.assertRaises(AnsibleFallbackNotFound):
            set_module_args({})
            fc_vm_cdrom_manager.main()

    def test_success_with_mount(self):
        set_module_args({
            'fc_hostname': '127.0.0.1',
            'fc_username': 'test',
            'action': 'mount',
            "vm_id": "i-xxxxxxxx",
            "devicePath": "1.2.3.4:/demo/path-to-vm.ovf",
            'protocol': 'nfs',
        })
        with self.assertRaises(AnsibleExitJson) as result:
            fc_vm_cdrom_manager.main()
        # ensure result is changed
        self.mock_post.assert_called_once_with(
            'https://127.0.0.1:7443/service/sites/ffffff/vms/i-xxxxxxxx/action/attachCdrom',
            {'devicePath': '1.2.3.4:/demo/path-to-vm.ovf', 'protocol': 'nfs'}
        )
        self.assertTrue(result.exception.args[0]['changed'])

    def test_success_with_unmount(self):
        set_module_args({
            'fc_hostname': '127.0.0.1',
            'fc_username': 'test',
            'action': 'unmount',
            "vm_id": "i-xxxxxxxx",
        })
        with self.assertRaises(AnsibleExitJson) as result:
            fc_vm_cdrom_manager.main()
        # ensure result is changed
        self.mock_post.assert_called_once_with(
            'https://127.0.0.1:7443/service/sites/ffffff/vms/i-xxxxxxxx/action/detachCdrom', data={}
        )
        self.assertTrue(result.exception.args[0]['changed'])
