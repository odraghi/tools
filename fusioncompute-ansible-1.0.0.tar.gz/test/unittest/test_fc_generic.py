from unittest.mock import call
from ansible_collections.huawei.fusioncompute.test.utils.basic import AnsibleExitJson, AnsibleFailJson, set_module_args
from ansible_collections.huawei.fusioncompute.test.utils.fc_mock_test_case import FcTestCase
from ansible_collections.huawei.fusioncompute.plugins.module_utils.env_fallback import AnsibleFallbackNotFound
from ansible_collections.huawei.fusioncompute.plugins.modules import fc_generic


class TestFcGeneric(FcTestCase):

    def test_module_fail_when_required_args_missing(self):
        with self.assertRaises(AnsibleFallbackNotFound):
            set_module_args({})
            fc_generic.main()

    def test_success_with_get(self):
        set_module_args({
            'fc_hostname': '127.0.0.1',
            'fc_username': 'test',
            'fc_method': 'get',
            'fc_url': '/vms/i-xxxxxxxx',
        })
        with self.assertRaises(AnsibleExitJson) as result:
            fc_generic.main()
        # ensure result is changed
        self.mock_get.assert_called_once_with(
            'https://127.0.0.1:7443/service/sites/ffffff/vms/i-xxxxxxxx',
            params=None
        )
        self.assertFalse(result.exception.args[0]['changed'])

    def test_success_with_post(self):
        set_module_args({
            'fc_hostname': '127.0.0.1',
            'fc_username': 'test',
            'fc_method': 'post',
            'fc_url': '/vms',
            'fc_body': {
                'name': 'demo-1',
            }
        })
        with self.assertRaises(AnsibleExitJson) as result:
            fc_generic.main()
        # ensure result is changed
        self.mock_post.assert_called_once_with(
            'https://127.0.0.1:7443/service/sites/ffffff/vms',
            {'name': 'demo-1'}
        )
        self.assertTrue(result.exception.args[0]['changed'])

    def test_success_with_put(self):
        set_module_args({
            'fc_hostname': '127.0.0.1',
            'fc_username': 'test',
            'fc_method': 'put',
            'fc_url': '/vms',
            'fc_body': {
                'name': 'demo-1',
            }
        })
        with self.assertRaises(AnsibleExitJson) as result:
            fc_generic.main()
        # ensure result is changed
        self.mock_put.assert_called_once_with(
            'https://127.0.0.1:7443/service/sites/ffffff/vms',
            {'name': 'demo-1'}
        )
        self.assertTrue(result.exception.args[0]['changed'])

    def test_success_with_delete(self):
        set_module_args({
            'fc_hostname': '127.0.0.1',
            'fc_username': 'test',
            'fc_method': 'delete',
            'fc_url': '/vms',
        })
        with self.assertRaises(AnsibleExitJson) as result:
            fc_generic.main()
        # ensure result is changed
        self.mock_delete.assert_called_once_with(
            'https://127.0.0.1:7443/service/sites/ffffff/vms',
            params=None
        )
        self.assertTrue(result.exception.args[0]['changed'])
