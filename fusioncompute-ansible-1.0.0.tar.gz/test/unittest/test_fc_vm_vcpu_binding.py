from unittest.mock import call
from ansible_collections.huawei.fusioncompute.test.utils.basic import AnsibleExitJson, AnsibleFailJson, set_module_args
from ansible_collections.huawei.fusioncompute.test.utils.fc_mock_test_case import FcTestCase
from ansible_collections.huawei.fusioncompute.plugins.module_utils.env_fallback import AnsibleFallbackNotFound
from ansible_collections.huawei.fusioncompute.plugins.modules import fc_vm_vcpu_binding


class TestFcVmVcpuBinding(FcTestCase):

    def test_module_fail_when_required_args_missing(self):
        with self.assertRaises(AnsibleFallbackNotFound):
            set_module_args({})
            fc_vm_vcpu_binding.main()

    def test_success_with_exact_binding(self):
        set_module_args({
            'fc_hostname': '127.0.0.1',
            'fc_username': 'test',
            'vm_id': 'i-12345678',
            'cpuBindType': 'exact',
            'emulatorPin': [],
            'exactCpuAffinityList': [{"vcpuScope": "0", "pcpuScope": "9,8"}, 
                                     {"vcpuScope": "1", "pcpuScope": "12,13"}],
            'numaBinds': {},
        })
        with self.assertRaises(AnsibleExitJson) as result:
            fc_vm_vcpu_binding.main()
        # ensure result is changed
        self.mock_put.assert_called_once_with(
            'https://127.0.0.1:7443/service/sites/ffffff/vms/i-12345678/action/vcpupin', {
                'cpuBindType': 'exact',
                'emulatorPin': [],
                'exactCpuAffinityList': [{"vcpuScope": "0", "pcpuScope": "9,8"}, 
                                         {"vcpuScope": "1", "pcpuScope": "12,13"}],
                'numaBinds': {},
            }
        )
        self.assertTrue(result.exception.args[0]['changed'])

    def test_success_with_exact_binding(self):
        set_module_args({
            'fc_hostname': '127.0.0.1',
            'fc_username': 'test',
            'vm_id': 'i-12345678',
            'cpuBindType': 'auto_on',
            'emulatorPin': [],
            'exactCpuAffinityList': [{"vcpuScope": "0", "pcpuScope": "9,8"}, {"vcpuScope": "1", "pcpuScope": "12,13"}],
            'numaBinds': {},
        })
        with self.assertRaises(AnsibleExitJson) as result:
            fc_vm_vcpu_binding.main()
        # ensure result is changed
        self.mock_put.assert_called_once_with(
            'https://127.0.0.1:7443/service/sites/ffffff/vms/i-12345678',
            {'cpu': {'cpuPolicy': 'dedicated'}}
        )
        self.assertTrue(result.exception.args[0]['changed'])
