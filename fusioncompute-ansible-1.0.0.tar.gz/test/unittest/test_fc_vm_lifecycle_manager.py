from unittest.mock import call
from ansible_collections.huawei.fusioncompute.test.utils.basic import AnsibleExitJson, AnsibleFailJson, set_module_args
from ansible_collections.huawei.fusioncompute.test.utils.fc_mock_test_case import FcTestCase
from ansible_collections.huawei.fusioncompute.plugins.module_utils.env_fallback import AnsibleFallbackNotFound
from ansible_collections.huawei.fusioncompute.plugins.modules import fc_vm_lifecycle_manager


class TestFcVmLifecycleManager(FcTestCase):

    def test_module_fail_when_required_args_missing(self):
        with self.assertRaises(AnsibleFallbackNotFound):
            set_module_args({})
            fc_vm_lifecycle_manager.main()

    def test_success_with_create(self):
        set_module_args({
            'fc_hostname': '127.0.0.1',
            'fc_username': 'test',
            'action': 'create',
            "name": "demo-vm-1",
            'vmConfig': {
                'cpu': {
                    'quantity': 8,
                },
                'Memory': {
                    'quantityMB': 128,
                }
            },
        })
        with self.assertRaises(AnsibleExitJson) as result:
            fc_vm_lifecycle_manager.main()
        # ensure result is changed
        self.mock_post.assert_called_once_with(
            'https://127.0.0.1:7443/service/sites/ffffff/vms',
            {'name': 'demo-vm-1',
             'vmConfig': {'cpu': {'quantity': 8}, 'Memory': {'quantityMB': 128}}}
        )
        self.assertTrue(result.exception.args[0]['changed'])

    def test_success_with_start(self):
        set_module_args({
            'fc_hostname': '127.0.0.1',
            'fc_username': 'test',
            'action': 'start',
            "vm_id": "i-xxxxxxxx",
        })
        with self.assertRaises(AnsibleExitJson) as result:
            fc_vm_lifecycle_manager.main()
        # ensure result is changed
        self.mock_post.assert_called_once_with(
            'https://127.0.0.1:7443/service/sites/ffffff/vms/i-xxxxxxxx/action/start',
            {}
        )
        self.assertTrue(result.exception.args[0]['changed'])

    def test_success_with_stop(self):
        set_module_args({
            'fc_hostname': '127.0.0.1',
            'fc_username': 'test',
            'action': 'stop',
            "vm_id": "i-xxxxxxxx",
            'mode': 'safe',
        })
        with self.assertRaises(AnsibleExitJson) as result:
            fc_vm_lifecycle_manager.main()
        # ensure result is changed
        self.mock_post.assert_called_once_with(
            'https://127.0.0.1:7443/service/sites/ffffff/vms/i-xxxxxxxx/action/stop',
            {'mode': 'safe'}
        )
        self.assertTrue(result.exception.args[0]['changed'])

    def test_success_with_delete(self):
        set_module_args({
            'fc_hostname': '127.0.0.1',
            'fc_username': 'test',
            'action': 'delete',
            "vm_id": "i-xxxxxxxx",
            'isReserveDisks': 1,
            'isFormat': 1,
        })
        with self.assertRaises(AnsibleExitJson) as result:
            fc_vm_lifecycle_manager.main()
        # ensure result is changed
        self.mock_delete.assert_called_once_with(
            'https://127.0.0.1:7443/service/sites/ffffff/vms/i-xxxxxxxx',
            {'isReserveDisks': 1, 'isFormat': 1}
        )
        self.assertTrue(result.exception.args[0]['changed'])

    def test_success_with_restart(self):
        set_module_args({
            'fc_hostname': '127.0.0.1',
            'fc_username': 'test',
            'action': 'restart',
            "vm_id": "i-xxxxxxxx",
            'mode': 'force',
        })
        with self.assertRaises(AnsibleExitJson) as result:
            fc_vm_lifecycle_manager.main()
        # ensure result is changed
        self.mock_post.assert_called_once_with(
            'https://127.0.0.1:7443/service/sites/ffffff/vms/i-xxxxxxxx/action/reboot',
            {'mode': 'force'}
        )
        self.assertTrue(result.exception.args[0]['changed'])

    def test_success_with_hibernate(self):
        set_module_args({
            'fc_hostname': '127.0.0.1',
            'fc_username': 'test',
            'action': 'hibernate',
            "vm_id": "i-xxxxxxxx",
        })
        with self.assertRaises(AnsibleExitJson) as result:
            fc_vm_lifecycle_manager.main()
        # ensure result is changed
        self.mock_post.assert_called_once_with(
            'https://127.0.0.1:7443/service/sites/ffffff/vms/i-xxxxxxxx/action/hibernate',
            {}
        )
        self.assertTrue(result.exception.args[0]['changed'])

    def test_success_with_convert_to_vm(self):
        set_module_args({
            'fc_hostname': '127.0.0.1',
            'fc_username': 'test',
            'action': 'convert_to_vm',
            "vm_id": "i-xxxxxxxx",
        })
        with self.assertRaises(AnsibleExitJson) as result:
            fc_vm_lifecycle_manager.main()
        # ensure result is changed
        self.mock_put.assert_called_once_with(
            'https://127.0.0.1:7443/service/sites/ffffff/vms/i-xxxxxxxx',
            {'isTemplate': False}
        )
        self.assertTrue(result.exception.args[0]['changed'])

    def test_success_with_convert_to_template(self):
        set_module_args({
            'fc_hostname': '127.0.0.1',
            'fc_username': 'test',
            'action': 'convert_to_template',
            "vm_id": "i-xxxxxxxx",
        })
        with self.assertRaises(AnsibleExitJson) as result:
            fc_vm_lifecycle_manager.main()
        # ensure result is changed
        self.mock_put.assert_called_once_with(
            'https://127.0.0.1:7443/service/sites/ffffff/vms/i-xxxxxxxx',
            {'isTemplate': True}
        )
        self.assertTrue(result.exception.args[0]['changed'])
