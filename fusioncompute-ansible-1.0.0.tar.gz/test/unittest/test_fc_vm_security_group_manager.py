from unittest.mock import call
from ansible_collections.huawei.fusioncompute.test.utils.basic import AnsibleExitJson, AnsibleFailJson, set_module_args
from ansible_collections.huawei.fusioncompute.test.utils.fc_mock_test_case import FcTestCase
from ansible_collections.huawei.fusioncompute.plugins.module_utils.env_fallback import AnsibleFallbackNotFound
from ansible_collections.huawei.fusioncompute.plugins.modules import fc_vm_security_group_manager


class TestFcSecurityGroupManager(FcTestCase):

    def test_module_fail_when_required_args_missing(self):
        with self.assertRaises(AnsibleFallbackNotFound):
            set_module_args({})
            fc_vm_security_group_manager.main()

    def test_success_with_create(self):
        set_module_args({
            'fc_hostname': '127.0.0.1',
            'fc_username': 'test',
            'action': 'create',
            'sgName': 'sg-1',
        })
        with self.assertRaises(AnsibleExitJson) as result:
            fc_vm_security_group_manager.main()
        # ensure result is changed
        self.mock_post.assert_called_once_with(
            'https://127.0.0.1:7443/service/sites/ffffff/securitygroups/addsecuritygroup',
            {'sgName': 'sg-1'}
        )
        self.assertTrue(result.exception.args[0]['changed'])

    def test_success_with_delete(self):
        set_module_args({
            'fc_hostname': '127.0.0.1',
            'fc_username': 'test',
            'action': 'delete',
            'sgIds': [2, 3],
        })
        with self.assertRaises(AnsibleExitJson) as result:
            fc_vm_security_group_manager.main()
        # ensure result is changed
        self.mock_post.assert_called_once_with(
            'https://127.0.0.1:7443/service/sites/ffffff/securitygroups/deletesecuritygroup',
            {'sgIds': [2, 3]}
        )
        self.assertTrue(result.exception.args[0]['changed'])

    def test_success_with_modify(self):
        set_module_args({
            'fc_hostname': '127.0.0.1',
            'fc_username': 'test',
            'action': 'modify',
            'sg_id': 234,
            'sgName': 'sg-2',
        })
        with self.assertRaises(AnsibleExitJson) as result:
            fc_vm_security_group_manager.main()
        # ensure result is changed
        self.mock_put.assert_called_once_with(
            'https://127.0.0.1:7443/service/sites/ffffff/securitygroups/234',
            {'sgName': 'sg-2'}
        )
        self.assertTrue(result.exception.args[0]['changed'])

    def test_success_with_create_rule(self):
        set_module_args({
            'fc_hostname': '127.0.0.1',
            'fc_username': 'test',
            'action': 'create_rule',
            'sg_id': 234,
            'rules': [{
                "direction": 0,
                "fromPort": 2,
                "ipProtocol": "tcp",
                "ipRanges": "1.2.3.0/24",
                "ipVersion": 4,
                "toPort": 6
            }]
        })
        with self.assertRaises(AnsibleExitJson) as result:
            fc_vm_security_group_manager.main()
        # ensure result is changed
        self.mock_post.assert_called_once_with(
            'https://127.0.0.1:7443/service/sites/ffffff/securitygroups/234/action/addrules',
            {'rules': [{'direction': 0, 'fromPort': 2, 'ipProtocol': 'tcp',
                        'ipRanges': '1.2.3.0/24', 'ipVersion': 4, 'toPort': 6}]}
        )
        self.assertTrue(result.exception.args[0]['changed'])

    def test_success_with_delete_rule(self):
        set_module_args({
            'fc_hostname': '127.0.0.1',
            'fc_username': 'test',
            'action': 'delete_rule',
            'sg_id': 234,
            'ruleIds': [2, 3]
        })
        with self.assertRaises(AnsibleExitJson) as result:
            fc_vm_security_group_manager.main()
        # ensure result is changed
        self.mock_post.assert_called_once_with(
            'https://127.0.0.1:7443/service/sites/ffffff/securitygroups/234/action/delrules',
            {'ruleIds': [2, 3]}
        )
        self.assertTrue(result.exception.args[0]['changed'])

    def test_success_with_pagination(self):
        set_module_args({
            'fc_hostname': '127.0.0.1',
            'fc_username': 'test',
            'action': 'pagination',
            'sgName': 'demo',
            'limit': 2
        })
        with self.assertRaises(AnsibleExitJson) as result:
            fc_vm_security_group_manager.main()
        # ensure result is changed
        self.mock_get.assert_called_once_with(
            'https://127.0.0.1:7443/service/sites/ffffff/securitygroups',
            {'sgName': 'demo', 'limit': 2}
        )
        self.assertFalse(result.exception.args[0]['changed'])

    def test_success_with_pagination_rule(self):
        set_module_args({
            'fc_hostname': '127.0.0.1',
            'fc_username': 'test',
            'action': 'pagination_rule',
            'sg_id': 234,
            'offset': 2
        })
        with self.assertRaises(AnsibleExitJson) as result:
            fc_vm_security_group_manager.main()
        # ensure result is changed
        self.mock_get.assert_called_once_with(
            'https://127.0.0.1:7443/service/sites/ffffff/securitygroups/234/action/rules',
            {'offset': 2}
        )
        self.assertFalse(result.exception.args[0]['changed'])
