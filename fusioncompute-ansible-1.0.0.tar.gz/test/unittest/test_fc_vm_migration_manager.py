from unittest.mock import call
from ansible_collections.huawei.fusioncompute.test.utils.basic import AnsibleExitJson, AnsibleFailJson, set_module_args
from ansible_collections.huawei.fusioncompute.test.utils.fc_mock_test_case import FcTestCase
from ansible_collections.huawei.fusioncompute.plugins.module_utils.env_fallback import AnsibleFallbackNotFound
from ansible_collections.huawei.fusioncompute.plugins.modules import fc_vm_migration_manager


class TestFcVmMigrationeManager(FcTestCase):

    def test_module_fail_when_required_args_missing(self):
        with self.assertRaises(AnsibleFallbackNotFound):
            set_module_args({})
            fc_vm_migration_manager.main()

    def test_success_with_migrate_full(self):
        set_module_args({
            'fc_hostname': '127.0.0.1',
            'fc_username': 'test',
            'action': 'migrate_full',
            "vm_id": "i-xxxxxxxx",
            'location': 'sites:xxxxxx:clusters:bbbbbb:hosts:1',
            'srcLocation': 'sites:xxxxxx:clusters:ccccccc:hosts:2',
        })
        with self.assertRaises(AnsibleExitJson) as result:
            fc_vm_migration_manager.main()
        # ensure result is changed
        self.mock_post.assert_called_once_with(
            'https://127.0.0.1:7443/service/sites/ffffff/vms/i-xxxxxxxx/action/hostAndStorageMigrate',
            {'location': 'sites:xxxxxx:clusters:bbbbbb:hosts:1',
             'srcLocation': 'sites:xxxxxx:clusters:ccccccc:hosts:2'}
        )
        self.assertTrue(result.exception.args[0]['changed'])

    def test_success_with_migrate_host(self):
        set_module_args({
            'fc_hostname': '127.0.0.1',
            'fc_username': 'test',
            'action': 'migrate_host',
            "vm_id": "i-xxxxxxxx",
            'location': 'sites:xxxxxx:clusters:bbbbbb:hosts:1',
            'srcLocation': 'sites:xxxxxx:clusters:ccccccc:hosts:2',
        })
        with self.assertRaises(AnsibleExitJson) as result:
            fc_vm_migration_manager.main()
        # ensure result is changed
        self.mock_post.assert_called_once_with(
            'https://127.0.0.1:7443/service/sites/ffffff/vms/i-xxxxxxxx/action/migrate',
            {'location': 'sites:xxxxxx:clusters:bbbbbb:hosts:1',
             'srcLocation': 'sites:xxxxxx:clusters:ccccccc:hosts:2'}
        )
        self.assertTrue(result.exception.args[0]['changed'])

    def test_success_with_migrate_storage(self):
        set_module_args({
            'fc_hostname': '127.0.0.1',
            'fc_username': 'test',
            'action': 'migrate_storage',
            "vm_id": "i-xxxxxxxx",
            'location': 'urn:sites:xxxxxxxx:clusters:bbbbbbbb:hosts:1',
            'srcLocation': 'urn:sites:xxxxxxxx:clusters:cccccccc:hosts:2',
            'disks': [{'datastoreUrn': 'urn:sites:xxxxxxxx:datastores:1',
                        'volumeUrn': 'urn:sites:xxxxxxxx:volumes:61', 'migrateType': 1, 'encrypted': '0'}],
            'speed': 'fast',
        })
        with self.assertRaises(AnsibleExitJson) as result:
            fc_vm_migration_manager.main()
        # ensure result is changed
        self.mock_post.assert_called_once_with(
            'https://127.0.0.1:7443/service/sites/ffffff/vms/i-xxxxxxxx/action/migratevol',
            {'disks': [{'datastoreUrn': 'urn:sites:xxxxxxxx:datastores:1',
                        'volumeUrn': 'urn:sites:xxxxxxxx:volumes:61', 'migrateType': 1, 'encrypted': '0'}],
                          'speed': 'fast'}
        )
        self.assertTrue(result.exception.args[0]['changed'])
