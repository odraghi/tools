from unittest.mock import call
from ansible_collections.huawei.fusioncompute.test.utils.basic import AnsibleExitJson, AnsibleFailJson, set_module_args
from ansible_collections.huawei.fusioncompute.test.utils.fc_mock_test_case import FcTestCase
from ansible_collections.huawei.fusioncompute.plugins.module_utils.env_fallback import AnsibleFallbackNotFound
from ansible_collections.huawei.fusioncompute.plugins.modules import fc_vm_attr_manager


class TestFcVmAttrManager(FcTestCase):

    def test_module_fail_when_required_args_missing(self):
        with self.assertRaises(AnsibleFallbackNotFound):
            set_module_args({})
            fc_vm_attr_manager.main()

    def test_success_with_attr_query(self):
        set_module_args({
            'fc_hostname': '127.0.0.1',
            'fc_username': 'test',
            'action': 'query',
            "vm_id": "i-xxxxxxxx",
            "listAllDisksStatus": True,
        })
        with self.assertRaises(AnsibleExitJson) as result:
            fc_vm_attr_manager.main()
        # ensure result is changed
        self.mock_get.assert_called_once_with(
            'https://127.0.0.1:7443/service/sites/ffffff/vms/i-xxxxxxxx?listAllDisksStatus=1'
        )
        self.assertFalse(result.exception.args[0]['changed'])
        self.mock_get.reset_mock()
        set_module_args({
            'fc_hostname': '127.0.0.1',
            'fc_username': 'test',
            'action': 'query',
            "vm_id": "i-xxxxxxxx",
        })
        with self.assertRaises(AnsibleExitJson) as result:
            fc_vm_attr_manager.main()
        # ensure result is changed
        self.mock_get.assert_called_once_with(
            'https://127.0.0.1:7443/service/sites/ffffff/vms/i-xxxxxxxx'
        )
        self.assertFalse(result.exception.args[0]['changed'])

    def test_success_with_attr_query_custom_attr(self):
        set_module_args({
            'fc_hostname': '127.0.0.1',
            'fc_username': 'test',
            'action': 'query_custom_attr',
            "vm_id": "i-xxxxxxxx",
        })
        with self.assertRaises(AnsibleExitJson) as result:
            fc_vm_attr_manager.main()
        # ensure result is changed
        self.mock_get.assert_called_once_with(
            'https://127.0.0.1:7443/service/sites/ffffff/vms/i-xxxxxxxx/customproperties'
        )
        self.assertFalse(result.exception.args[0]['changed'])

    def test_success_with_attr_modifying(self):
        set_module_args({
            'fc_hostname': '127.0.0.1',
            'fc_username': 'test',
            'action': 'modify',
            "vm_id": "i-xxxxxxxx",
            "name": "demo-vm-1",
        })
        with self.assertRaises(AnsibleExitJson) as result:
            fc_vm_attr_manager.main()
        # ensure result is changed
        self.mock_put.assert_called_once_with(
            'https://127.0.0.1:7443/service/sites/ffffff/vms/i-xxxxxxxx',
            {'name': 'demo-vm-1'}
        )
        self.assertTrue(result.exception.args[0]['changed'])
