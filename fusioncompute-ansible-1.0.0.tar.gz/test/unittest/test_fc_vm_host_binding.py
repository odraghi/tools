from unittest.mock import call
from ansible_collections.huawei.fusioncompute.test.utils.basic import AnsibleExitJson, AnsibleFailJson, set_module_args
from ansible_collections.huawei.fusioncompute.test.utils.fc_mock_test_case import FcTestCase
from ansible_collections.huawei.fusioncompute.plugins.module_utils.env_fallback import AnsibleFallbackNotFound
from ansible_collections.huawei.fusioncompute.plugins.modules import fc_vm_host_binding


class TestFcVmVcpuBinding(FcTestCase):

    def test_module_fail_when_required_args_missing(self):
        with self.assertRaises(AnsibleFallbackNotFound):
            set_module_args({})
            fc_vm_host_binding.main()

    def test_success_with_host_binding(self):
        set_module_args({
            'fc_hostname': '127.0.0.1',
            'fc_username': 'test',
            'vm_id': 'i-12345678',
            'action': 'bind',
            'urn': 'urn:sites:DA210DB9:hosts:180',
        })
        with self.assertRaises(AnsibleExitJson) as result:
            fc_vm_host_binding.main()
        # ensure result is changed
        self.mock_put.assert_called_once_with(
            'https://127.0.0.1:7443/service/sites/ffffff/vms/i-12345678/action/bindHost', {
                'bindingHostFlag': True, 'urn': 'urn:sites:DA210DB9:hosts:180'}
        )
        self.assertTrue(result.exception.args[0]['changed'])

    def test_success_with_host_unbinding(self):
        set_module_args({
            'fc_hostname': '127.0.0.1',
            'fc_username': 'test',
            'vm_id': 'i-12345678',
            'action': 'unbind',
        })
        with self.assertRaises(AnsibleExitJson) as result:
            fc_vm_host_binding.main()
        # ensure result is changed
        self.mock_put.assert_called_once_with(
            'https://127.0.0.1:7443/service/sites/ffffff/vms/i-12345678/action/bindHost', {
                'bindingHostFlag': False, 'urn': ''}
        )
        self.assertTrue(result.exception.args[0]['changed'])
