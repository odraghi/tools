from unittest.mock import call
from ansible_collections.huawei.fusioncompute.test.utils.basic import AnsibleExitJson, AnsibleFailJson, set_module_args
from ansible_collections.huawei.fusioncompute.test.utils.fc_mock_test_case import FcTestCase
from ansible_collections.huawei.fusioncompute.plugins.module_utils.env_fallback import AnsibleFallbackNotFound
from ansible_collections.huawei.fusioncompute.plugins.modules import fc_vm_batch_manager


class TestFcVmBatchManager(FcTestCase):

    def test_module_fail_when_required_args_missing(self):
        with self.assertRaises(AnsibleFallbackNotFound):
            set_module_args({})
            fc_vm_batch_manager.main()

    def test_success_with_vm_list(self):
        set_module_args({
            'fc_hostname': '127.0.0.1',
            'fc_username': 'test',
            'action': 'delete',
            'vmList': [
                'urn:sites:ffffff:vms:1',
                'urn:sites:ffffff:vms:2',
            ],
        })
        with self.assertRaises(AnsibleExitJson) as result:
            fc_vm_batch_manager.main()
        # ensure result is changed
        self.mock_post.assert_called_once_with(
            'https://127.0.0.1:7443/service/sites/ffffff/vms/action/multi-delete', {
                'vmList': ['urn:sites:ffffff:vms:1', 'urn:sites:ffffff:vms:2'], 'is_format': '0'}
        )
        self.assertTrue(result.exception.args[0]['changed'])

    def test_success_with_param_path(self):
        set_module_args({
            'fc_hostname': '127.0.0.1',
            'fc_username': 'test',
            'action': 'delete',
            'param_path': '/root/.ansible/collections/ansible_collections'
            '/huawei/fusioncompute/test/config/yaml/vm_batch_deletion.yml',
            'is_format': '1'
        })
        with self.assertRaises(AnsibleExitJson) as result:
            fc_vm_batch_manager.main()
        # ensure result is changed
        self.mock_post.assert_called_once_with(
            'https://127.0.0.1:7443/service/sites/ffffff/vms/action/multi-delete',
            {'vmList': ['urn:sites:ffffff:vms:3',
                        'urn:sites:ffffff:vms:4'],
             'is_format': '1'}
        )
        self.assertTrue(result.exception.args[0]['changed'])
