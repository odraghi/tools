from unittest.mock import call
from ansible_collections.huawei.fusioncompute.test.utils.basic import AnsibleExitJson, AnsibleFailJson, set_module_args
from ansible_collections.huawei.fusioncompute.test.utils.fc_mock_test_case import FcTestCase
from ansible_collections.huawei.fusioncompute.plugins.module_utils.env_fallback import AnsibleFallbackNotFound
from ansible_collections.huawei.fusioncompute.plugins.modules import fc_site_config_manager


class TestFcSiteConfigManager(FcTestCase):

    def test_module_fail_when_required_args_missing(self):
        with self.assertRaises(AnsibleFallbackNotFound):
            set_module_args({})
            fc_site_config_manager.main()

    def test_success_when_update(self):
        set_module_args({
            'fc_hostname': '127.0.0.1',
            'fc_username': 'test',
            'action': 'modify',
            'items': [
                {
                    "key": "vmVncKeymapSetting",
                    "value": 12
                }
            ],
        })
        with self.assertRaises(AnsibleExitJson) as result:
            fc_site_config_manager.main()
        # ensure result is changed
        self.mock_put.assert_has_calls(
            [call('https://127.0.0.1:7443/service/sites/ffffff/advancedconfig',
                  {'items': [{'key': 'vmVncKeymapSetting', 'value': 12}]})]
        )
        self.assertTrue(result.exception.args[0]['changed'])
