from unittest.mock import call
from ansible_collections.huawei.fusioncompute.test.utils.basic import AnsibleExitJson, AnsibleFailJson, set_module_args
from ansible_collections.huawei.fusioncompute.test.utils.fc_mock_test_case import FcTestCase
from ansible_collections.huawei.fusioncompute.plugins.module_utils.env_fallback import AnsibleFallbackNotFound
from ansible_collections.huawei.fusioncompute.plugins.modules import fc_vm_attr_spec_manager


class TestFcVmAttrSpecManager(FcTestCase):

    def test_module_fail_when_required_args_missing(self):
        with self.assertRaises(AnsibleFallbackNotFound):
            set_module_args({})
            fc_vm_attr_spec_manager.main()

    def test_success_with_spec_creating(self):
        set_module_args({
            'fc_hostname': '127.0.0.1',
            'fc_username': 'test',
            'action': 'create',
            "name": "vm-spec-1",
            "osType": "Windows",
            "description": "",
            "hostname": "hn",
            "workgroup": "wg"
        })
        with self.assertRaises(AnsibleExitJson) as result:
            fc_vm_attr_spec_manager.main()
        # ensure result is changed
        self.mock_post.assert_called_once_with(
            'https://127.0.0.1:7443/service/sites/ffffff/vmcustomizations', {
                'name': 'vm-spec-1',
                'description': '',
                'osType': 'Windows',
                'hostname': 'hn',
                'workgroup': 'wg'
            }
        )
        self.assertTrue(result.exception.args[0]['changed'])

    def test_success_with_spec_modifying(self):
        set_module_args({
            'fc_hostname': '127.0.0.1',
            'fc_username': 'test',
            'action': 'modify',
            'spec_id': '234',
            "name": "vm-spec-2",
            "osType": "Windows",
            "description": "",
            "hostname": "hn-2",
            "workgroup": "wg-2"
        })
        with self.assertRaises(AnsibleExitJson) as result:
            fc_vm_attr_spec_manager.main()
        # ensure result is changed
        self.mock_put.assert_called_once_with(
            'https://127.0.0.1:7443/service/sites/ffffff/vmcustomizations/234', {
                'name': 'vm-spec-2',
                'description': '',
                'osType': 'Windows',
                'hostname': 'hn-2',
                'workgroup': 'wg-2'
            }
        )
        self.assertTrue(result.exception.args[0]['changed'])

    def test_success_with_spec_query(self):
        set_module_args({
            'fc_hostname': '127.0.0.1',
            'fc_username': 'test',
            'spec_id': 'vm-spec-1',
            'action': 'query',
        })
        with self.assertRaises(AnsibleExitJson) as result:
            fc_vm_attr_spec_manager.main()
        # ensure result is changed
        self.mock_get.assert_called_once_with(
            'https://127.0.0.1:7443/service/sites/ffffff/vmcustomizations/vm-spec-1'
        )
        self.assertFalse(result.exception.args[0]['changed'])

    def test_success_with_spec_pagination(self):
        set_module_args({
            'fc_hostname': '127.0.0.1',
            'fc_username': 'test',
            'action': 'pagination',
            'limit': 10,
            'offset': 5,
        })
        with self.assertRaises(AnsibleExitJson) as result:
            fc_vm_attr_spec_manager.main()
        # ensure result is changed
        self.mock_get.assert_called_once_with(
            'https://127.0.0.1:7443/service/sites/ffffff/vmcustomizations',
            params={'limit': 10, 'offset': 5}
        )
        self.assertFalse(result.exception.args[0]['changed'])