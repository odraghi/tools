from unittest.mock import call
from ansible_collections.huawei.fusioncompute.test.utils.basic import AnsibleExitJson, AnsibleFailJson, set_module_args
from ansible_collections.huawei.fusioncompute.test.utils.fc_mock_test_case import FcTestCase
from ansible_collections.huawei.fusioncompute.plugins.module_utils.env_fallback import AnsibleFallbackNotFound
from ansible_collections.huawei.fusioncompute.plugins.modules import fc_vm_vmtools_manager


class TestFcVmVmtoolsManager(FcTestCase):

    def test_module_fail_when_required_args_missing(self):
        with self.assertRaises(AnsibleFallbackNotFound):
            set_module_args({})
            fc_vm_vmtools_manager.main()

    def test_success_with_vmtool_install(self):
        set_module_args({
            'fc_hostname': '127.0.0.1',
            'fc_username': 'test',
            'vm_id': 'i-12345678',
            'action': 'mount',
        })
        with self.assertRaises(AnsibleExitJson) as result:
            fc_vm_vmtools_manager.main()
        # ensure result is changed
        self.mock_post.assert_called_once_with(
            'https://127.0.0.1:7443/service/sites/ffffff/vms/i-12345678/action/installtools',
            {}
        )
        self.assertTrue(result.exception.args[0]['changed'])

    def test_success_with_vmtool_uninstall(self):
        set_module_args({
            'fc_hostname': '127.0.0.1',
            'fc_username': 'test',
            'vm_id': 'i-12345678',
            'action': 'unmount',
        })
        with self.assertRaises(AnsibleExitJson) as result:
            fc_vm_vmtools_manager.main()
        # ensure result is changed
        self.mock_post.assert_called_once_with(
            'https://127.0.0.1:7443/service/sites/ffffff/vms/i-12345678/action/uninstalltools',
            {}
        )
        self.assertTrue(result.exception.args[0]['changed'])
