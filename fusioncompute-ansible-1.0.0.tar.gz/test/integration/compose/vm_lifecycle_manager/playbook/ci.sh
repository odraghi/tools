#!/bin/bash
ansible-playbook test_create_then_delete.yml