#!/bin/bash
ansible-playbook test_query_one.yml