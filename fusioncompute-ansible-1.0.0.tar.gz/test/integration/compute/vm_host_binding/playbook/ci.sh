#!/bin/bash
ansible-playbook test_binding.yml