#!/bin/bash
ansible-playbook test_query.yml