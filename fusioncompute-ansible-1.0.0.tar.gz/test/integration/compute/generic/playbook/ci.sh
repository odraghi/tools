#!/bin/bash
ansible-playbook test_get.yml