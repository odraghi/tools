#!/bin/bash
ansible-playbook test_pagination.yml