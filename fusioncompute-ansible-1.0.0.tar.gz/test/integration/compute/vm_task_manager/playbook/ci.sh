#!/bin/bash
ansible-playbook test_cancel.yml