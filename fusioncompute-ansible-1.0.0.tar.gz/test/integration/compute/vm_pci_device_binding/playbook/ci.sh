#!/bin/bash
ansible-playbook test_bind.yml