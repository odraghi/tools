#!/bin/bash
ansible-playbook test_migrate_full.yml