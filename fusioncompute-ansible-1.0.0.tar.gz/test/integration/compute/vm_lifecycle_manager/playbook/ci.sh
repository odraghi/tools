#!/bin/bash
ansible-playbook test_stop.yml