#!/bin/bash
ansible-playbook test_attach.yml