#!/bin/bash
ansible-playbook test_vcpu_binding_auto.yml