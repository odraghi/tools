#!/bin/bash
ansible-playbook test_unmount.yml