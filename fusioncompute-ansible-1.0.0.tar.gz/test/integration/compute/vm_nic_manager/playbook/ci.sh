#!/bin/bash
ansible-playbook test_create.yml