from http import HTTPStatus
import sys
import tempfile
import json
import requests
from ansible_collections.huawei.fusioncompute.plugins.module_utils.core.fusincompute import logger
from ansible_collections.huawei.fusioncompute.plugins.module_utils.core.parameter_normalization \
    import mask_sensitive_field


def pull_http_file(url, params):
    logger.debug('pull_http_file: url: %s, params:%s', url, mask_sensitive_field(params))
    with tempfile.NamedTemporaryFile(delete=False) as tmp_file:
        tmp_file_path = tmp_file.name
        logger.debug('Downloading file from url: %s to: %s', url, tmp_file_path)
        with requests.get(url, stream=True, verify=params['ca_path']) as response:
            if response.status_code == HTTPStatus.OK:
                for chunk in response.iter_content(chunk_size=1024*1024):
                    if chunk:
                        tmp_file.write(chunk)
                logger.debug('File downloaded successfully to %s', tmp_file_path)
            else:
                logger.debug('Failed to download file. HTTP status code: %s', response.status_code)
        return True, tmp_file_path


if __name__ == '__main__':
    url = sys.argv[1]
    params = json.loads(sys.argv[2])
    auto_clean, file_path = pull_http_file(url, params)
    print('%s %s' % (auto_clean, file_path))
