#!/bin/bash
ansible-playbook test_uninstall.yml