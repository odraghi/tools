#!/bin/bash
ansible-playbook test_pagination_v2.yml