#!/bin/bash
ansible-playbook test_change_password.yml