#!/bin/bash
ansible-playbook test_advanced_config.yml