#!/bin/bash
ansible-playbook test_login.yml