#!/usr/bin/env python
# -*- coding:utf-8 -*-
#  Copyright (c) Huawei Technologies Co., Ltd. 2024-2024. All rights reserved.
import logging

DEFAULT_MODULE_LOG_FILE_PATH = '/var/log/ansible/fusioncompute_ansible_module.log'
DEFAULT_PLAYBOOK_LOG_FILE_PATH = '/var/log/ansible/fusioncompute_ansible_playbook.log'
DEFAULT_MODULE_LOG_FORMAT = '[%(asctime)s] [%(levelname)-5s] [%(filename)s:%(lineno)d] %(message)s'
DEFAULT_MODULE_LOG_LEVEL = 'DEBUG'
DEFAULT_PLAYBOOK_LOG_LEVEL = logging.INFO
DEFAULT_MODULE_LOG_MAX_FILE_SIZE = '50MB'
DEFAULT_MODULE_LOG_BACKUP_COUNT = 24*3  # 3 days
DEFAULT_MODULE_LOG_ROTATION_INTERVAL = '1'
DEFAULT_MODULE_LOG_ROTATION_WHEN = 'H'
DEFAULT_MODULE_LOG_DIR_PERMISSION = 0o750
DEFAULT_MODULE_LOG_FILE_PERMISSION = 0o640
DEFAULT_MODULE_LOG_HISTORY_FILE_PERMISSION = 0o440
DEFAULT_SENSITIVE_FIELDS = ['token', 'password', 'key',
                            'email', 'phone', 'pwd', 'secret', 
                            'cipher_text', 'pa2wd', 'passwd', 
                            'authorizeinfo', 'iqn', 'wwn', 's3config']
DEFAULT_SENSITIVE_REPLACED_STRING = 'XXXXXXXX'
