#!/usr/bin/env python
# -*- coding:utf-8 -*-
#  Copyright (c) Huawei Technologies Co., Ltd. 2024-2024. All rights reserved.
from ansible_collections.huawei.fusioncompute.plugins.module_utils.entity.enum.basic import Language


DEFAULT_VRM_PORT = 7443
INTERFACE_USER_TYPE = 2
DEFAULT_ENCRIPT_ALGORITHM = 1
BASE_HEADERS = {
    'Content-Type': 'application/json',
    'Accept': 'application/json;version=8.0',
}
FC_COMMON_URL_PREFIX = 'https://{}:{}/service'
DEFAULT_LANGUAGE = Language.zh_cn
DEFAULT_CONFIGS = {'max_retry_times': 3, 'timeout': 10}

DEFAULT_MAX_RETRY_TIMES = 3
DEFAULT_INTERVAL = 5
DEFAULT_TIMEOUT = 30
