#!/usr/bin/env python
# -*- coding:utf-8 -*-
#  Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.

DEFAULT_CONFIG_PATH = '/etc/ansible/fusioncompute/config.ini'

