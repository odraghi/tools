#!/usr/bin/env python
# -*- coding:utf-8 -*-
#  Copyright (c) Huawei Technologies Co., Ltd. 2024-2024. All rights reserved.
from enum import Enum
from functools import partial, wraps
from typing import Type

from ansible_collections.huawei.fusioncompute.plugins.module_utils.basic import FcParamValidatorBase


def action_injector(action_type: Type[Enum], param: str = 'action', target_attr: str = 'action'):
    def decorator(cls):
        original_init = cls.__init__

        @wraps(original_init)
        def new_init(self, *args, **kwargs):
            original_init(self, *args, **kwargs)
            action_str = self.params[param]
            setattr(self, target_attr, action_type(action_str))
        cls.__init__ = new_init
        return cls
    return decorator


def validator_injector(validators: list[FcParamValidatorBase]):
    def decorator(cls):
        original_init = cls.__init__

        def validator_fn(self, *args, **kwargs):
            for validator in validators:
                res = validator.validate(self)
                if res:
                    return res
            return ''

        @wraps(original_init)
        def new_init(self, *args, **kwargs):
            original_init(self, *args, **kwargs)
            setattr(self, 'validate', partial(validator_fn, self))
        cls.__init__ = new_init
        return cls
    return decorator
