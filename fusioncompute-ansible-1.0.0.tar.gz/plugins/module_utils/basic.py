#!/usr/bin/env python
# -*- coding:utf-8 -*-
#  Copyright (c) Huawei Technologies Co., Ltd. 2024-2024. All rights reserved.
from abc import abstractmethod
import inspect
import os
import re
from typing import Callable, Optional
from ansible_collections.huawei.fusioncompute.plugins.module_utils.core.fusincompute import logger
from ansible_collections.huawei.fusioncompute.plugins.module_utils.constants.http_constant \
    import DEFAULT_LANGUAGE, DEFAULT_VRM_PORT
from ansible_collections.huawei.fusioncompute.plugins.module_utils.core.fusincompute \
    import DefaultFcHttpClient, FcHttpBase
from ansible_collections.huawei.fusioncompute.plugins.module_utils.entity.enum.basic \
    import Language, EnvFallBackAction
from ansible_collections.huawei.fusioncompute.plugins.module_utils.env_fallback import env_fallback
from ansible_collections.huawei.fusioncompute.plugins.module_utils.core.global_config import GlobalConfig


class HttpClientFactory():
    @staticmethod
    def create_client(policy, *args, **kwargs) -> FcHttpBase:
        if policy == 'default':
            return DefaultFcHttpClient(*args, **kwargs)
        raise NotImplementedError(
            f'Http client with policy: {policy} is unsupported.')


class FcModuleBase(object):
    def __init__(self, module, policy='default'):
        """
        Constructor
        """
        self.module = module
        self.params = module.params
        global_config = GlobalConfig()
        language = Language(self.params['fc_language'] or global_config.get(
            'fc_language', DEFAULT_LANGUAGE))
        is_force_verify = global_config.get(
            'ssl_force_verification', 'true') != 'false'
        verify = module.params['fc_verify'] or global_config.get(
            'ssl_ca_cert_path', False)
        if is_force_verify and not verify:
            err_msg = 'Must give valid certifacte path.'
            logger.error(err_msg)
            raise ValueError(err_msg)
        self.client: FcHttpBase = HttpClientFactory.create_client(policy,
                                                                  self.params['fc_hostname'],
                                                                  self.params['fc_port'],
                                                                  language,
                                                                  verify)
        if self.params['fc_site_id'] is not None:
            logger.debug('Using provided fc_site_id: %s',
                         self.params['fc_site_id'])
            self.client.site_id = self.params['fc_site_id']
        else:
            logger.debug(
                'No fc_site_id provided, will retrieve from FusionCompute.')
        if self.params['fc_token'] is not None:
            logger.debug('Using provided authentication token.')
            self.client.set_auth_token(self.params['fc_token'])
        else:
            env_token = os.environ.get('FUSIONCOMPUTE_TOKEN')
            if env_token:
                logger.debug('Using authentication token from environment.')
                self.params['fc_token'] = env_token
                self.client.set_auth_token(env_token)
            else:
                logger.debug(
                    'No authentication token found, logging in with username and password.')
                self.client.login(
                    self.params['fc_username'], self.params['fc_password'])

    def exact_params(self, parm_names):
        res = {}
        for param in parm_names:
            res[param] = self.params.get(param, None)
        return res

    @staticmethod
    def args():
        return dict(
            fc_hostname=dict(type='str', required=False,
                             fallback=(env_fallback, [EnvFallBackAction.do_throw, 'FUSIONCOMPUTE_HOST'])),
            fc_port=dict(type='int', required=False,
                         fallback=(env_fallback, [DEFAULT_VRM_PORT, 'FUSIONCOMPUTE_PORT'])),
            fc_token=dict(type='str', required=False, no_log=True,
                          fallback=(env_fallback, [None, 'FUSIONCOMPUTE_TOKEN'])),
            fc_username=dict(type='str', required=False,
                             fallback=(env_fallback, [EnvFallBackAction.no_throw, 'FUSIONCOMPUTE_USERNAME'])),
            fc_password=dict(type='str', aliases=['pass', 'pwd'],
                             required=False, no_log=True,
                             fallback=(env_fallback, [EnvFallBackAction.no_throw, 'FUSIONCOMPUTE_PASSWORD'])),
            fc_site_id=dict(type='str', required=False,
                            fallback=(env_fallback, [EnvFallBackAction.no_throw, 'FUSIONCOMPUTE_SITE_ID'])),
            fc_language=dict(type='str', required=False,
                             fallback=(env_fallback, [None, 'FUSIONCOMPUTE_LANGUAGE'])),
            fc_verify=dict(type='str', required=False,
                           fallback=(env_fallback, ['', 'FUSIONCOMPUTE_VERIFY'])),
        )

    @abstractmethod
    def validate(self) -> str:
        pass


class FcParamValidatorBase(object):
    def __init__(self, attr, validator_fn: Callable[[any, Optional[str]], bool]):
        self.attr = attr
        self.validator_fn = validator_fn

    def validate(self, obj) -> str:
        if callable(self.validator_fn):
            for match_name, match_res in self.match(obj.params).items():
                param_len = len(inspect.signature(
                    self.validator_fn).parameters)
                if param_len == 1 and not self.validator_fn(match_res):
                    return f"validate fail for {match_name}: {match_res}"
                elif param_len == 2 and not self.validator_fn(match_res, match_name):
                    return f"validate fail for {match_name}: {match_res}"
        return ''

    @abstractmethod
    def match(self, obj) -> dict:
        pass


class FcAttrValidator(FcParamValidatorBase):
    def __init__(self, attr, validator_fn):
        super().__init__(attr, validator_fn)

    def match(self, obj: dict):
        return {self.attr: obj.get(self.attr, None)}


class FcRegexValidator(FcParamValidatorBase):
    def __init__(self, pattern, validator_fn):
        super().__init__(pattern, validator_fn)

    def match(self, obj):
        return {attr_name: getattr(obj, attr_name) for attr_name in dir(obj) if re.match(self.attr, attr_name)}
