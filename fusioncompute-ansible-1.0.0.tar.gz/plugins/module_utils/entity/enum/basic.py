#!/usr/bin/env python
# -*- coding:utf-8 -*-
#  Copyright (c) Huawei Technologies Co., Ltd. 2024-2024. All rights reserved.
from enum import Enum


class Language(Enum):
    en_us = 'en_US'
    zh_cn = 'zh_CN'


class RestfulReqType(Enum):
    post = 'post'
    get = 'get'
    put = 'put'
    delete = 'delete'
    options = 'options'
    patch = 'patch'
    head = 'head'


class EnvFallBackAction(Enum):
    do_throw = 'do_throw'
    no_throw = 'no_throw'


class FileFormatType(Enum):
    unsupported = ''
    yaml = 'yml'
    xml = 'xml'
    toml = 'toml'
    excel = 'excel'


class VcpuBindType(Enum):
    nobind = 'nobind'
    auto_on = 'auto_on'
    auto_off = 'auto_off'
    exact = 'exact'
    range = 'range'
    numa = 'numa'


class BindAction(Enum):
    bind = 'bind'
    unbind = 'unbind'


class ManageAction(Enum):
    query = 'query'
    pagination = 'pagination'
    delete = 'delete'
    create = 'create'
    modify = 'modify'


class FcTaskStatus(Enum):
    unknown = 'unknown'
    running = 'running'
    success = 'success'
    failed = 'failed'
