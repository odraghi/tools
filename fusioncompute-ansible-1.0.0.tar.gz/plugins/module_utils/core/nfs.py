import os
import subprocess
import tempfile

from ansible_collections.huawei.fusioncompute.plugins.module_utils.core.fusincompute import logger


def mount_nfs(nfs_path: str, timeout=30) -> str:
    """
    Mount the NFS share to a temporary directory and return the path of the mounted directory.

    :param nfs_path: The NFS path (e.g., 'nfs://ip/xxx')
    :param timeout: The timeout in seconds for the mount operation.
    :return: The local mount point where the NFS is mounted, or None if the mount operation fails.
    """
    # Create a temporary directory to mount the NFS share
    mount_point = tempfile.mkdtemp()

    # Remove the 'nfs://' prefix from the path if present
    nfs_path = nfs_path.replace("nfs://", "")

    mount_options = "nosuid,noexec,nodev"
    # Prepare the mount command
    mount_command = ["mount", "-t", "nfs", "-o", mount_options, nfs_path, mount_point]

    try:
        # Execute the mount command and set a timeout
        subprocess.run(mount_command, check=True, timeout=timeout)
        logger.info(
            f"Successfully mounted NFS share {nfs_path} to {mount_point}")
        return mount_point

    except subprocess.CalledProcessError as e:
        logger.error(f"Failed to mount NFS share: {e}")
        os.remove(mount_point)  # Cleanup the temporary directory
        return None

    except subprocess.TimeoutExpired as e:
        logger.error(f"Mount operation timed out after {timeout} seconds.")
        if e.process:
            e.process.kill()  # Kill the subprocess if it's still running
        os.remove(mount_point)  # Cleanup the temporary directory
        return None

    except Exception as e:
        logger.error(f"Unexpected error: {e}")
        os.remove(mount_point)  # Cleanup the temporary directory
        return None


def unmount_nfs(mount_point: str, timeout=30) -> bool:
    """
    Unmount the NFS share from the temporary directory.

    :param mount_point: The path where the NFS share was mounted.
    :param timeout: The timeout in seconds for the unmount operation.
    :return: True if unmounting was successful, False otherwise.
    """
    try:
        # Run the umount command to unmount the NFS share
        subprocess.run(["umount", mount_point], check=True, timeout=timeout)
        logger.info(f"Successfully unmounted {mount_point}")
        os.remove(mount_point)  # Cleanup the temporary directory
        return True

    except subprocess.CalledProcessError as e:
        logger.error(f"Failed to unmount: {e}")
        return False

    except subprocess.TimeoutExpired as e:
        logger.error(f"Unmount operation timed out after {timeout} seconds.")
        if e.process:
            e.process.kill()  # Kill the subprocess if it's still running
        return False

    except Exception as e:
        logger.error(f"Unexpected error: {e}")
        return False
