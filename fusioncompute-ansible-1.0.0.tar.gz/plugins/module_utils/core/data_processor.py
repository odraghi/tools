#!/usr/bin/env python
# -*- coding:utf-8 -*-
#  Copyright (c) Huawei Technologies Co., Ltd. 2024-2024. All rights reserved.

from pathlib import Path
from ansible_collections.huawei.fusioncompute.plugins.module_utils.core.config_parser \
    import ConfigParser, ExcelParser, TomlParser, XmlParser, YamlParser
from ansible_collections.huawei.fusioncompute.plugins.module_utils.core.data_exporter \
    import DataExporter, ExcelExporter, YamlExporter, TomlExporter, XmlExporter
from ansible_collections.huawei.fusioncompute.plugins.module_utils.entity.enum.basic import FileFormatType
from ansible_collections.huawei.fusioncompute.plugins.module_utils.metaclass import SingletonMeta


class DataProcessor(metaclass=SingletonMeta):
    def __init__(self):
        """
        Initializes the DataProcessor class with parsers and exporters for each file format.
        The parsers handle reading configuration files, and the exporters handle saving data.
        """
        # Mapping of file formats to their respective parsers
        self.parsers: dict[FileFormatType, ConfigParser] = {
            FileFormatType.yaml: YamlParser(),
            FileFormatType.toml: TomlParser(),
            FileFormatType.xml: XmlParser(),
            FileFormatType.excel: ExcelParser(),
        }

        # Mapping of file formats to their respective exporters
        self.exporters: dict[FileFormatType, DataExporter] = {
            FileFormatType.yaml: YamlExporter(),
            FileFormatType.toml: TomlExporter(),
            FileFormatType.xml: XmlExporter(),
            FileFormatType.excel: ExcelExporter(),
        }

    def load_config(self, source: str, file_format: FileFormatType = None) -> dict:
        """
        Load and parse the configuration file from the specified source.

        :param source: Path or URL to the configuration file
        :param file_format: The format of the configuration file (YAML, TOML, XML, Excel).
                       If None, the format will be detected based on the file extension.
        :return: Parsed configuration data as a dictionary
        """
        # Detect format if not provided
        if file_format is None:
            try:
                # Extract the file extension and map it to a FileFormatType
                file_format = FileFormatType(Path(source).suffix[1:])
            except ValueError:
                file_format = None  # If file extension is unsupported, set to None

        # Check if the format is supported
        if file_format not in self.parsers:
            raise ValueError(
                f"Unsupported file format: {file_format.value if format else 'None'}")

        # Get the appropriate parser based on the file_format
        parser = self.parsers[file_format]
        return parser.load(source)

    def save(self, destination: str, data: dict, file_format: FileFormatType = None) -> bool:
        """
        Save the provided data to a destination in the specified file format.

        :param destination: Path or URL to save the data
        :param data: Dictionary containing the data to be saved
        :param file_format: The desired format to save the data (YAML, TOML, XML, Excel).
                       If None, the format will be inferred from the destination file extension.
        :return: True if the data was successfully saved, False otherwise
        """
        # Detect format if not provided
        if file_format is None:
            try:
                # Extract the file extension and map it to a FileFormatType
                file_format = FileFormatType(Path(destination).suffix[1:])
            except ValueError:
                # If file extension is unsupported, set format to unsupported
                file_format = FileFormatType.unsupported

        # Check if the format is supported
        if file_format not in self.exporters:
            raise ValueError(
                f"Unsupported file format: {file_format.value if file_format else 'None'}")

        # Get the appropriate exporter based on the format
        exporter = self.exporters[file_format]
        return exporter.save(destination, data)
