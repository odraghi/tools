#!/usr/bin/env python
# -*- coding:utf-8 -*-
#  Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.
import glob
import os
from logging.handlers import TimedRotatingFileHandler
from ansible_collections.huawei.fusioncompute.plugins.module_utils.core.global_config import GlobalConfig
from ansible_collections.huawei.fusioncompute.plugins.module_utils.constants.logger_constant \
    import DEFAULT_MODULE_LOG_FILE_PERMISSION, DEFAULT_MODULE_LOG_HISTORY_FILE_PERMISSION, \
    DEFAULT_MODULE_LOG_MAX_FILE_SIZE


class SafeTimedRotatingFileHandler(TimedRotatingFileHandler):
    """ Custom log handler that rotates logs based on time and ensures log files do not exceed a maximum size. """

    def __init__(self, *args, **kwargs):
        """ Initialize the log handler and set the max log file size from the global configuration. """
        super().__init__(*args, **kwargs)  # Call parent class constructor
        global_config = GlobalConfig()
        log_max_file_size = global_config.get(
            'log_max_file_size', DEFAULT_MODULE_LOG_MAX_FILE_SIZE)
        size_units = {'KB': 1024, 'MB': 1024**2, 'GB': 1024**3}
        cur_unit = log_max_file_size[-2:]
        if cur_unit not in size_units:
            raise ValueError('Must use KB,MB,GB for log_max_file_size')
        self.max_size = int(log_max_file_size[:-2]) * \
            size_units[cur_unit]

    def emit(self, record):
        """ Override `emit` to check file size before writing a new log entry. """
        if os.path.exists(self.baseFilename) and os.path.getsize(self.baseFilename) > self.max_size:
            self.doRollover()  # Perform log rotation if file size exceeds limit
        super().emit(record)  # Proceed with the original logging process
        # After writing the log entry, ensure the log file has the correct permissions
        if os.path.exists(self.baseFilename):
            # Set active log file permissions
            os.chmod(self.baseFilename, DEFAULT_MODULE_LOG_FILE_PERMISSION)
        # Get the directory of the log file
        log_dir = os.path.dirname(self.baseFilename)
        # Get the base filename
        base_filename = os.path.basename(self.baseFilename)
        archived_log_pattern = os.path.join(log_dir, base_filename + '.*')
        for filename in glob.glob(archived_log_pattern):
            os.chmod(filename, DEFAULT_MODULE_LOG_HISTORY_FILE_PERMISSION)
