#!/usr/bin/env python
# -*- coding:utf-8 -*-
#  Copyright (c) Huawei Technologies Co., Ltd. 2024-2024. All rights reserved.

from abc import ABC, abstractmethod
import openpyxl
import yaml
import xml.etree.ElementTree as ET

from ansible_collections.huawei.fusioncompute.plugins.module_utils.core.file_loader import FileLoader


class ConfigParser(ABC):
    """
    Abstract base class for configuration file parsers.
    Subclasses should implement the `parse` method to handle specific file formats.
    """

    @property
    @abstractmethod
    def encoding(self):
        """
        Returns whether the content requires encoding.
        :return: True if encoding is needed, False otherwise.
        """
        raise NotImplementedError(
            "Subclasses of ConfigParser should implement encoding.")

    def _load_file(self, source: str) -> str | bytes:
        """
        Load configuration file content from a given source.
        :param source: Path or URL to the configuration file
        :return: File content as a string or bytes
        """
        return FileLoader.load_file(source, encoding=self.encoding)

    def load(self, source: str) -> dict:
        """
        Load and parse the configuration file from the given source.
        :param source: Path or URL to the configuration file
        :return: Parsed configuration data as a dictionary
        """
        data = self._load_file(source)
        return self.parse(data)

    @abstractmethod
    def parse(self, data: str) -> dict:
        """
        Parse the configuration data into a dictionary.
        :param data: Configuration file content as a string
        :return: Parsed configuration as a dictionary
        """
        raise NotImplementedError("Subclasses should implement this method.")


class RawConfigParser(ConfigParser):
    """
    Parser for raw configuration files that do not require encoding.
    """
    @property
    def encoding(self):
        return False


class EncodingConfigParser(ConfigParser):
    """
    Parser for encoded configuration files that require encoding.
    """
    @property
    def encoding(self):
        return True


class YamlParser(EncodingConfigParser):
    """
    Parser for YAML configuration files.
    """

    def parse(self, data: str) -> dict:
        """
        Parse the YAML data into a dictionary.
        :param data: YAML file content
        :return: Parsed YAML data as a dictionary
        """
        return yaml.safe_load(data)


class TomlParser(EncodingConfigParser):
    """
    Parser for TOML configuration files (currently unsupported).
    """

    def parse(self, data: str) -> dict:
        """
        Parse the TOML data into a dictionary.
        :param data: TOML file content
        :return: Parsed TOML data as a dictionary (not implemented yet)
        """
        raise NotImplementedError("TOML parse is not yet implemented.")


class XmlParser(EncodingConfigParser):
    """
    Parser for XML configuration files.
    """

    def parse(self, data: str) -> dict:
        """
        Parse the XML data into a dictionary.
        :param data: XML file content
        :return: Parsed XML data as a dictionary
        """
        tree = ET.ElementTree(ET.fromstring(data))
        root = tree.getroot()
        return self._xml_to_dict(root)

    def _xml_to_dict(self, element) -> dict:
        """
        Convert XML elements to a nested dictionary structure.
        :param element: XML Element object
        :return: Nested dictionary representing the XML structure
        """
        result = {}
        for child in element:
            result[child.tag] = self._xml_to_dict(
                child) if len(child) > 0 else child.text
        return result


class ExcelParser(RawConfigParser):
    """
    Parser for Excel configuration files (XLSX format).
    """

    def parse(self, data: bytes) -> dict:
        """
        Parse the Excel data into a dictionary.
        :param data: Excel file content as bytes
        :return: Parsed Excel data as a dictionary
        """
        wb = openpyxl.load_workbook(data)
        return self._workbook_to_dict(wb)

    def _workbook_to_dict(self, wb: openpyxl.Workbook) -> dict:
        """
        Convert openpyxl Workbook to a nested dictionary structure.
        :param wb: openpyxl Workbook object
        :return: Nested dictionary representing the Excel file
        """
        result = {}
        for sheet in wb.sheetnames:
            result[sheet] = self._parse_sheet(wb[sheet])
        return result

    def _parse_sheet(self, ws):
        """
        Parse a sheet from the Excel workbook into a dictionary.
        :param ws: Worksheet object from openpyxl
        :return: List of dictionaries representing the sheet rows
        """
        # Read headers from the first row
        headers = [cell.value for cell in ws[1]]

        # Initialize a list to hold the data for this sheet
        data_list = []

        # Iterate through the rows (skip the header row)
        for row in ws.iter_rows(min_row=2, values_only=True):
            row_dict = {headers[i]: row[i] for i in range(len(headers))}
            data_list.append(row_dict)
        return data_list
