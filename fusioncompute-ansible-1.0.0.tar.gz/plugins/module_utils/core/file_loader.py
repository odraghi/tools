#!/usr/bin/env python
# -*- coding:utf-8 -*-
#  Copyright (c) Huawei Technologies Co., Ltd. 2024-2024. All rights reserved.
from http import HTTPStatus
import os
import requests
from urllib.parse import urlparse

from ansible_collections.huawei.fusioncompute.plugins.module_utils.core.nfs import mount_nfs, unmount_nfs


class FileLoader:
    @staticmethod
    def load_file(source: str, encoding=True) -> str | bytes:
        """
        Load the configuration file from various sources (local, NFS, HTTP).
        :param source: File path or URL
        :return: File content as a string
        """
        parsed_url = urlparse(source)

        if parsed_url.scheme == 'http' or parsed_url.scheme == 'https':
            return FileLoader._load_http(source, encoding)
        elif os.path.isfile(source):  # Local file
            return FileLoader._load_local(source, encoding)
        elif parsed_url.scheme == 'nfs':  # NFS
            return FileLoader._load_nfs(source, encoding)
        else:
            raise ValueError(f"Unsupported file source: {source}")

    @staticmethod
    def _load_local(source: str, encoding=True) -> str | bytes:
        """
        Load a file from the local filesystem.
        :param source: Path to the local file
        :return: File content as a string
        """
        try:
            with open(source, mode='r' if encoding else 'rb') as file:
                return file.read()
        except IOError:
            return None

    @staticmethod
    def _load_http(source: str, encoding=True) -> str:
        """
        Load a file from an HTTP or HTTPS URL.
        :param source: URL to the remote file
        :return: File content as a string
        """
        try:
            response = requests.get(source)
            if response.status_code != HTTPStatus.OK:
                return None
            return response.text if encoding else response.content
        except Exception as e:
            return None

    @staticmethod
    def _load_nfs(source: str, encoding=True) -> str:
        """
        Load a file from an NFS share.
        :param source: Path to the NFS file
        :return: File content as a string
        """
        mount_point = mount_nfs(source)
        if mount_point:
            # NFS is treated as local for simplicity
            content = FileLoader._load_local(mount_point, encoding)
            unmount_nfs(mount_point)
            return content
        else:
            return None
