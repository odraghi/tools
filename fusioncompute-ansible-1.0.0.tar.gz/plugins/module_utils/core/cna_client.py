#!/usr/bin/env python
# -*- coding:utf-8 -*-
#  Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.
from http import HTTPStatus
import ssl
import http.client
import json
from urllib.parse import urlparse
from ansible_collections.huawei.fusioncompute.plugins.module_utils.constants.http_constant import DEFAULT_CNA_PORT
from ansible_collections.huawei.fusioncompute.plugins.module_utils.core.fusincompute import logger
from ansible_collections.huawei.fusioncompute.plugins.module_utils.core.global_config import GlobalConfig


class CnaClient():
    def __init__(self, ip, ca_path, port=DEFAULT_CNA_PORT):
        """
        Initialize the CNA client with the target IP, port, and CA certificate path.

        :param ip: IP address of the CNA server
        :param ca_path: Path to the root CA certificate used for SSL verification
                        (path on CNA: /etc/galax/certs/nginx/rootCA.crt)
                        If set to None, certificate verification will be skipped only 
                        if ssl_force_verification is False; otherwise, an error will be raised.
        :param port: Port number of the CNA server (default is DEFAULT_CNA_PORT)
        """
        self.ip = ip
        self.ca_path = ca_path
        self.port = port
        if ca_path:
            # Use CA for verification
            context = ssl.create_default_context(cafile=ca_path)
            context.check_hostname = False  # Disable hostname validation
            context.verify_mode = ssl.CERT_REQUIRED
        else:
            global_config = GlobalConfig()
            is_force_verify = global_config.get(
                'ssl_force_verification', 'true') != 'false'
            if is_force_verify:
                err_msg = 'Must give valid certifacte path.'
                logger.error(err_msg)
                raise ValueError(err_msg)
            # Skip all certificate verification
            context = ssl._create_unverified_context()
            context.check_hostname = False
            context.verify_mode = ssl.CERT_NONE

        # Create an HTTPS connection to the CNA server
        self.conn = http.client.HTTPSConnection(ip, port=port, context=context)

    def __enter__(self):
        """Support use with 'with' statement."""
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        """Automatically close the connection when leaving 'with' block."""
        self.close()

    def close(self):
        self.conn.close()

    @property
    def prefix(self):
        """
        Authenticate or connect to the CNA node.

        Sends a GET request to the authentication endpoint.

        :return: HTTP response object
        """
        return 'https://{}:{}'.format(self.ip, self.port)

    def auth_node(self):
        """
        Authenticate or connect to the CNA node.

        Sends a GET request to the authentication endpoint.

        :return: HTTP response object
        """
        auth_url = '/api/?language=en-US'
        payload = {}
        headers = {
            'Content-Type': 'application/json'
        }
        self.conn.request("GET", auth_url, body=json.dumps(
            payload), headers=headers)
        rsp = self.conn.getresponse()
        return rsp, rsp.read().decode()

    def auth_template(self, auth_token):
        template_url = '/api/template?language=en-US'
        payload = {}
        headers = {
            'Accept': 'application/json;version=8.0',
            'X-Auth-Token': auth_token,
            'Content-Type': 'application/json',
        }
        self.conn.request("GET", template_url, body=json.dumps(
            payload), headers=headers)
        rsp = self.conn.getresponse()
        return rsp, rsp.read().decode()

    @staticmethod
    def truncate_url(full_url):
        parsed = urlparse(full_url)
        url = parsed.path
        if parsed.query:
            url += f'?{parsed.query}'
        return url

    def upload_ds_file_chunk(self, upload_url, headers, data):
        url = self.truncate_url(upload_url)
        self.conn.request('POST', url, body=data, headers=headers)
        rsp = self.conn.getresponse()
        return rsp, rsp.read().decode()

    @staticmethod
    def generate_chunks(file_path, lease_id, chunk_size, context, update_lease_fn):
        with open(file_path, 'rb') as f:
            while True:
                chunk = f.read(chunk_size)
                if not chunk:
                    logger.debug('chunk empty, break')
                    break
                context['uploaded_size'] += len(chunk)
                yield chunk
                # Log progress and update lease
                progress = (context['uploaded_size'] /
                            context['total_size']) * 100
                logger.debug('update progress: %s', progress)
                ret, rsp = update_lease_fn(lease_id, progress)
                logger.debug('update lease, result: %s', ret)

    def upload_template_file(self, vol_uuid, file_path, context, update_lease_fn, complete_lease_fn):
        url_path = f"/vna-api/1.0/volumes/upload_template_file?urlPostfix={vol_uuid}"
        auth_token = context['auth_token']
        lease_id = context['lease_id']
        chunk_size = context['chunk_size']
        total_size = context['total_size']
        uploaded_size = 0

        headers = {
            'Content-Type': 'application/octet-stream; charset=UTF-8',
            'Accept': '*/*;version=<version>; charset=UTF-8',
            'X-Auth-Token': auth_token,
            'Accept-Language': 'en-US',
        }

        def file_chunk_generator():
            nonlocal uploaded_size
            with open(file_path, 'rb') as f:
                while True:
                    chunk = f.read(chunk_size)
                    if not chunk:
                        break
                    uploaded_size += len(chunk)
                    context['uploaded_size'] = uploaded_size
                    progress = (uploaded_size / total_size) * 100
                    logger.debug('Uploaded %d/%d bytes (%.2f%%)', uploaded_size, total_size, progress)

                    ret, rsp = update_lease_fn(lease_id, progress)
                    logger.debug('Update lease, result: %s', ret)

                    yield chunk

        self.conn.request("POST", url_path, body=file_chunk_generator(), headers=headers, encode_chunked=True)
        response = self.conn.getresponse()
        response_data = response.read().decode()

        if response.status != HTTPStatus.OK:
            logger.error('Failed to upload file. Status: %s, Body: %s', response.status, response_data)
            return HTTPStatus.INTERNAL_SERVER_ERROR

        if uploaded_size == total_size:
            ret, rsp = complete_lease_fn(lease_id)
            logger.debug('Complete lease, ret: %s, rsp: %s', ret, rsp)

        return HTTPStatus.OK

