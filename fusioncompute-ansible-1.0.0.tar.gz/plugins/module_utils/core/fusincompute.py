#!/usr/bin/env python
# -*- coding:utf-8 -*-
#  Copyright (c) Huawei Technologies Co., Ltd. 2024-2024. All rights reserved.
from abc import ABC, abstractmethod
from copy import deepcopy
from http import HTTPStatus
import logging
import json
import os
import time
import requests

from ansible_collections.huawei.fusioncompute.plugins.module_utils.constants.http_constant import DEFAULT_INTERVAL, \
    DEFAULT_LANGUAGE, DEFAULT_MAX_RETRY_TIMES, DEFAULT_TIMEOUT, DEFAULT_VRM_PORT, \
    DEFAULT_ENCRIPT_ALGORITHM, FC_COMMON_URL_PREFIX, INTERFACE_USER_TYPE, DEFAULT_CONFIGS
from ansible_collections.huawei.fusioncompute.plugins.module_utils.constants.logger_constant \
    import DEFAULT_MODULE_LOG_FILE_PERMISSION, DEFAULT_MODULE_LOG_ROTATION_INTERVAL, \
    DEFAULT_MODULE_LOG_ROTATION_WHEN, DEFAULT_MODULE_LOG_BACKUP_COUNT, \
    DEFAULT_MODULE_LOG_FILE_PATH, DEFAULT_MODULE_LOG_FORMAT, \
    DEFAULT_MODULE_LOG_LEVEL, DEFAULT_MODULE_LOG_DIR_PERMISSION
from ansible_collections.huawei.fusioncompute.plugins.module_utils.entity.enum.basic import RestfulReqType
from ansible_collections.huawei.fusioncompute.plugins.module_utils.core.parameter_normalization \
    import mask_sensitive_field
from ansible_collections.huawei.fusioncompute.plugins.module_utils.core.global_config import GlobalConfig
from ansible_collections.huawei.fusioncompute.plugins.module_utils.core.log_handler import SafeTimedRotatingFileHandler


class FcUrlGenerator():
    def __init__(self, fc_hostname, port=DEFAULT_VRM_PORT):
        self.prefix = FC_COMMON_URL_PREFIX.format(fc_hostname, port)

    @property
    def site(self):
        return f'{self.prefix}/sites'

    @property
    def session(self):
        return f'{self.prefix}/session'

    def base_url(self, site_id):
        return f'{self.prefix}/sites/{site_id}'

    def advanced_config(self, site_id):
        return f'{self.prefix}/sites/{site_id}/advancedconfig'

    def vms(self, site_id, vm_id=None):
        return f'{self.prefix}/sites/{site_id}/vms' +\
            (f'/{vm_id}' if vm_id else '')

    def vms_import(self, site_id):
        return f'{self.prefix}/sites/{site_id}/vms/action/import'

    def vms_export(self, site_id, vm_id):
        return f'{self.prefix}/sites/{site_id}/vms/{vm_id}/action/export'

    def vms_clone(self, site_id, vm_id):
        return f'{self.prefix}/sites/{site_id}/vms/{vm_id}/action/clone'

    def vms_register(self, site_id):
        return f'{self.prefix}/sites/{site_id}/vms/action/register'

    def vms_start(self, site_id, vm_id):
        return f'{self.prefix}/sites/{site_id}/vms/{vm_id}/action/start'

    def vms_stop(self, site_id, vm_id):
        return f'{self.prefix}/sites/{site_id}/vms/{vm_id}/action/stop'

    def vms_restart(self, site_id, vm_id):
        return f'{self.prefix}/sites/{site_id}/vms/{vm_id}/action/reboot'

    def vms_migrate_host(self, site_id, vm_id):
        return f'{self.prefix}/sites/{site_id}/vms/{vm_id}/action/migrate'

    def vms_migrate_full(self, site_id, vm_id):
        return f'{self.prefix}/sites/{site_id}/vms/{vm_id}/action/hostAndStorageMigrate'

    def vms_migrate_storage(self, site_id, vm_id):
        return f'{self.prefix}/sites/{site_id}/vms/{vm_id}/action/migratevol'

    def vms_hibernate(self, site_id, vm_id):
        return f'{self.prefix}/sites/{site_id}/vms/{vm_id}/action/hibernate'

    def vms_query(self, site_id, vm_id, show_disk_details=False):
        return f'{self.prefix}/sites/{site_id}/vms/{vm_id}' +\
            ('?listAllDisksStatus=1' if show_disk_details else '')

    def vms_custom_attr(self, site_id, vm_id):
        return f'{self.prefix}/sites/{site_id}/vms/{vm_id}/customproperties'

    def vm_batch_deletion(self, site_id):
        return f'{self.prefix}/sites/{site_id}/vms/action/multi-delete'

    def vm_vcpu_bind(self, site_id, vm_id):
        return f'{self.prefix}/sites/{site_id}/vms/{vm_id}/action/vcpupin'

    def vm_cdrom(self, site_id, vm_id, is_mount: bool):
        return f'{self.prefix}/sites/{site_id}/vms/{vm_id}/action/'+('attachCdrom' if is_mount else 'detachCdrom')

    def os_query(self, site_id, os_id):
        return f'{self.prefix}/sites/{site_id}/vms/osversions'+(f'/{os_id}' if os_id else '')

    def vm_vol_create_attach(self, site_id, vm_id):
        return f'{self.prefix}/sites/{site_id}/vms/{vm_id}/action/createattachvol'

    def vm_vol_attach(self, site_id, vm_id):
        return f'{self.prefix}/sites/{site_id}/vms/{vm_id}/action/attachvol'

    def vm_vmtools(self, site_id, vm_id, is_mount: bool):
        return f'{self.prefix}/sites/{site_id}/vms/{vm_id}/action/' + \
            ('installtools' if is_mount else 'uninstalltools')

    def vm_vol_io_mode(self, site_id, vm_id):
        return f'{self.prefix}/sites/{site_id}/vms/{vm_id}/action/ioMode'

    def vm_vol_detach(self, site_id, vm_id):
        return f'{self.prefix}/sites/{site_id}/vms/{vm_id}/action/detachvol'

    def pcis(self, site_id, vm_id, pci_id, is_format=False):
        if pci_id:
            return f'{self.prefix}/sites/{site_id}/vms/{vm_id}/pcis/{pci_id}' +\
                ('?format=true' if is_format else '')
        else:
            return f'{self.prefix}/sites/{site_id}/vms/{vm_id}/pcis'

    def vm_bind_host(self, site_id, vm_id):
        return f'{self.prefix}/sites/{site_id}/vms/{vm_id}/action/bindHost'

    def vm_virtual_nics(self, site_id, vm_id, nic_id=None):
        return f'{self.prefix}/sites/{site_id}/vms/{vm_id}/virtualNics'+(f'/{nic_id}' if nic_id else '')

    def vm_virtual_nics_link(self, site_id, vm_id):
        return f'{self.prefix}/sites/{site_id}/vms/{vm_id}/virtualNics/link-status'

    def vm_nics(self, site_id, vm_id, nic_id):
        return f'{self.prefix}/sites/{site_id}/vms/{vm_id}/nics/{nic_id}'

    def vm_nics_network(self, site_id, vm_id, nic_id):
        return f'{self.prefix}/sites/{site_id}/vms/{vm_id}/nics/{nic_id}/network-info'

    def vm_nics_sg(self, site_id, vm_id, nic_id):
        return f'{self.prefix}/sites/{site_id}/vms/{vm_id}/nics/{nic_id}/securitygroup'

    def vm_nics_pg(self, site_id, vm_id, nic_id):
        return f'{self.prefix}/sites/{site_id}/vms/{vm_id}/nics/{nic_id}/portGroup'

    def vm_attr_spec(self, site_id, spec_id=None):
        return f'{self.prefix}/sites/{site_id}/vmcustomizations' +\
            ('' if spec_id is None else f'/{spec_id}')

    def vm_set_password(self, site_id, vm_id):
        return f'{self.prefix}/sites/{site_id}/vms/{vm_id}/action/changePassword'

    def vm_set_vnc_password(self, site_id, vm_id):
        return f'{self.prefix}/sites/{site_id}/vms/{vm_id}/action/resetvnc'

    def task(self, site_id, task_id=None):
        return f'{self.prefix}/sites/{site_id}/tasks' +\
            (f'/{task_id}' if task_id else '')

    def task_cancel(self, site_id, task_id):
        return f'{self.prefix}/sites/{site_id}/tasks/{task_id}/cancel'

    def vm_create_sg(self, site_id):
        return f'{self.prefix}/sites/{site_id}/securitygroups/addsecuritygroup'

    def vm_delete_sg(self, site_id):
        return f'{self.prefix}/sites/{site_id}/securitygroups/deletesecuritygroup'

    def vm_modify_sg(self, site_id, sg_id):
        return f'{self.prefix}/sites/{site_id}/securitygroups/{sg_id}'

    def vm_pagination_sg(self, site_id):
        return f'{self.prefix}/sites/{site_id}/securitygroups'

    def vm_create_sg_rule(self, site_id, sg_id):
        return f'{self.prefix}/sites/{site_id}/securitygroups/{sg_id}/action/addrules'

    def vm_pagination_sg_rule(self, site_id, sg_id):
        return f'{self.prefix}/sites/{site_id}/securitygroups/{sg_id}/action/rules'

    def vm_delete_sg_rule(self, site_id, sg_id):
        return f'{self.prefix}/sites/{site_id}/securitygroups/{sg_id}/action/delrules'

    def generic_url(self, url, site_id):
        if site_id:
            return f'{self.prefix}/sites/{site_id}{url}'
        else:
            return f'{self.prefix}{url}'

    def lease_url(self, site_id, lease_id):
        return f'{self.prefix}/sites/{site_id}/serverlease/{lease_id}'

    def lease_complete_url(self, site_id, lease_id):
        return f'{self.prefix}/sites/{site_id}/serverlease/{lease_id}/action/complete'
    
    def ds_apply_upload(self, site_id, ds_id):
        return f'{self.prefix}/sites/{site_id}/datastores/{ds_id}/applyUpload'

    def ds_file(self, site_id, ds_id, file_id=None):
        return f'{self.prefix}/sites/{site_id}/datastores/{ds_id}/file' +\
            (f'/{file_id}' if file_id else '')

    def folder_url(self, site_id, folder_id=None):
        return f'{self.prefix}/sites/{site_id}/folder' +\
            (f'/{folder_id}' if folder_id else '')

    def folder_move_url(self, site_id):
        return f'{self.prefix}/sites/{site_id}/folder/action/move-into-folder'

    def folder_resource_url(self, site_id, folder_id):
        return f'{self.prefix}/sites/{site_id}/folder/{folder_id}/resource'

    def folder_topo_url(self, site_id, folder_id):
        return f'{self.prefix}/sites/{site_id}/folder/{folder_id}/queryFolderTopology'


class RestfulRequestClient:
    def __init__(self, verify: bool | str):
        self.verify = verify

    def request(self, method: RestfulReqType, url: str, fc_headers, data=None, ret_headers=False) \
            -> tuple[HTTPStatus, any]:
        for key, value in fc_headers.items():
            if not isinstance(value, str):
                fc_headers[key] = str(value)
        logger.debug(
            "Restful reqeust: [%s %s], [headers: %s], [body: %s]",
            method.value.upper(), url,
            mask_sensitive_field(fc_headers),
            mask_sensitive_field(data)
        )
        response = requests.request(
            method.value, url, verify=self.verify, headers=fc_headers, json=data)
        content = response.content
        if isinstance(content, bytes):
            content = content.decode()
            try:
                content = json.loads(content)
            except ValueError:
                pass
        logger.debug("Restful response: %s",
                     mask_sensitive_field(content) if isinstance(content, dict) else content)
        ret = response.status_code
        if ret != HTTPStatus.OK:
            return ret, response
        try:
            rsp: dict = response.json()
            if ret_headers:
                rsp.update(**response.headers)
            return response.status_code, rsp
        except requests.JSONDecodeError:
            return ret, response.text

    def get(self, url, params: dict = None, fc_headers=None):
        if params:
            parms_str = '&'.join([f'{k}={v}' for k, v in params.items()])
            url = f'{url}?{parms_str}'
        return self.request(RestfulReqType.get, url, fc_headers)

    def delete(self, url, params: dict = None, fc_headers=None):
        if params:
            parms_str = '&'.join([f'{k}={v}' for k, v in params.items()])
            url = f'{url}?{parms_str}'
        return self.request(RestfulReqType.delete, url, fc_headers)

    def post(self, url, data, fc_headers, ret_headers=False):
        return self.request(RestfulReqType.post, url, fc_headers, data, ret_headers)

    def put(self, url, data, fc_headers):
        return self.request(RestfulReqType.put, url, fc_headers, data)


class FcHttpBase(ABC):
    def __init__(self, fc_hostname: str, port=DEFAULT_VRM_PORT, language=DEFAULT_LANGUAGE, verify: bool | str = False):
        self.fc_hostname = fc_hostname
        self.port = port
        self.language = language
        self.fc_headers = {
            'Accept': 'application/json;version=8.0',
            'Content-Type': 'application/json',
            'Accept-Language': language.value,
        }
        self.connection = RestfulRequestClient(verify)
        self.url_generator = FcUrlGenerator(fc_hostname, port)
        self.username = None
        self.password = None
        self._site_id = None

    @property
    def fc_token(self):
        return self.fc_headers['X-Auth-Token']

    def set_auth_token(self, token):
        self.fc_headers['X-Auth-Token'] = token
        return HTTPStatus.INTERNAL_SERVER_ERROR if self.site_id is None else HTTPStatus.OK

    def login(self, username, password):
        self.username = username
        self.password = password
        ret = self.update_auth_token()
        if ret != HTTPStatus.OK:
            return ret
        return HTTPStatus.INTERNAL_SERVER_ERROR if self.site_id is None else HTTPStatus.OK

    def update_auth_token(self):
        if self.username is None:
            return HTTPStatus.INTERNAL_SERVER_ERROR
        fc_headers = deepcopy(self.fc_headers)
        fc_headers['X-ENCRIPT-ALGORITHM'] = DEFAULT_ENCRIPT_ALGORITHM
        fc_headers['X-Auth-UserType'] = INTERFACE_USER_TYPE
        fc_headers['X-Auth-User'] = self.username
        fc_headers['X-Auth-Key'] = self.password
        ret, rsp = self.connection.post(
            self.url_generator.session, data=None, fc_headers=fc_headers, ret_headers=True)
        token = rsp['X-Auth-Token'] if ret == HTTPStatus.OK else None
        self.fc_headers['X-Auth-Token'] = token
        return ret

    @property
    def site_id(self) -> str:
        if self._site_id is not None:
            return self._site_id
        ret, site_rsp = self.connection.get(
            self.url_generator.site, fc_headers=self.fc_headers)
        if ret != HTTPStatus.OK:
            return ''
        for site in site_rsp['sites']:
            if site['isSelf']:
                self._site_id = site['urn'].split(':')[-1]
                return self._site_id or ''
        return ''

    @site_id.setter
    def site_id(self, value):
        self._site_id = value

    def logout(self):
        ret, _ = self.connection.delete(
            self.url_generator.session, fc_headers=self.fc_headers)
        del self.fc_headers['X-Auth-Token']
        logger.debug('Invalidate auth token in environment.')
        os.environ.pop('FUSIONCOMPUTE_TOKEN', None)
        return ret

    @abstractmethod
    def get(self, url, params=None) -> tuple[HTTPStatus, any]:
        pass

    @abstractmethod
    def delete(self, url, params=None) -> tuple[HTTPStatus, any]:
        pass

    @abstractmethod
    def post(self, url, data) -> tuple[HTTPStatus, any]:
        pass

    @abstractmethod
    def put(self, url, data) -> tuple[HTTPStatus, any]:
        pass


class DefaultPolicy():
    def __init__(self, configs: dict):
        if configs is None:
            configs = {}
        self.max_retry_times = configs.get(
            'max_retry_times', DEFAULT_MAX_RETRY_TIMES)
        self.interval = configs.get('interval', DEFAULT_INTERVAL)
        self.timeout = configs.get(
            'timeout', DEFAULT_TIMEOUT)

    def apply(self, obj: FcHttpBase, method_type: RestfulReqType, *args, **kwargs):
        method = getattr(obj.connection, method_type.name)
        for _ in range(self.max_retry_times):
            ret, rsp = method(*args, obj.fc_headers, **kwargs)
            if ret == HTTPStatus.OK:
                return ret, rsp
            elif ret == HTTPStatus.UNAUTHORIZED:
                if obj.username is None:
                    return HTTPStatus.INTERNAL_SERVER_ERROR, None
                if obj.update_auth_token() != HTTPStatus.OK:
                    time.sleep(self.interval)
                continue
            else:
                return ret, rsp
        return HTTPStatus.INTERNAL_SERVER_ERROR, None


class DefaultFcHttpClient(FcHttpBase):
    def __init__(self, fc_hostname: str, port=DEFAULT_VRM_PORT, language=DEFAULT_LANGUAGE,
                 verify: bool | str = False, configs: dict[str, any] = DEFAULT_CONFIGS):
        super().__init__(fc_hostname, port, language, verify)
        self.policy = DefaultPolicy(configs)

    def get(self, url, params=None):
        return self.policy.apply(self, RestfulReqType.get, url, params)

    def delete(self, url, params=None):
        return self.policy.apply(self, RestfulReqType.delete, url, params)

    def post(self, url, data):
        return self.policy.apply(self, RestfulReqType.post, url, data)

    def put(self, url, data):
        return self.policy.apply(self, RestfulReqType.put, url, data)


def setup_logging():
    global_config = GlobalConfig()
    # logger configuration
    safe_logger = logging.getLogger('ansible_module_logger')
    logger_level_dict = logging.getLevelNamesMapping()
    logger_level = logger_level_dict.get(global_config.get(
        'log_module_level'))
    safe_logger.setLevel(logger_level)
    formatter = logging.Formatter(global_config.get(
        'log_module_format', DEFAULT_MODULE_LOG_FORMAT))
    log_rotation_interval = int(global_config.get(
        'log_rotation_interval', DEFAULT_MODULE_LOG_ROTATION_INTERVAL))
    log_rotation_when = global_config.get(
        'log_rotation_when', DEFAULT_MODULE_LOG_ROTATION_WHEN)
    log_backup_count = int(global_config.get(
        'log_backup_count', DEFAULT_MODULE_LOG_BACKUP_COUNT))
    log_file = global_config.get(
        'log_module_file_path', DEFAULT_MODULE_LOG_FILE_PATH)
    log_dir = os.path.dirname(log_file)
    if not os.path.exists(log_dir):
        os.makedirs(log_dir, mode=DEFAULT_MODULE_LOG_DIR_PERMISSION)
    handler = SafeTimedRotatingFileHandler(
        log_file, when=log_rotation_when, interval=log_rotation_interval, backupCount=log_backup_count)
    handler.setFormatter(formatter)
    safe_logger.addHandler(handler)
    os.chmod(log_file, DEFAULT_MODULE_LOG_FILE_PERMISSION)
    return safe_logger


# Setup logger
logger = setup_logging()
logger.debug("Logging setup completed.")
