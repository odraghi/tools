#!/usr/bin/env python
# -*- coding:utf-8 -*-
#  Copyright (c) Huawei Technologies Co., Ltd. 2024-2024. All rights reserved.

from abc import ABC, abstractmethod
from io import BytesIO
import yaml
import xml.etree.ElementTree as ET

from ansible_collections.huawei.fusioncompute.plugins.module_utils.core.file_loader import FileLoader
from ansible_collections.huawei.fusioncompute.plugins.module_utils.core.file_exporter import FileExporter


class DataExporter(ABC):
    @property
    @abstractmethod
    def encoding(self):
        """
        Abstract property to define encoding behavior.
        Subclasses must implement this property to return encoding type.
        """
        raise NotImplementedError(
            "Subclasses of DataExporter should implement encoding.")

    def _save_file(self, destination: str, content: str | bytes) -> bool:
        """
        Save the content to the specified destination (file, URL, etc.).

        :param destination: Path or URL where the content should be saved
        :param content: Content to be saved (string or bytes)
        :return: True if the file was saved successfully, False otherwise
        """
        return FileExporter.save_file(destination, content, encoding=self.encoding)

    @abstractmethod
    def encode(self, data: dict) -> str | bytes:
        """
        Encode the given data (dictionary) into the required format (e.g., YAML, XML, etc.).

        :param data: Dictionary containing the data to be encoded
        :return: Encoded data in the specified format (string or bytes)
        """
        raise NotImplementedError("Subclasses should implement this method.")

    def save(self, destination: str, data: dict) -> bool:
        """
        Encode the given data and save it to the specified destination.

        :param destination: Path or URL where the encoded data should be saved
        :param data: Dictionary containing the data to be saved
        :return: True if the data was successfully saved, False otherwise
        """
        content = self.encode(data)
        return self._save_file(destination, content)


class RawDataExporter(DataExporter):
    @property
    def encoding(self):
        """
        Return encoding type for raw data exporter (False for no encoding).
        """
        return False


class EncodingDataExporter(DataExporter):
    @property
    def encoding(self):
        """
        Return encoding type for encoding data exporter (True for encoding).
        """
        return True


class YamlExporter(EncodingDataExporter):
    def encode(self, data: dict) -> str:
        """
        Encode the given dictionary into YAML format.

        :param data: Dictionary to be converted to YAML
        :return: YAML formatted string
        """
        return yaml.safe_dump(data)


class TomlExporter(EncodingDataExporter):
    def encode(self, data: dict) -> str:
        """
        Encode the given dictionary into TOML format.

        :param data: Dictionary to be converted to TOML
        :return: TOML formatted string (currently disabled)
        """
        raise NotImplementedError("TOML encoding is not yet implemented.")


class XmlExporter(EncodingDataExporter):
    def encode(self, data: dict) -> str:
        """
        Encode the given dictionary into XML format.

        :param data: Dictionary to be converted to XML
        :return: XML formatted string
        """
        # Convert the dictionary to an XML string
        root = self.dict_to_xml('person', data)

        # Convert the ElementTree to a string and return it
        xml_str = ET.tostring(root, encoding='utf-8', method='xml')
        return xml_str

    @staticmethod
    def dict_to_xml(tag, d):
        """
        Recursively convert a dictionary to an XML string.

        :param tag: The name of the root element
        :param d: The dictionary to convert
        :return: An Element object representing the XML structure
        """
        elem = ET.Element(tag)

        # Iterate over dictionary items
        for key, value in d.items():
            # If value is a dictionary, recursively call dict_to_xml
            if isinstance(value, dict):
                elem.append(XmlExporter.dict_to_xml(key, value))
            elif isinstance(value, list):
                for item in value:
                    elem.append(XmlExporter.dict_to_xml(key, {key: item}))
            else:
                child = ET.Element(key)
                child.text = str(value)
                elem.append(child)

        return elem


class ExcelExporter(RawDataExporter):
    def encode(self, data: dict) -> bytes:
        """
        Generate an Excel file from the given dictionary and return it as raw bytes.

        :param data: Dictionary to be converted into an Excel file
        :return: Raw bytes representing the generated Excel file
        """
        import openpyxl

        wb = openpyxl.Workbook()

        # Remove the default "Sheet" created by openpyxl (if it exists)
        if 'Sheet' in wb.sheetnames:
            wb.remove(wb['Sheet'])

        # Iterate over the dictionary and create a sheet for each key (sheet name)
        for sheet_name, sheet_data in data.items():
            ws = wb.create_sheet(title=sheet_name)

            # If sheet_data is a list of dictionaries, write headers from the keys of the first dict
            if sheet_data:
                # Extract the keys from the first dictionary
                headers = sheet_data[0].keys()
                ws.append(headers)  # Write headers as the first row

                # Write each row of data
                for row in sheet_data:
                    ws.append([row[col] for col in headers])

        # Save the workbook to a BytesIO object (in-memory buffer)
        excel_stream = BytesIO()
        wb.save(excel_stream)

        # Get the raw bytes from the BytesIO object and return it
        return excel_stream.getvalue()
