#!/usr/bin/env python
# -*- coding:utf-8 -*-
#  Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.
import configparser
import os


from ansible_collections.huawei.fusioncompute.plugins.module_utils.constants.logger_constant \
    import DEFAULT_MODULE_LOG_ROTATION_INTERVAL, DEFAULT_MODULE_LOG_ROTATION_WHEN, DEFAULT_MODULE_LOG_BACKUP_COUNT, \
    DEFAULT_MODULE_LOG_FILE_PATH, DEFAULT_MODULE_LOG_FORMAT, \
    DEFAULT_MODULE_LOG_LEVEL, DEFAULT_MODULE_LOG_MAX_FILE_SIZE
from ansible_collections.huawei.fusioncompute.plugins.module_utils.constants.http_constant import DEFAULT_LANGUAGE
from ansible_collections.huawei.fusioncompute.plugins.module_utils.constants.basic import DEFAULT_CONFIG_PATH


class GlobalConfig:
    __supported_sections = ('fusioncompute', 'ssl', 'log')
    _instance = None  # Singleton instance
    _default_config = {
        'fc_language': DEFAULT_LANGUAGE,
        'ssl_force_verification': True,
        'ssl_ca_cert_path': '',
        'log_module_level': DEFAULT_MODULE_LOG_LEVEL,
        'log_module_format': DEFAULT_MODULE_LOG_FORMAT,
        'log_module_file_path': DEFAULT_MODULE_LOG_FILE_PATH,
        'log_rotation_when': DEFAULT_MODULE_LOG_ROTATION_WHEN,
        'log_rotation_interval': DEFAULT_MODULE_LOG_ROTATION_INTERVAL,
        'log_backup_count': DEFAULT_MODULE_LOG_BACKUP_COUNT,
        'log_max_file_size': DEFAULT_MODULE_LOG_MAX_FILE_SIZE,
    }
    _config = None

    def __new__(cls):
        if cls._instance is None:
            config_path = DEFAULT_CONFIG_PATH
            cls._instance = super(GlobalConfig, cls).__new__(cls)
            cls._instance._load_config(config_path)
        return cls._instance

    def _load_config(self, config_file):
        """
        Load configuration from the specified INI file.
        If the file does not exist or cannot be parsed, use the default configuration.
        """
        self._config = self._default_config.copy()
        if os.path.exists(config_file):
            config_parser = configparser.ConfigParser()
            try:
                config_parser.read(config_file, encoding="utf-8")
                for section in self.__supported_sections:
                    if section in config_parser:
                        self._config.update(config_parser[section])
            except (configparser.Error, IOError) as e:
                raise e

    def get(self, key, default=None):
        """Retrieve a configuration value by key. Returns the default value if the key is not found."""
        return self._config.get(key, default)
