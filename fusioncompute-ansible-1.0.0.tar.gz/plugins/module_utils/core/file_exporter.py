#!/usr/bin/env python
# -*- coding:utf-8 -*-
#  Copyright (c) Huawei Technologies Co., Ltd. 2024-2024. All rights reserved.

import os
import requests
from urllib.parse import urlparse
from ansible_collections.huawei.fusioncompute.plugins.module_utils.core.nfs import mount_nfs, unmount_nfs


class FileExporter:
    @staticmethod
    def save_file(destination: str, content: str | bytes, encoding=True) -> bool:
        """
        Save the given content to a destination (local file, HTTP/HTTPS URL, or NFS share).

        :param destination: The destination to save the file to, can be a local path, HTTP(S) URL, or NFS path.
        :param content: The content to save, either a string (for text) or bytes (for binary data).
        :param encoding: Whether to encode the content (default is True, for text files).
        :return: True if the content was successfully saved, False otherwise.
        """
        parsed_url = urlparse(destination)

        # Determine the scheme (protocol) used in the destination URL and call appropriate method
        # If the destination is HTTP or HTTPS
        if parsed_url.scheme in ['http', 'https']:
            return FileExporter._save_http(destination, content, encoding)
        elif parsed_url.scheme in ['file', '']:  # Local file
            return FileExporter._save_local(destination, content, encoding)
        elif parsed_url.scheme == 'nfs':  # NFS share
            return FileExporter._save_nfs(destination, content, encoding)
        else:
            # If the scheme is unsupported, raise an error
            raise ValueError(f"Unsupported file source: {destination}")

    @staticmethod
    def _save_local(destination: str, content: str | bytes, encoding=True) -> bool:
        """
        Save content to a local file on the filesystem.

        :param destination: Path to the local file to save the content to.
        :param content: The content to save, either a string or bytes.
        :param encoding: Whether to write the content as text (default is True).
        :return: True if the file was successfully written, False otherwise.
        """
        try:
            # Ensure the directory exists
            if not os.path.exists(destination):
                # Create the directory if it doesn't exist
                os.makedirs(destination)
            # Write the content to the file
            with open(destination, mode='w' if encoding else 'wb') as f:
                # Check if content was written completely
                return f.write(content) == len(content)
        except IOError:
            # If any IOError occurs (e.g., permissions issue), return False
            return False

    @staticmethod
    def _save_http(destination: str, content: str | bytes, encoding=True) -> bool:
        """
        Save content to a remote HTTP or HTTPS server via PUT request.

        :param destination: The URL to which the content will be sent.
        :param content: The content to send, either a string or bytes.
        :param encoding: Whether to encode the content (default is True).
        :return: True if the content was successfully uploaded (status code 200), False otherwise.
        """
        try:
            # Send a PUT request to upload the content to the specified destination
            response = requests.put(destination, data=content)
            return response.status_code == 200  # Check if upload was successful
        except Exception:
            # If an exception occurs (e.g., connection failure), return False
            return False

    @staticmethod
    def _save_nfs(destination: str, content: str | bytes, encoding=True) -> bool:
        """
        Save content to an NFS share by mounting the NFS, saving the file, and then unmounting.

        :param destination: The NFS path (e.g., 'nfs://ip/path/to/file').
        :param content: The content to save, either a string or bytes.
        :param encoding: Whether to encode the content (default is True).
        :return: True if the file was successfully saved to the NFS share, False otherwise.
        """
        # Mount the NFS share
        mount_point = mount_nfs(destination)
        if mount_point:
            # Save the file to the mounted NFS directory
            content_saved = FileExporter._save_local(
                mount_point, content, encoding)
            # Unmount the NFS share after saving
            unmount_nfs(mount_point)
            return content_saved  # Return the result of the local save operation
        return False  # Return False if the NFS mount failed
