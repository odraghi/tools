from typing import Callable

from ansible_collections.huawei.fusioncompute.plugins.module_utils.constants.logger_constant \
    import DEFAULT_SENSITIVE_FIELDS, DEFAULT_SENSITIVE_REPLACED_STRING


def do_filter(params: dict, filter_fn: Callable[[str], bool], replaced_str=DEFAULT_SENSITIVE_REPLACED_STRING):
    if not params:
        return params
    res = {}
    for k, v in params.items():
        if isinstance(v, dict):
            res[k] = do_filter(v, filter_fn)
            continue
        if isinstance(v, list):
            for i, element in enumerate(v):
                if isinstance(element, dict):
                    v[i] = do_filter(element, filter_fn)
        if filter_fn(k):
            res[k] = replaced_str
        else:
            res[k] = v
    return res


def normalize(params: dict):
    res = {}
    for k, v in params.items():
        if v is None:
            continue
        if isinstance(v, dict):
            res[k] = normalize(v)
            continue
        if isinstance(v, list):
            for i, element in enumerate(v):
                if isinstance(element, dict):
                    v[i] = normalize(element)
            res[k] = v
            continue
        res[k] = v
    return res


def mask_sensitive_field(params: dict, sensitive_fields=DEFAULT_SENSITIVE_FIELDS,
                         replaced_str=DEFAULT_SENSITIVE_REPLACED_STRING):
    return do_filter(params, filter_fn=contains_any_sensitive_string, replaced_str=replaced_str)


def contains_any_sensitive_string(a: str) -> bool:
    for substring in DEFAULT_SENSITIVE_FIELDS:
        if substring in a.lower() or substring == a.lower():
            return True
    return False
