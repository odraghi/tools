import base64
import os
import json
import yaml


def get_user(name, authorized_key):
    res = {
        "name": name
    }
    if authorized_key:
        res['sshAuthorizedKeys'] = [authorized_key]
    return res


def get_nic(ip, netmask, gateway, dns_servers):
    nic_config = NIC_CONFIG_TEMPLATE.replace('{{ip}}', ip).replace('{{netmask}}', netmask).replace(
        '{{gateway}}', gateway).replace('{{dns_servers}}', dns_servers)

    return {
        "path": "/etc/NetworkManager/system-connections/enp4s1.nmconnection",
        "mode": 384,
        "overwrite": True,
        "contents": {
            "source": "data:text/plain;charset=utf-8;base64,{}".format(base64.b64encode(nic_config.encode()).decode()),
            "human_read": nic_config
        }
    }


NIC_CONFIG_TEMPLATE = '''
[connection]
id=enp4s1
type=ethernet
interface-name=enp4s1

[ipv4]
dns-search=
method=manual
address1={{ip}}/{{netmask}},{{gateway}}
dns={{dns_servers}}
ignore_auto_dns=true

[ipv6]
dns-search=
addr-gen-mode=eui64
method=ignore
'''



def generate_ignition(input_file_path, output_file_path):
    configs = {}
    try:
        with open(input_file_path) as f:
            configs = yaml.safe_load(f)
        return generate_ignition_from_config(configs, output_file_path)
    except Exception as e:
        return None


def generate_ignition_from_config(ign_configs, output_file_path=None):
    ign_template = {
        "ignition": {
            "version": "3.2.0"
        },
        "passwd": {
            "users": [
            ]
        },
        "storage": {
            "files": [
                {
                    "path": "/etc/NetworkManager/conf.d/noauto.conf",
                    "mode": 420,
                    "overwrite": True,
                    "contents": {
                        "source": "data:text/plain;charset=utf-8;base64,"
                        "W21haW5dCiMgRG8gbm90IGRvIGF1dG9tYXRpYyAoREhDUC9"
                        "TTEFBQykgY29uZmlndXJhdGlvbiBvbiBldGhlcm5ldCBkZXZpY"
                        "2VzCiMgd2l0aCBubyBvdGhlciBtYXRjaGluZyBjb25uZWN0aW9ucy4Kbm8tYXV0by1kZWZhdWx0PSoK",
                        "human_read": "[main]\n# Do not do automatic (DHCP/SLAAC) configuration on ethernet devices\n"
                        "# with no other matching connections.\nno-auto-default=*\n"
                    }
                }
            ]
        }
    }
    for user in ign_configs['users']:
        ign_template['passwd']['users'].append(
            get_user(user['name'],
                     user.get('authorized_key', None)))
    ign_template['storage']['files'].insert(0, get_nic(
        ign_configs['ip'], str(ign_configs['netmask']
                               ), ign_configs['gateway'],
        ign_configs['dns_servers']))
    if output_file_path:
        with open(output_file_path, 'w') as f:
            json.dump(ign_template, f, indent=4)
    return ign_template


def get_all_users(ign: dict):
    original_usrs = ign.get('passwd', {}).get('users', [])
    res_map = {}
    for user in original_usrs:
        res_map[user['name']] = user
    return res_map


def get_host_name_file(ign: dict):
    host_name_file = '/etc/hostname'
    return get_file(ign, host_name_file)


def get_all_nic_files(ign: dict):
    nic_path_prefix = '/etc/NetworkManager/system-connections/'
    all_files = ign.get('storage', {}).get('files', [])
    all_nic_files = {}
    for file in all_files:
        if file['path'].startswith(nic_path_prefix):
            all_nic_files[file['path']] = file
    return all_nic_files


def get_file(ign: dict, file_name: str):
    all_files = ign.get('storage', {}).get('files', [])
    for file in all_files:
        if file['path'] == file_name:
            return file
    return None


def add_user(original_ign, new_user):
    if 'passwd' not in original_ign:
        original_ign['passwd'] = {}
    if 'users' not in original_ign['passwd']:
        original_ign['passwd']['users'] = []
    original_ign['passwd']['users'].append(new_user)


def add_file(original_ign: dict, file_item):
    if 'storage' not in original_ign:
        original_ign['storage'] = {}
    if 'files' not in original_ign['storage']:
        original_ign['storage']['files'] = []
    original_ign['storage']['files'].append(file_item)


def add_hostname(original_ign: dict, hostname):
    add_file(original_ign, hostname)


def add_nic(original_ign: dict, nic_file):
    add_file(original_ign, nic_file)


def merge_ignition(original_ign: dict, added_ign: dict, ignored_nic=True):
    original_usrs = get_all_users(original_ign)
    added_usrs = get_all_users(added_ign)
    for new_name, new_user in added_usrs.items():
        if new_name in original_usrs:
            continue
        add_user(original_ign, new_user)
    original_hostname = get_host_name_file(original_ign)
    added_hostname = get_host_name_file(added_ign)
    if added_hostname and original_hostname:
        return False
    if added_hostname:
        add_hostname(original_ign, added_hostname)
    if not ignored_nic:
        original_nic_files = get_all_nic_files(original_ign)
        added_nic_files = get_all_nic_files(added_ign)

        for nic_path, nic_item in added_nic_files.items():
            if nic_path in original_nic_files:
                return False
            add_nic(original_ign, nic_item)
    return True
