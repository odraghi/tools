#!/usr/bin/env python
# -*- coding:utf-8 -*-
#  Copyright (c) Huawei Technologies Co., Ltd. 2024-2024. All rights reserved.
import os
from ansible_collections.huawei.fusioncompute.plugins.module_utils.entity.enum.basic import EnvFallBackAction


class AnsibleFallbackNotFound(Exception):
    pass


def env_fallback(*args, **kwargs):
    if len(args) == 0:
        raise AnsibleFallbackNotFound
    default = args[0]
    ''' Load value from environment '''
    for arg in args[1:]:
        if arg in os.environ:
            return os.environ[arg]
    if not isinstance(default, EnvFallBackAction):
        return default
    match default:
        case EnvFallBackAction.no_throw:
            return None
        case EnvFallBackAction.do_throw:
            raise AnsibleFallbackNotFound
        case _:
            pass
