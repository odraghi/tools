#!/usr/bin/env python
# -*- coding:utf-8 -*-
#  Copyright (c) Huawei Technologies Co., Ltd. 2024-2024. All rights reserved.
import re


def hostname_validator_fn(target: str):
    return len(target) != 0


def all_digit_validator_fn(target: str):
    return re.match(r"\d+$", target)
