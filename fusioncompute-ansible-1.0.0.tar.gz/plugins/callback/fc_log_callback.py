#!/usr/bin/env python
# -*- coding:utf-8 -*-
#  Copyright (c) Huawei Technologies Co., Ltd. 2024-2024. All rights reserved.
import logging
import os
import inspect

from ansible_collections.huawei.fusioncompute.plugins.module_utils.constants.logger_constant \
    import DEFAULT_PLAYBOOK_LOG_FILE_PATH, DEFAULT_PLAYBOOK_LOG_LEVEL


class LogCallback:
    def __init__(self, log_file=DEFAULT_PLAYBOOK_LOG_FILE_PATH, log_level=DEFAULT_PLAYBOOK_LOG_LEVEL):
        """
        Initialize the logger
        :param log_file: Path to the log file, default is '/var/log/fusioncompute/ansible_playbook.log'
        :param log_level: Log level, default is logging.INFO
        """
        self.log_file = log_file
        self.log_level = log_level

        self.logger = logging.getLogger('ansible_callback_logger')
        self.logger.setLevel(self.log_level)

        file_handler = logging.FileHandler(self.log_file)
        formatter = logging.Formatter(
            '%(asctime)s - %(levelname)s - %(message)s - %(filename)s - %(lineno)d'
        )
        file_handler.setFormatter(formatter)
        self.logger.addHandler(file_handler)

        console_handler = logging.StreamHandler()
        console_handler.setFormatter(formatter)
        self.logger.addHandler(console_handler)

        self.logger.info(
            f"Logger initialized, log file: {self.log_file}, log level: {logging.getLevelName(self.log_level)}")

    def _log(self, message, level=logging.INFO):
        """
        Log a message
        :param message: The log message content
        :param level: The log level
        """
        frame = inspect.currentframe().f_back
        filename = os.path.basename(frame.f_globals["__file__"])
        lineno = frame.f_lineno
        self.logger.log(level, f"{message} - {filename} - {lineno}")

    def v2_playbook_on_start(self, playbook):
        """Log when the playbook starts"""
        self._log(f"Playbook {playbook.name} started execution")

    def v2_playbook_on_task_start(self, task, is_conditional):
        """Log when each task starts execution"""
        self._log(f"Task {task.name} started execution")

    def v2_on_any(self, result):
        """Log each module execution (success or failure)"""
        if result.is_failed():
            self._log(
                f"Task failed: {result.task_name}, Error: {result.result}", logging.ERROR)
        elif result.is_ok():
            self._log(
                f"Task succeeded: {result.task_name}, Result: {result.result}")

    def v2_playbook_on_end(self):
        """Log when the playbook ends"""
        self._log("Playbook execution completed")
