#!/usr/bin/env python
# -*- coding:utf-8 -*-
#  Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.
from http import HTTPStatus
import json
import os
import ssl
import tempfile
import time
from urllib.parse import ParseResult, urlparse
import importlib
import requests

from ansible.module_utils.basic import AnsibleModule
from ansible_collections.huawei.fusioncompute.plugins.module_utils.core.fusincompute import logger
from ansible_collections.huawei.fusioncompute.plugins.module_utils.param_validator import hostname_validator_fn
from ansible_collections.huawei.fusioncompute.plugins.module_utils.decorator import validator_injector
from ansible_collections.huawei.fusioncompute.plugins.module_utils.basic import FcAttrValidator, FcModuleBase
from ansible_collections.huawei.fusioncompute.plugins.module_utils.core.cna_client import CnaClient
from ansible_collections.huawei.fusioncompute.plugins.module_utils.core.global_config import GlobalConfig

ANSIBLE_METADATA = {
    'metadata_version': '1.0.1',
    'status': ['preview'],
    'supported_by': 'huawei'
}

DOCUMENTATION = '''
---
module: huawei.fusioncompute.fc_vm_http_import

short_description: Module for importing a virtual machine (VM) using the HTTP(S) protocol in Huawei FusionCompute.

version_added: "1.0.1"

description:
    - This module enables the import of VMs via the HTTP(s) protocol in Huawei FusionCompute.
    - Provides flexibility in specifying both the image location and the method of pulling the image.

options:

    fc_body:
        description:
            - A dictionary containing the body of the standard VM import request.
            - The path in the `FileItems` field specifies the location of the image to be imported.
        required: true
        type: dict

    cna_ca_file:
        description:
            - CA file path to communicate with CNA (path on CNA: /etc/galax/certs/nginx/rootCA.crt)
        required: false
        type: str

    fc_params:
        description:
            - A dictionary for various parameters used throughout the import process.
            - "Available sub-parameters:"
            - "**fc_interval**: The interval (in seconds) for querying the VM import lease status. Default is 5 seconds."
            - "**fc_chunk_size**: The chunk size (in MB) used for the image import process. Default is 10 MB."
            - "**fc_pull_script**: A script that runs to fetch the image."
            - "Inputs:"
            - "Image URL: Location of the image."
            - JSON-encoded string containing `fc_params`.
            - "Outputs:"
            - "One line containing `{0} {1}`:"
            - "`{1}` is the local file location."
            - "`{0}` is `True` if the module should auto-clean after task completion, otherwise the file will not be cleaned."
        required: false
        type: dict

    # Parameters inherited from FcModuleBase:
    fc_hostname:
        description:
            - Host name or IP address of the FusionCompute VRM.
        required: true
        type: str

    fc_port:
        description:
            - Port number to connect to the FusionCompute VRM. Default is 7443.
        required: false
        default: 7443
        type: int

    fc_token:
        description:
            - Token for authentication. If provided, the module will skip login and use this token for authentication.
        required: false
        type: str

    fc_username:
        description:
            - Username for FusionCompute authentication.
        required: false
        type: str

    fc_password:
        description:
            - Password for authentication on the FusionCompute VRM.
        required: false
        type: str
        no_log: true

    fc_site_id:
        description:
            - Site ID for FusionCompute. If provided, the module will skip retrieving  site id and use this site ID.
        required: false
        type: str

    fc_language:
        description:
            - Language used for communication with FusionCompute VRM. Default is 'en-US'.
        required: false
        default: 'en-US'
        type: str

    fc_verify:
        description:
            - Path to rootCA.crt file for SSL certificate verification. If empty, SSL verification will be disabled.
        required: false
        default: ''
        type: str

author:
    - Huawei Technologies Co., Ltd.
'''

EXAMPLES = '''
# vm import from local
- name: test import
  huawei.fusioncompute.fc_vm_http_import:
    fc_hostname: "192.168.1.100"
    fc_token: "xxxx"
    fc_params:
      fc_chunk_size: 100
      fc_interval: 6
    fc_body:
      name: "ansible-http-import"
      description: ""
      location: "urn:sites:xxxxxxxxx:clusters:129"
      parentObjUrn: "urn:sites:xxxxxxxxx"
      enableImc: false
      isBindingHost: false
      osOptions:
        osType: "Linux"
        osVersion: 10023
      vmConfig:
        cpu:
          cpuHotPlug: 1
          cpuPolicy: "shared"
          cpuThreadPolicy: "prefer"
          weight: 1000
          quantity: 2
          limit: 0
          reservation: 0
          coresPerSocket: 1
        memory:
          quantityMB: 4096
          hugePage: "4K"
          limit: 0
          reservation: 0
          weight: 40960
          memHotPlug: 1
        disks:
          - datastoreUrn: "urn:sites:xxxxxxxxx:datastores:1"
            quantityGB: 40
            sequenceNum: 1
            type: "normal"
            indepDisk: false
            persistentDisk: true
            isThin: false
            volType: 0
            pciType: "VIRTIO"
            bootOrder: 1
            encrypted: "0"
            storageProtocol: "0"
          - datastoreUrn: "urn:sites:xxxxxxxxx:datastores:1"
            quantityGB: 10
            sequenceNum: 2
            type: "normal"
            indepDisk: false
            persistentDisk: true
            isThin: false
            volType: 1
            pciType: "VIRTIO"
            bootOrder: 2
            encrypted: "0"
            storageProtocol: "0"
        nics:
          - enableSecurityGroup: ""
            portGroupUrn: "urn:sites:xxxxxxxxx:dvswitchs:1:portgroups:1"
            sequenceNum: 0
            virtIo: 1
            bootOrder: -1
            connectAtPowerOn: true
            linkStatus: "disconnected"
            nicConfig:
              vringbuf: 256
              queues: 1
        graphicsCard:
          type: "cirrus"
          size: 4
        properties:
          antivirusMode: ""
          isAutoAdjustNuma: false
          bootFirmware: "BIOS"
          bootFirmwareTime: 0
          bootOption: "disk"
          clockMode: "synchClock"
          vmVncKeymapSetting: 12
          isHpet: false
          evsAffinity: false
          secureVmType: ""
          realtime: false
          isEnableMemVol: false
          isEnableFt: false
          isAutoUpgrade: true
          emulatorResType: null
          dpiVmType: ""
          cdRomBootOrder: -1
          attachType: false
          enableWatchDog: false
          isSecureBoot: false
          migrateSetting: "passThrough"
          enableKae: false
          enableSpice: false
        gpuGroups: []
      cpuVendor: "Intel"
      floppyFile: ""
      floppyProtocol: "select"
      imageFormat: "qcow2"
      fileItems:
        - size: 1825832960
          deviceId: "ovf:/disk/vda"
          path: "file:///xxxx/xxx-vda.qcow2"
        - size: 9961472
          deviceId: "ovf:/disk/vdb"
          path: "file:///xxxx/xxx-vdb.qcow2"
      isTemplate: true
      h5Style: true
      protocol: "server-http"
      url: "ansible-http-import.ovf"
      recover: false
      isSrcTemplate: false
      isEnableIntegrity: false
'''

RETURN = '''
ret:
    description: The response from the FusionCompute API.
    type: dict
    returned: always
    contains:
        code:
            description: The HTTP status code returned by the API.
            type: int
            returned: always
        rsp:
            description: The response body.
            type: dict
            returned: always
'''


@validator_injector([FcAttrValidator('fc_hostname', hostname_validator_fn)])
class FcVmHttpImport(FcModuleBase):
    def __init__(self, module):
        super(FcVmHttpImport, self).__init__(module)

    def execute(self):
        validate_res = self.validate()
        if validate_res:
            logger.info('fc vm http import validate failed %s', validate_res)
            self.module.fail_json(msg=validate_res)
        self.do_import()

    def do_import(self):
        fc_body = self.params['fc_body']
        fc_params = self.params['fc_params']
        fc_chunk_size = fc_params.get('fc_chunk_size', 10)
        fc_interval = fc_params.get('fc_interval', 5)
        ca_path = self.params['cna_ca_file']
        global_config = GlobalConfig()
        is_force_verify = global_config.get(
            'ssl_force_verification', 'true') != 'false'
        if is_force_verify and not ca_path:
            err_msg = 'Must give valid certifacte path.'
            logger.error(err_msg)
            raise ValueError(err_msg)
        fc_vol_files = self.pull_vol_files(fc_body['fileItems'], fc_params)
        if not fc_vol_files:
            self.module.fail_json(
                msg="Couldn't pull volume files with fileItems: %s" % fc_body['fileItems'])
        self.normalize_params(fc_body)
        fc_url = self.client.url_generator.vms_import(self.client.site_id)
        ret, rsp = self.client.post(fc_url, fc_body)
        if ret != HTTPStatus.OK:
            self.clean_files(fc_vol_files)
            self.module.fail_json(
                msg="Couldn't do vms import: ret: %s, rsp: %s" % (ret, rsp.json()))
        try:
            lease_id = self.get_lease_id(rsp)
            vm_id = self.get_vm_id(rsp)
            task_id = self.get_task_id(rsp)
            ret = self.upload_vol_and_complete_lease(
                lease_id, fc_vol_files, ca_path, fc_interval, fc_chunk_size)
            self.clean_files(fc_vol_files)
            if ret == HTTPStatus.OK:
                rsp = {'lease_id': lease_id,
                       'vm_id': vm_id,
                       'task_id': task_id, }
                self.module.exit_json(
                    changed=True, ret={'code': ret, 'rsp': rsp})
            else:
                self.module.fail_json(
                    msg="Couldn't complete lease: %s" % lease_id)
        except Exception as e:
            logger.exception(e)
            self.clean_files(fc_vol_files)
            url = self.client.url_generator.task_cancel(
                self.client.site_id, task_id)
            ret, rsp = self.client.post(url, {})
            self.module.fail_json(
                msg="Couldn't import vm, task_id: %s" % task_id)

    def pull_vol_files(self, file_items, params):
        vol_files = {}
        for file_item in file_items:
            try:
                file_url: ParseResult = urlparse(file_item['path'])
                logger.debug('file_url: %s', file_url)
                vol_res = {}
                vol_res['size'] = file_item['size']
                if file_url.scheme == 'file':
                    if os.path.getsize(file_url.path) != file_item['size']:
                        raise Exception(
                            'file size invalid for %s' % file_item)
                    vol_res['auto_clean'] = file_item.get(
                        'fc_auto_clean', False)
                    vol_res['path'] = file_url.path
                    vol_files[file_item['deviceId']] = vol_res
                else:
                    vol_pull_fn = self.get_vol_pull_fn(params)
                    if not vol_pull_fn:
                        return None
                    logger.debug('vol_pull_fn: %s', vol_pull_fn)
                    auto_clean, path = vol_pull_fn(file_item['path'], params)
                    vol_res['auto_clean'] = auto_clean
                    vol_res['path'] = path
                    logger.debug('auto_clean is %s, path is %s',
                                 auto_clean, path)
                    vol_files[file_item['deviceId']] = vol_res
                    if os.path.getsize(path) != file_item['size']:
                        logger.error('different size,%s, %s',
                                     os.path.getsize(path), file_item['size'])
                        raise Exception(
                            'file size invalid for %s' % file_item)
            except Exception as e:
                logger.exception(e)
                self.clean_files(vol_files)
                self.module.fail_json(
                    msg='Invalid schema for url: %s' % file_item['path'])
        return vol_files

    def get_vol_pull_fn(self, params):
        return pull_fn_wrap(params.get('fc_pull_script'))

    def clean_files(self, vol_files: dict):
        for vol_info in vol_files.values():
            if not vol_info['auto_clean']:
                continue
            logger.debug('clean file, path is %s', vol_info['path'])
            if os.path.exists(vol_info['path']):
                os.remove(vol_info['path'])

    def normalize_params(self, fc_body):
        for file_item in fc_body['fileItems']:
            file_item['path'] = file_item['path'].split('/')[-1]

    def get_lease_id(self, rsp):
        return int(rsp['serverLeaseUrn'].split(':')[-1])

    def get_vm_id(self, rsp):
        return rsp['urn'].split(':')[-1]

    def get_task_id(self, rsp):
        return int(rsp['taskUrn'].split(':')[-1])

    def upload_vol_and_complete_lease(self, lease_id, vol_files, ca_path, interval=5, chunk_size=10):
        vol_infos, auth_token = self.wait_lease_ready(lease_id, interval)
        if not vol_infos:
            return HTTPStatus.INTERNAL_SERVER_ERROR
        context = self.get_exec_context(
            vol_files, auth_token, lease_id, chunk_size)
        for vol_key, cna_ip, vol_uuid in vol_infos:
            with CnaClient(cna_ip, ca_path) as client:
                rsp, _ = client.auth_node()
                if rsp.status != HTTPStatus.OK:
                    logger.error('auth cna node error, rsp: %s', rsp)
                rsp, _ = client.auth_template(auth_token)
                if rsp.status != HTTPStatus.OK:
                    logger.error('auth cna template error, rsp: %s', rsp)
                ret = self.upload_template_file(context, client,
                                                vol_uuid, vol_files[vol_key]['path'])
            if ret != HTTPStatus.OK:
                return ret
        return ret

    def wait_lease_ready(self, lease_id, interval=5):
        lease_url = self.client.url_generator.lease_url(
            self.client.site_id, lease_id)
        while True:
            ret, rsp = self.client.get(lease_url)
            if ret != HTTPStatus.OK:
                logger.error('query lease info error, %s', rsp)
                return [], ''
            logger.debug('query lease info rsp: %s', rsp)
            if rsp['state'] == 'ready':
                infos = [(lease['key'], lease['url'].split('/')[2].split(':')[0], lease['url'].split('/')[4])
                         for lease in rsp['serverLeaseInfos']]
                logger.debug('lease is ready, infos: %s', infos)
                return infos, rsp['token']
            elif rsp['state'] == 'initializing':
                time.sleep(interval)
                continue
            else:
                logger.error('Unexpected lease status: %s', rsp['state'])
                return [], ''

    def get_exec_context(self, vol_files: dict, auth_token, lease_id, chunk_size):
        total_size = 0  # Get total file size
        for vol_info in vol_files.values():
            total_size += vol_info['size']
        context = {
            'total_size': total_size,
            'uploaded_size': 0,
            'auth_token': auth_token,
            'lease_id': lease_id,
            'chunk_size': chunk_size*1024*1024,
        }
        return context

    def update_lease(self, lease_id, percent):
        url = self.client.url_generator.lease_url(
            self.client.site_id, lease_id)
        ret, rsp = self.client.put(url, {
            'percent': int(percent),
        })
        return ret, rsp

    def complete_lease(self, lease_id, is_abort=False):
        url = self.client.url_generator.lease_complete_url(
            self.client.site_id, lease_id)
        ret, rsp = self.client.post(url, {
            'isAbort': is_abort,
            'fault': '',
        })
        return ret, rsp

    def upload_template_file(self, context, cna_client: CnaClient, vol_uuid, file_path):
        return cna_client.upload_template_file(vol_uuid, file_path, context, self.update_lease, self.complete_lease)


def pull_fn_wrap(fc_pull_script):
    def fn(path, params):
        import subprocess
        args = ["python3", fc_pull_script, path, json.dumps(params)]
        result = subprocess.run(args, capture_output=True, text=True)
        stdout = result.stdout
        returncode = result.returncode
        if returncode != 0:
            return False, ''
        auto_clean, res_path = stdout.strip().split(' ')
        return auto_clean == 'True', res_path
    return fn


def run_module():
    # define available arguments/parameters a user can pass to the module
    module_args = FcModuleBase.args()
    module_args.update(
        cna_ca_file=dict(type='str', required=False),
        fc_body=dict(type='dict', required=True),
        fc_params=dict(type='dict', required=False, default={}),
    )
    module = AnsibleModule(
        argument_spec=module_args,
        supports_check_mode=True
    )
    fc_vm_http_import = FcVmHttpImport(module)
    fc_vm_http_import.execute()


def main():
    run_module()


if __name__ == '__main__':
    main()
