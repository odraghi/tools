#!/usr/bin/env python
# -*- coding:utf-8 -*-
#  Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.
from http import HTTPStatus
from enum import Enum

from ansible.module_utils.basic import AnsibleModule
from ansible_collections.huawei.fusioncompute.plugins.module_utils.core.fusincompute import logger
from ansible_collections.huawei.fusioncompute.plugins.module_utils.param_validator import hostname_validator_fn
from ansible_collections.huawei.fusioncompute.plugins.module_utils.decorator import action_injector, validator_injector
from ansible_collections.huawei.fusioncompute.plugins.module_utils.basic import FcAttrValidator, FcModuleBase
from ansible_collections.huawei.fusioncompute.plugins.module_utils.entity.enum.basic import RestfulReqType

ANSIBLE_METADATA = {
    'metadata_version': '1.0.0',
    'status': ['preview'],
    'supported_by': 'huawei'
}

DOCUMENTATION = '''
---
module: huawei.fusioncompute.fc_generic

short_description: FusionCompute generic module.

version_added: "1.0.0"

description:
    - A generic module for interacting with Huawei FusionCompute.
    - Supports sending HTTP requests to FusionCompute APIs.
    - Provides flexibility to perform various operations through configurable parameters.

options:
    fc_method:
        description:
            - The HTTP method to be used for the request. 
        required: true
        type: str
        choices: ['get', 'post', 'put', 'delete']
    
    fc_url:
        description:
            - The URL to send the HTTP request to.
        required: true
        type: str
    
    fc_raw_url:
        description:
            - Whether to use the raw URL.
            - "If false, concatenate the target URL as `https://{fc_hostname}:{fc_port}/service/sites/{site_id}{fc_url}`."
            - "If true, concatenate the target URL as `https://{fc_hostname}:{fc_port}/service{fc_url}`."
        required: false
        type: bool
        default: false
    
    fc_query:
        description:
            - A dictionary of query parameters to append to the URL.
            - The query parameters will be added after the `?` in the URL.
        required: false
        type: dict

    fc_body:
        description:
            - A dictionary representing the body of the HTTP request.
            - This is typically used with methods like 'POST' or 'PUT'.
        required: false
        type: dict

    
    # Parameters inherited from FcModuleBase:
    fc_hostname:
        description:
            - Host name or IP address of the FusionCompute VRM.
        required: true
        type: str

    fc_port:
        description:
            - Port number to connect to the FusionCompute VRM. Default is 7443.
        required: false
        default: 7443
        type: int

    fc_token:
        description:
            - Token for authentication. If provided, the module will skip login and use this token for authentication.
        required: false
        type: str

    fc_username:
        description:
            - Username for FusionCompute authentication.
        required: false
        type: str

    fc_password:
        description:
            - Password for authentication on the FusionCompute VRM.
        required: false
        type: str
        no_log: true
    
    fc_site_id:
        description:
            - Site ID for FusionCompute. If provided, the module will skip retrieving  site id and use this site ID.
        required: false
        type: str

    fc_language:
        description:
            - Language used for communication with FusionCompute VRM. Default is 'en-US'.
        required: false
        default: 'en-US'
        type: str

    fc_verify:
        description:
            - Path to rootCA.crt file for SSL certificate verification. If empty, SSL verification will be disabled.
        required: false
        default: ''
        type: str

author:
    - Huawei Technologies Co., Ltd.
'''

EXAMPLES = '''
# query vms
- name: test get
  huawei.fusioncompute.fc_generic:
    action: login
    fc_hostname: "192.168.1.100"
    fc_token: "xxxx"
    fc_method: 'get'
    fc_url: '/vms'
    fc_query:
      limit: 2
      offset: 1
# add datastore cluster
- name: test post
  huawei.fusioncompute.fc_generic:
    action: logout
    fc_hostname: "192.168.1.100"
    fc_token: "xxxx"
    fc_method: 'post'
    fc_url: '/datastore-cluster'
    fc_body:
      clusterName: demo-2
      clusterType: LOCAL_SAN
      datastoreList: []
      sdrsProps:
          drsKey: 1
          sizeDrsKey: 1
          iopsDrsKey: 0
          isAuto: 1
          storageThreshold: 80
          storageDiffThreshold: 5
          speed: 60
          sdrsFragmentLimen: "001000000000000000000000"
          sdrsCycleType: 3
          sdrsCycleSpec: "1"
'''

RETURN = '''
ret:
    description: The response from the FusionCompute API.
    type: dict
    returned: always
    contains:
        code:
            description: The HTTP status code returned by the API.
            type: int
            returned: always
        rsp:
            description: The response body returned by the API.
            type: dict
            returned: always
'''


@action_injector(RestfulReqType, 'fc_method', 'fc_method')
@validator_injector([FcAttrValidator('fc_hostname', hostname_validator_fn)])
class FcGeneric(FcModuleBase):
    def __init__(self, module):
        super(FcGeneric, self).__init__(module)

    def execute(self):
        validate_res = self.validate()
        if validate_res:
            logger.info('fc generic validate failed %s', validate_res)
            self.module.fail_json(msg=validate_res)
        method: RestfulReqType = self.fc_method
        original_url = self.params['fc_url']
        is_raw_url = self.params['fc_raw_url']
        url = self.client.url_generator.generic_url(
            original_url, self.client.site_id if not is_raw_url else None)
        match method:
            case RestfulReqType.get:
                ret, rsp = self.client.get(url, params=self.params['fc_query'])
            case RestfulReqType.post:
                ret, rsp = self.client.post(url, self.params['fc_body'])
            case RestfulReqType.put:
                ret, rsp = self.client.put(url, self.params['fc_body'])
            case RestfulReqType.delete:
                ret, rsp = self.client.delete(
                    url, params=self.params['fc_query'])
            case _:
                self.module.fail_json(
                    changed=False, msg='param fc_method type invalid.')
        if ret != HTTPStatus.OK:
            self.module.fail_json(
                msg="Couldn't execute fc_generic: ret: %s, rsp: %s" % (ret, rsp.json()))
        self.module.exit_json(
            changed=(method != RestfulReqType.get), ret={'code': ret, 'rsp': rsp})


def run_module():
    # define available arguments/parameters a user can pass to the module
    module_args = FcModuleBase.args()
    module_args.update(
        fc_method=dict(type='str', required=True),
        fc_url=dict(type='str', required=True),
        fc_raw_url=dict(type='bool', required=False, default=False),
        fc_query=dict(type='dict', required=False),
        fc_body=dict(type='dict', required=False),
    )
    module = AnsibleModule(
        argument_spec=module_args,
        supports_check_mode=True
    )
    fc_generic = FcGeneric(module)
    fc_generic.execute()


def main():
    run_module()


if __name__ == '__main__':
    main()
