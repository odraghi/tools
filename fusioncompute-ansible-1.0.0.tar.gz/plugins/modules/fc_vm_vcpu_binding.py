#!/usr/bin/env python
# -*- coding:utf-8 -*-
#  Copyright (c) Huawei Technologies Co., Ltd. 2024-2024. All rights reserved.
from http import HTTPStatus
from enum import Enum

from ansible.module_utils.basic import AnsibleModule
from ansible_collections.huawei.fusioncompute.plugins.module_utils.core.fusincompute import logger
from ansible_collections.huawei.fusioncompute.plugins.module_utils.entity.enum.basic import VcpuBindType
from ansible_collections.huawei.fusioncompute.plugins.module_utils.param_validator import hostname_validator_fn
from ansible_collections.huawei.fusioncompute.plugins.module_utils.decorator import validator_injector
from ansible_collections.huawei.fusioncompute.plugins.module_utils.basic import FcAttrValidator, FcModuleBase
from ansible_collections.huawei.fusioncompute.plugins.module_utils.core.parameter_normalization import normalize

ANSIBLE_METADATA = {
    'metadata_version': '1.0.0',
    'status': ['preview'],
    'supported_by': 'standard'
}

DOCUMENTATION = '''
---
module: huawei.fusioncompute.fc_vm_vcpu_binding

short_description: Manage FusionCompute VM vcpu binding (auto on/auto off/exact/range/numa)

version_added: "1.0.0"

description:
    - "This module supports binding vCPUs for FusionCompute VMs."
    - "Supported binding types include: auto on, auto off, exact, range, and NUMA."

options:
    vm_id:
        description:
            - The ID of the virtual machine (VM) for which the vCPU binding is to be configured.
        required: true
        type: str

    cpuBindType:
        description:
            - The type of vCPU binding to be applied.
            - Supported values include
            - "'auto_on': Automatically binds vCPUs in dedicated mode."
            - "'auto_off': Automatically binds vCPUs in shared mode."
            - "'exact': Manually specify exact vCPUs for binding."
            - "'range': Bind vCPUs within a specified range."
            - "'numa': NUMA-based vCPU binding."
        required: true
        type: str
        choices: ['auto_on', 'auto_off', 'exact', 'range', 'numa']

    affinitySet:
        description:
            - A list of CPU affinities to be applied when using 'exact' binding type. 
            - This defines the exact set of CPUs that the VM should use.
        required: false
        type: list

    emulatorPin:
        description:
            - A list of CPU affinities for emulator pinning. This is used to pin the emulator to specific CPUs.
        required: false
        type: list

    exactCpuAffinityList:
        description:
            - A list of CPU IDs that the VM will use when 'cpuBindType' is set to 'exact'.
        required: false
        type: list

    numaBinds:
        description:
            - A dictionary that specifies the NUMA node bindings for the VM's vCPUs.
            - This is used when 'cpuBindType' is set to 'numa'.
        required: false
        type: dict

    # Parameters inherited from FcModuleBase:
    fc_hostname:
        description:
            - Host name or IP address of the FusionCompute VRM.
        required: true
        type: str

    fc_port:
        description:
            - Port number to connect to the FusionCompute VRM. Default is 7443.
        required: false
        default: 7443
        type: int

    fc_token:
        description:
            - Token for authentication. If provided, the module will skip login and use this token for authentication.
        required: false
        type: str

    fc_username:
        description:
            - Username for FusionCompute authentication.
        required: false
        type: str

    fc_password:
        description:
            - Password for authentication on the FusionCompute VRM.
        required: false
        type: str
        no_log: true
    
    fc_site_id:
        description:
            - Site ID for FusionCompute. If provided, the module will skip retrieving  site id and use this site ID.
        required: false
        type: str

    fc_language:
        description:
            - Language used for communication with FusionCompute VRM. Default is 'en-US'.
        required: false
        default: 'en-US'
        type: str

    fc_verify:
        description:
            - Path to rootCA.crt file for SSL certificate verification. If empty, SSL verification will be disabled.
        required: false
        default: ''
        type: str

author:
    - Huawei Technologies Co., Ltd.
'''

EXAMPLES = '''
# Example 1: Auto bind vCPUs in dedicated mode (auto_on)
- name: Bind vCPUs in dedicated mode (auto_on)
  huawei.fusioncompute.fc_vm_vcpu_binding:
    vm_id: "i-xxxxxxxx"
    cpuBindType: "auto_on"
    fc_hostname: "192.168.1.100"
    fc_token: "xxxx"

# Example 2: Bind vCPUs with exact CPU affinities(exact)
- name: Bind vCPUs with exact CPU affinities(exact)
  huawei.fusioncompute.fc_vm_vcpu_binding:
    vm_id: "i-xxxxxxxx"
    cpuBindType: "exact"
    exactCpuAffinityList:
      - vcpuScope: "0"
        pcpuScope: "9,8"
      - vcpuScope: "1"
        pcpuScope: "12,13"
    fc_hostname: "192.168.1.100"
    fc_token: "xxxx"
  register: result

- name: Debug the result
  debug:
    var: result
'''

RETURN = '''
ret:
    description: The response from the FusionCompute API.
    type: dict
    returned: always
    contains:
        code:
            description: The HTTP status code of the operation.
            type: int
            returned: always
        rsp:
            description: The response body returned by the API.
            type: dict
            returned: always
'''


@validator_injector([FcAttrValidator('fc_hostname', hostname_validator_fn)])
class FcVmVcpuBinding(FcModuleBase):
    def __init__(self, module):
        super(FcVmVcpuBinding, self).__init__(module)

    def execute(self):
        validate_res = self.validate()
        if validate_res:
            logger.info("fc token manager validate failed %s", validate_res)
            self.module.fail_json(msg=validate_res)
        vm_id = self.params['vm_id']
        cpu_bind_type = self.params['cpuBindType']
        if cpu_bind_type in [VcpuBindType.auto_on.value, VcpuBindType.auto_off.value]:
            data = {
                'cpu': {
                    "cpuPolicy": 'dedicated' if cpu_bind_type == VcpuBindType.auto_on.value else 'shared'
                }
            }
            url = self.client.url_generator.vms(self.client.site_id, vm_id)
        else:
            affinity_set = self.params['affinitySet']
            emulator_pin = self.params['emulatorPin']
            exact_cpu_affinity_list = self.params['exactCpuAffinityList']
            numa_binds = self.params['numaBinds']
            data = {'cpuBindType': cpu_bind_type,
                    'affinitySet': affinity_set,
                    'emulatorPin': emulator_pin,
                    'exactCpuAffinityList': exact_cpu_affinity_list,
                    'numaBinds': numa_binds,
                    }
            url = self.client.url_generator.vm_vcpu_bind(
                self.client.site_id, vm_id)
        ret, rsp = self.client.put(
            url,
            normalize(data)
        )
        if ret != HTTPStatus.OK:
            self.module.fail_json(
                msg="Couldn't bind vm vcpu: ret: %s, rsp: %s" % (ret, rsp.json()))
        else:
            self.module.exit_json(
                changed=True, ret={'code': ret, 'rsp': rsp})


def run_module():
    # define available arguments/parameters a user can pass to the module
    module_args = FcModuleBase.args()
    module_args.update(
        vm_id=dict(type='str', required=True),
        cpuBindType=dict(type='str', required=True),
        affinitySet=dict(type='list', required=False),
        emulatorPin=dict(type='list', required=False),
        exactCpuAffinityList=dict(type='list', required=False),
        numaBinds=dict(type='dict', required=False),
    )
    module = AnsibleModule(
        argument_spec=module_args,
        supports_check_mode=True
    )
    fc_vm_vcpu_binding = FcVmVcpuBinding(module)
    fc_vm_vcpu_binding.execute()


def main():
    run_module()


if __name__ == '__main__':
    main()
