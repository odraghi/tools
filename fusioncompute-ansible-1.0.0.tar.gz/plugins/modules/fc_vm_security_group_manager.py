#!/usr/bin/env python
# -*- coding:utf-8 -*-
#  Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.
from http import HTTPStatus
from enum import Enum

from ansible.module_utils.basic import AnsibleModule
from ansible_collections.huawei.fusioncompute.plugins.module_utils.core.fusincompute import logger
from ansible_collections.huawei.fusioncompute.plugins.module_utils.param_validator import hostname_validator_fn
from ansible_collections.huawei.fusioncompute.plugins.module_utils.decorator import action_injector, validator_injector
from ansible_collections.huawei.fusioncompute.plugins.module_utils.basic import FcAttrValidator, FcModuleBase
from ansible_collections.huawei.fusioncompute.plugins.module_utils.core.parameter_normalization import normalize

ANSIBLE_METADATA = {
    'metadata_version': '1.0.0',
    'status': ['preview'],
    'supported_by': 'standard'
}

DOCUMENTATION = '''
---
module: huawei.fusioncompute.fc_vm_security_group_manager

short_description: Manage security groups and network rules for virtual machines (VMs) on Huawei FusionCompute.

version_added: "1.0.0"

description:
    - This module allows you to manage security groups and network rules for virtual machines (VMs) on Huawei FusionCompute.
    - It supports querying, creating, modifying, deleting, configuring, and configuring security groups for NICs.

options:
    action:
        description:
            - The action to perform.
            - Supported actions are 'create', 'modify', 'delete', 'pagination', 'create_rule', 'pagination_rule', and 'delete_rule'.
        required: true
        type: str
        choices: ['create', 'modify', 'delete', 'pagination', 'create_rule', 'pagination_rule', 'delete_rule']

    sg_id:
        description:
            - The ID of the security group to be managed.
        required: false
        type: int

    sgIds:
        description:
            - List of security group IDs for batch operations.
        required: false
        type: list

    sgName:
        description:
            - The name of the security group.
        required: false
        type: str

    sgDescription:
        description:
            - The description of the security group.
        required: false
        type: str

    sgType:
        description:
            - The type of the security group.
        required: false
        type: int

    sgIPStackType:
        description:
            - The IP stack type of the security group.
        required: false
        type: int

    rules:
        description:
            - List of rules to be applied to the security group.
        required: false
        type: list

    limit:
        description:
            - The maximum number of items to return in a paginated request.
        required: false
        type: int

    offset:
        description:
            - The offset for paginated requests.
        required: false
        type: int

    ruleIds:
        description:
            - List of rule IDs for batch operations.
        required: false
        type: list

    # Parameters inherited from FcModuleBase:
    fc_hostname:
        description:
            - Host name or IP address of the FusionCompute VRM.
        required: true
        type: str

    fc_port:
        description:
            - Port number to connect to the FusionCompute VRM. Default is 7443.
        required: false
        default: 7443
        type: int

    fc_token:
        description:
            - Token for authentication. If provided, the module will skip login and use this token for authentication.
        required: false
        type: str

    fc_username:
        description:
            - Username for FusionCompute authentication.
        required: false
        type: str

    fc_password:
        description:
            - Password for authentication on the FusionCompute VRM.
        required: false
        type: str
        no_log: true

    fc_site_id:
        description:
            - Site ID for FusionCompute. If provided, the module will skip retrieving  site id and use this site ID.
        required: false
        type: str

    fc_language:
        description:
            - Language used for communication with FusionCompute VRM. Default is 'en-US'.
        required: false
        default: 'en-US'
        type: str

    fc_verify:
        description:
            - Path to rootCA.crt file for SSL certificate verification. If empty, SSL verification will be disabled.
        required: false
        default: ''
        type: str

author:
    - Huawei Technologies Co., Ltd.
'''

EXAMPLES = '''
# Create a security group
- name: Create a security group
  huawei.fusioncompute.fc_vm_security_group_manager:
    action: create
    fc_hostname: "192.168.1.100"
    fc_token: "xxxx"
    sgName: "my_security_group"
    sgDescription: "Security group for my VMs"
    sgType: 0
    sgIPStackType: 2
    rules:
      - rule1
      - rule2

# Modify a security group
- name: Modify a security group
  huawei.fusioncompute.fc_vm_security_group_manager:
    action: modify
    fc_hostname: "192.168.1.100"
    fc_token: "xxxx"
    sg_id: 1
    sgName: "updated_security_group"
    sgDescription: "Updated security group description"

# Delete a security group
- name: Delete a security group
  huawei.fusioncompute.fc_vm_security_group_manager:
    action: delete
    fc_hostname: "192.168.1.100"
    fc_token: "xxxx"
    sgIds:
      - 1
      - 2

# Paginate security groups
- name: Paginate security groups
  huawei.fusioncompute.fc_vm_security_group_manager:
    action: pagination
    fc_hostname: "192.168.1.100"
    fc_token: "xxxx"
    limit: 10
    offset: 0

# Create a security group rule
- name: Create a security group rule
  huawei.fusioncompute.fc_vm_security_group_manager:
    action: create_rule
    fc_hostname: "192.168.1.100"
    fc_token: "xxxx"
    sg_id: 1
    rules:
      - rule1
      - rule2

# Paginate security group rules
- name: Paginate security group rules
  huawei.fusioncompute.fc_vm_security_group_manager:
    action: pagination_rule
    fc_hostname: "192.168.1.100"
    fc_token: "xxxx"
    sg_id: 1
    limit: 10
    offset: 0

# Delete security group rules
- name: Delete security group rules
  huawei.fusioncompute.fc_vm_security_group_manager:
    action: delete_rule
    fc_hostname: "192.168.1.100"
    fc_token: "xxxx"
    sg_id: 1
    ruleIds:
      - 1
      - 2
'''


RETURN = '''
ret:
    description: The response from the FusionCompute API.
    type: dict
    returned: always
    contains:
        code:
            description: The HTTP status code of the operation.
            type: int
            returned: always
        rsp:
            description: The response body returned by the API.
            type: dict
            returned: always
'''


class ManageAction(Enum):
    delete = 'delete'
    create = 'create'
    pagination = 'pagination'
    modify = 'modify'
    create_rule = 'create_rule'
    pagination_rule = 'pagination_rule'
    delete_rule = 'delete_rule'


@action_injector(ManageAction)
@validator_injector([FcAttrValidator('fc_hostname', hostname_validator_fn)])
class FcVmSecurityGroupManager(FcModuleBase):
    def __init__(self, module):
        super(FcVmSecurityGroupManager, self).__init__(module)

    def execute(self):
        validate_res = self.validate()
        if validate_res:
            logger.info("fc  manager validate failed %s", validate_res)
            self.module.fail_json(msg=validate_res)
        action: ManageAction = self.action
        match action:
            case ManageAction.create:
                ret, rsp = self.do_create()
            case ManageAction.pagination:
                ret, rsp = self.do_pagination()
            case ManageAction.modify:
                ret, rsp = self.do_modify()
            case ManageAction.delete:
                ret, rsp = self.do_delete()
            case ManageAction.create_rule:
                ret, rsp = self.do_create_rule()
            case ManageAction.pagination_rule:
                ret, rsp = self.do_pagination_rule()
            case ManageAction.delete_rule:
                ret, rsp = self.do_delete_rule()
            case _:
                self.module.fail_json(
                    changed=False, msg='param action type invalid.')
        if ret != HTTPStatus.OK:
            self.module.fail_json(
                msg="Couldn't manage vm security group: ret: %s, rsp: %s" % (ret, rsp.json()))
        else:
            self.module.exit_json(
                changed=(action not in (ManageAction.pagination, ManageAction.pagination_rule)), ret={'code': ret, 'rsp': rsp})

    def do_pagination(self):
        params = ['sgName', 'limit', 'offset']
        data = self.exact_params(params)
        url = self.client.url_generator.vm_pagination_sg(
            self.client.site_id)
        return self.client.get(url, normalize(data))

    def do_create(self):
        params = ['sgName', 'sgDescription',
                  'sgType', 'sgIPStackType', 'rules']
        data = self.exact_params(params)
        url = self.client.url_generator.vm_create_sg(
            self.client.site_id)
        return self.client.post(url, normalize(data))

    def do_modify(self):
        params = ['sgName', 'sgDescription', 'sgIPStackType']
        sg_id = self.params['sg_id']
        data = self.exact_params(params)
        url = self.client.url_generator.vm_modify_sg(
            self.client.site_id, sg_id)
        return self.client.put(url, normalize(data))

    def do_delete(self):
        params = ['sgIds']
        data = self.exact_params(params)
        url = self.client.url_generator.vm_delete_sg(
            self.client.site_id)
        return self.client.post(url, normalize(data))

    def do_create_rule(self):
        params = ['rules']
        sg_id = self.params['sg_id']
        data = self.exact_params(params)
        url = self.client.url_generator.vm_create_sg_rule(
            self.client.site_id, sg_id)
        return self.client.post(url, normalize(data))

    def do_pagination_rule(self):
        params = ['sgName', 'limit', 'offset']
        data = self.exact_params(params)
        sg_id = self.params['sg_id']
        url = self.client.url_generator.vm_pagination_sg_rule(
            self.client.site_id, sg_id)
        return self.client.get(url, normalize(data))

    def do_delete_rule(self):
        params = ['ruleIds']
        sg_id = self.params['sg_id']
        data = self.exact_params(params)
        url = self.client.url_generator.vm_delete_sg_rule(
            self.client.site_id, sg_id)
        return self.client.post(url, normalize(data))


def run_module():
    # define available arguments/parameters a user can pass to the module
    module_args = FcModuleBase.args()
    module_args.update(
        action=dict(type='str', required=True),
        sg_id=dict(type='int', required=False),
        sgIds=dict(type='list', required=False),
        sgName=dict(type='str', required=False),
        sgDescription=dict(type='str', required=False),
        sgType=dict(type='int', required=False),
        sgIPStackType=dict(type='int', required=False),
        rules=dict(type='list', required=False),
        limit=dict(type='int', required=False),
        offset=dict(type='int', required=False),
        ruleIds=dict(type='list', required=False),
    )
    module = AnsibleModule(
        argument_spec=module_args,
        supports_check_mode=True
    )
    fc_vm_security_group_manager = FcVmSecurityGroupManager(module)
    fc_vm_security_group_manager.execute()


def main():
    run_module()


if __name__ == '__main__':
    main()
