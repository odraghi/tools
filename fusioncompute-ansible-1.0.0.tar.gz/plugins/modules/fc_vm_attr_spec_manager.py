#!/usr/bin/env python
# -*- coding:utf-8 -*-
#  Copyright (c) Huawei Technologies Co., Ltd. 2024-2024. All rights reserved.
from http import HTTPStatus

from ansible.module_utils.basic import AnsibleModule
from ansible_collections.huawei.fusioncompute.plugins.module_utils.core.fusincompute import logger
from ansible_collections.huawei.fusioncompute.plugins.module_utils.entity.enum.basic import ManageAction
from ansible_collections.huawei.fusioncompute.plugins.module_utils.param_validator import hostname_validator_fn
from ansible_collections.huawei.fusioncompute.plugins.module_utils.decorator import action_injector, validator_injector
from ansible_collections.huawei.fusioncompute.plugins.module_utils.basic import FcAttrValidator, FcModuleBase
from ansible_collections.huawei.fusioncompute.plugins.module_utils.core.parameter_normalization import normalize

ANSIBLE_METADATA = {
    'metadata_version': '1.0.0',
    'status': ['preview'],
    'supported_by': 'standard'
}

DOCUMENTATION = '''
---
module: huawei.fusioncompute.fc_attr_spec_manager

short_description: Manage virtual machine (VM) attribute specifications on Huawei FusionCompute.

version_added: "1.0.0"

description:
    - This module allows you to manage attribute specifications for virtual machines (VMs) on Huawei FusionCompute.
    - It supports creating, modifying, deleting, querying, and paginating VM attribute specifications.

options:
    action:
        description:
            - The action to perform.
            - Supported actions are 'create', 'modify', 'delete', 'query', and 'pagination'.
        required: true
        type: str
        choices: ['create', 'modify', 'delete', 'query', 'pagination']

    spec_id:
        description:
            - The ID of the VM attribute specification to manage.
        required: false
        type: str

    limit:
        description:
            - The maximum number of specifications to return in pagination mode.
            - Only applicable when action is 'pagination'.
        required: false
        type: int

    offset:
        description:
            - The starting index for pagination.
            - Only applicable when action is 'pagination'.
        required: false
        type: int

    target_name:
        description:
            - The name of the target specification to filter in pagination mode.
            - Only applicable when action is 'pagination'.
        required: false
        type: str

    urn:
        description:
            - The URN (Uniform Resource Name) of the VM attribute specification.
        required: false
        type: str

    uri:
        description:
            - The URI (Uniform Resource Identifier) of the VM attribute specification.
        required: false
        type: str

    name:
        description:
            - The name of the VM attribute specification.
        required: false
        type: str

    description:
        description:
            - The description of the VM attribute specification.
        required: false
        type: str

    osType:
        description:
            - The operating system type for the VM attribute specification.
        required: false
        type: str

    hostname:
        description:
            - The hostname for the VM attribute specification.
        required: false
        type: str

    updatePassword:
        description:
            - Whether to update the password for the VM attribute specification.
        required: false
        type: bool

    isUpdateVmPassword:
        description:
            - Whether to update the VM password for the VM attribute specification.
        required: false
        type: bool

    updateDomainPassword:
        description:
            - Whether to update the domain password for the VM attribute specification.
        required: false
        type: bool

    password:
        description:
            - The password for the VM attribute specification.
        required: false
        type: str

    workgroup:
        description:
            - The workgroup for the VM attribute specification.
        required: false
        type: str

    domain:
        description:
            - The domain for the VM attribute specification.
        required: false
        type: str

    domainName:
        description:
            - The domain name for the VM attribute specification.
        required: false
        type: str

    domainPassword:
        description:
            - The domain password for the VM attribute specification.
        required: false
        type: str

    nicSpecification:
        description:
            - The NIC (Network Interface Card) specification for the VM attribute specification.
        required: false
        type: list

    ouName:
        description:
            - The OU (Organizational Unit) name for the VM attribute specification.
        required: false
        type: str

    runOnce:
        description:
            - The run-once configuration for the VM attribute specification.
        required: false
        type: list

    isUpdateVmSid:
        description:
            - Whether to update the VM SID (Security Identifier) for the VM attribute specification.
        required: false
        type: bool

    grubPassword:
        description:
            - The GRUB password for the VM attribute specification.
        required: false
        type: str

    # Parameters inherited from FcModuleBase:
    fc_hostname:
        description:
            - Host name or IP address of the FusionCompute VRM.
        required: true
        type: str

    fc_port:
        description:
            - Port number to connect to the FusionCompute VRM. Default is 7443.
        required: false
        default: 7443
        type: int

    fc_token:
        description:
            - Token for authentication. If provided, the module will skip login and use this token for authentication.
        required: false
        type: str

    fc_username:
        description:
            - Username for FusionCompute authentication.
        required: false
        type: str

    fc_password:
        description:
            - Password for authentication on the FusionCompute VRM.
        required: false
        type: str
        no_log: true
    
    fc_site_id:
        description:
            - Site ID for FusionCompute. If provided, the module will skip retrieving  site id and use this site ID.
        required: false
        type: str

    fc_language:
        description:
            - Language used for communication with FusionCompute VRM. Default is 'en-US'.
        required: false
        default: 'en-US'
        type: str

    fc_verify:
        description:
            - Path to rootCA.crt file for SSL certificate verification. If empty, SSL verification will be disabled.
        required: false
        default: ''
        type: str

author:
    - Huawei Technologies Co., Ltd.
'''

EXAMPLES = '''
# Create a VM attribute specification
- name: Create a VM attribute specification
  huawei.fusioncompute.fc_attr_spec_manager:
    action: create
    fc_hostname: "192.168.1.100"
    fc_token: "xxxx"
    name: 'vm-spec-2'
    osType: 'Windows'
    description: ''
    hostname: 'hn'
    workgroup: 'wg'
    nicSpecification: []
  register: result

# Query a VM attribute specification
- name: Query a VM attribute specification
  huawei.fusioncompute.fc_attr_spec_manager:
    action: query
    fc_hostname: "192.168.1.100"
    fc_token: "xxxx"
    spec_id: "spec-123"
  register: result

- name: Debug the result
  debug:
    var: result
'''

RETURN = '''
ret:
    description: The response from the FusionCompute API.
    type: dict
    returned: always
    contains:
        code:
            description: The HTTP status code of the operation.
            type: int
            returned: always
        rsp:
            description: The response body returned by the API.
            type: dict
            returned: always
'''


@action_injector(ManageAction)
@validator_injector([FcAttrValidator('fc_hostname', hostname_validator_fn)])
class FcVmAttrSpecManager(FcModuleBase):
    def __init__(self, module):
        super(FcVmAttrSpecManager, self).__init__(module)

    def execute(self):
        validate_res = self.validate()
        if validate_res:
            logger.info("fc token manager validate failed %s", validate_res)
            self.module.fail_json(msg=validate_res)
        action: ManageAction = self.action
        spec_id = self.params['spec_id']
        limit = self.params['limit']
        offset = self.params['offset']
        target_name = self.params['target_name']
        data = self.generate_data()
        params = {
            'limit': limit,
            'offset': offset,
            'name': target_name,
        }
        url = self.client.url_generator.vm_attr_spec(
            self.client.site_id, spec_id)
        match action:
            case ManageAction.create:
                ret, rsp = self.client.post(url, normalize(data))
            case ManageAction.modify:
                ret, rsp = self.client.put(url, normalize(data))
            case ManageAction.delete:
                ret, rsp = self.client.delete(url)
            case ManageAction.query:
                ret, rsp = self.client.get(url)
            case ManageAction.pagination:
                ret, rsp = self.client.get(url, params=normalize(params))
            case _:
                self.module.fail_json(
                    changed=False, msg='param action type invalid.')
        if ret != HTTPStatus.OK:
            self.module.fail_json(
                msg="Couldn't manage vm attribute specifcation: ret: %s, rsp: %s" % (ret, rsp.json()))
        else:
            self.module.exit_json(
                changed=(action in (ManageAction.create,
                         ManageAction.modify, ManageAction.delete)),
                ret={'code': ret, 'rsp': rsp})

    def generate_data(self):
        urn = self.params['urn']
        uri = self.params['uri']
        name = self.params['name']
        description = self.params['description']
        os_type = self.params['osType']
        hostname = self.params['hostname']
        update_password = self.params['updatePassword']
        is_update_vm_password = self.params['isUpdateVmPassword']
        update_domain_password = self.params['updateDomainPassword']
        password = self.params['password']
        workgroup = self.params['workgroup']
        domain = self.params['domain']
        domain_name = self.params['domainName']
        domain_password = self.params['domainPassword']
        nic_specification = self.params['nicSpecification']
        ou_name = self.params['ouName']
        run_once = self.params['runOnce']
        is_update_vm_sid = self.params['isUpdateVmSid']
        grub_password = self.params['grubPassword']
        data = {
            'urn': urn,
            'uri': uri,
            'name': name,
            'description': description,
            'osType': os_type,
            'hostname': hostname,
            'updatePassword': update_password,
            'isUpdateVmPassword': is_update_vm_password,
            'updateDomainPassword': update_domain_password,
            'password': password,
            'workgroup': workgroup,
            'domain': domain,
            'domainName': domain_name,
            'domainPassword': domain_password,
            'nicSpecification': nic_specification,
            'ouName': ou_name,
            'runOnce': run_once,
            'isUpdateVmSid': is_update_vm_sid,
            'grubPassword': grub_password
        }
        return data


def run_module():
    # define available arguments/parameters a user can pass to the module
    module_args = FcModuleBase.args()
    module_args.update(
        action=dict(type='str', required=True),
        spec_id=dict(type='str', required=False),
        limit=dict(type='int', required=False),
        offset=dict(type='int', required=False),
        target_name=dict(type='str', required=False),
        urn=dict(type='str', required=False),
        uri=dict(type='str', required=False),
        name=dict(type='str', required=False),
        description=dict(type='str', required=False),
        osType=dict(type='str', required=False),
        hostname=dict(type='str', required=False),
        updatePassword=dict(type='bool', required=False),
        isUpdateVmPassword=dict(type='bool', required=False),
        updateDomainPassword=dict(type='bool', required=False),
        password=dict(type='str', required=False),
        workgroup=dict(type='str', required=False),
        domain=dict(type='str', required=False),
        domainName=dict(type='str', required=False),
        domainPassword=dict(type='str', required=False),
        nicSpecification=dict(type='list', required=False),
        ouName=dict(type='str', required=False),
        runOnce=dict(type='list', required=False),
        isUpdateVmSid=dict(type='bool', required=False),
        grubPassword=dict(type='str', required=False),

    )
    module = AnsibleModule(
        argument_spec=module_args,
        supports_check_mode=True
    )
    fc_attr_spec_manager = FcVmAttrSpecManager(module)
    fc_attr_spec_manager.execute()


def main():
    run_module()


if __name__ == '__main__':
    main()
