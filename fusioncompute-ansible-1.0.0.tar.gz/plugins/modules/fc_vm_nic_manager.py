#!/usr/bin/env python
# -*- coding:utf-8 -*-
#  Copyright (c) Huawei Technologies Co., Ltd. 2024-2024. All rights reserved.
from http import HTTPStatus
from enum import Enum

from ansible.module_utils.basic import AnsibleModule
from ansible_collections.huawei.fusioncompute.plugins.module_utils.core.fusincompute import logger
from ansible_collections.huawei.fusioncompute.plugins.module_utils.param_validator import hostname_validator_fn
from ansible_collections.huawei.fusioncompute.plugins.module_utils.decorator import action_injector, validator_injector
from ansible_collections.huawei.fusioncompute.plugins.module_utils.basic import FcAttrValidator, FcModuleBase
from ansible_collections.huawei.fusioncompute.plugins.module_utils.core.parameter_normalization import normalize

ANSIBLE_METADATA = {
    'metadata_version': '1.0.0',
    'status': ['preview'],
    'supported_by': 'standard'
}

DOCUMENTATION = '''
---
module: huawei.fusioncompute.fc_vm_nic_manager

short_description: Manage network interface cards (NICs) for virtual machines (VMs) on Huawei FusionCompute.

version_added: "1.0.0"

description:
    - This module allows you to manage network interface cards (NICs) for virtual machines (VMs) on Huawei FusionCompute.
    - It supports querying, creating, modifying, deleting, configuring, and configuring security groups for NICs.

options:
    action:
        description:
            - The action to perform.
            - Supported actions are 'query', 'create', 'modify', 'delete', 'config', 'config_sg' and 'config_conn'.
        required: true
        type: str
        choices: ['query', 'create', 'modify', 'delete', 'config', 'config_sg', 'config_conn']

    vm_id:
        description:
            - The ID of the virtual machine (VM) for which the NIC operation is to be performed.
        required: true
        type: str

    nic_id:
        description:
            - The ID of the NIC to be managed.
        required: false
        type: str

    name:
        description:
            - The name of the NIC.
        required: false
        type: str

    portGroupUrn:
        description:
            - The URN (Uniform Resource Name) of the port group to which the NIC belongs.
        required: false
        type: str

    mac:
        description:
            - The MAC address of the NIC.
        required: false
        type: str

    sequenceNum:
        description:
            - The sequence number of the NIC.
        required: false
        type: str

    virtIo:
        description:
            - Whether the NIC uses VirtIO.
        required: false
        type: int

    portId:
        description:
            - The port ID of the NIC.
        required: false
        type: int

    nicConfig:
        description:
            - The configuration of the NIC.
        required: false
        type: dict

    enableSecurityGroup:
        description:
            - Whether to enable the security group for the NIC.
        required: false
        type: bool

    securityGroupId:
        description:
            - The ID of the security group for the NIC.
        required: false
        type: int

    nicSpecification:
        description:
            - The specification of the NIC.
        required: false
        type: dict

    connectAtPowerOn:
        description:
            - Whether the NIC should connect at power-on.
        required: false
        type: bool

    linkStatus:
        description:
            - The link status of the NIC.
        required: false
        type: str

    neutronPortId:
        description:
            - The Neutron port ID of the NIC.
        required: false
        type: str

    # Parameters inherited from FcModuleBase:
    fc_hostname:
        description:
            - Host name or IP address of the FusionCompute VRM.
        required: true
        type: str

    fc_port:
        description:
            - Port number to connect to the FusionCompute VRM. Default is 7443.
        required: false
        default: 7443
        type: int

    fc_token:
        description:
            - Token for authentication. If provided, the module will skip login and use this token for authentication.
        required: false
        type: str

    fc_username:
        description:
            - Username for FusionCompute authentication.
        required: false
        type: str

    fc_password:
        description:
            - Password for authentication on the FusionCompute VRM.
        required: false
        type: str
        no_log: true
    
    fc_site_id:
        description:
            - Site ID for FusionCompute. If provided, the module will skip retrieving  site id and use this site ID.
        required: false
        type: str

    fc_language:
        description:
            - Language used for communication with FusionCompute VRM. Default is 'en-US'.
        required: false
        default: 'en-US'
        type: str

    fc_verify:
        description:
            - Path to rootCA.crt file for SSL certificate verification. If empty, SSL verification will be disabled.
        required: false
        default: ''
        type: str

author:
    - Huawei Technologies Co., Ltd.
'''

EXAMPLES = '''
# Query a NIC
- name: Query a NIC
  huawei.fusioncompute.fc_vm_nic_manager:
    action: query
    fc_hostname: "192.168.1.100"
    fc_token: "xxxx"
    vm_id: "i-xxxxxxxx"
    nic_id: "1"
    register: result

- name: Debug the result
  debug:
    var: result
'''

RETURN = '''
ret:
    description: The response from the FusionCompute API.
    type: dict
    returned: always
    contains:
        code:
            description: The HTTP status code of the operation.
            type: int
            returned: always
        rsp:
            description: The response body returned by the API.
            type: dict
            returned: always
'''


class ManageAction(Enum):
    query = 'query'
    delete = 'delete'
    create = 'create'
    modify = 'modify'
    config = 'config'
    config_sg = 'config_sg'
    config_conn = 'config_conn'
    modify_pg = 'modify_pg'
    modify_mac = 'modify_mac'


@action_injector(ManageAction)
@validator_injector([FcAttrValidator('fc_hostname', hostname_validator_fn)])
class FcVmNicManager(FcModuleBase):
    def __init__(self, module):
        super(FcVmNicManager, self).__init__(module)

    def execute(self):
        validate_res = self.validate()
        if validate_res:
            logger.info("fc vm inc manager validate failed %s", validate_res)
            self.module.fail_json(msg=validate_res)
        action: ManageAction = self.action
        match action:
            case ManageAction.query:
                ret, rsp = self.do_query()
            case ManageAction.create:
                ret, rsp = self.do_create()
            case ManageAction.modify:
                ret, rsp = self.do_modify()
            case ManageAction.delete:
                ret, rsp = self.do_delete()
            case ManageAction.config:
                ret, rsp = self.do_config()
            case ManageAction.config_sg:
                ret, rsp = self.do_config_sg()
            case ManageAction.config_conn:
                ret, rsp = self.do_config_conn()
            case ManageAction.modify_pg:
                ret, rsp = self.do_modify_pg()
            case _:
                self.module.fail_json(
                    changed=False, msg='param action type invalid.')
        if ret != HTTPStatus.OK:
            self.module.fail_json(
                msg="Couldn't manage vm nic: ret: %s, rsp: %s" % (ret, rsp.json()))
        else:
            self.module.exit_json(
                changed=(action not in (ManageAction.query,)), ret={'code': ret, 'rsp': rsp})

    def do_query(self):
        vm_id = self.params['vm_id']
        nic_id = self.params['nic_id']
        url = self.client.url_generator.vm_nics_network(
            self.client.site_id, vm_id, nic_id)
        return self.client.get(url)

    def do_create(self):
        vm_id = self.params['vm_id']
        name = self.params['name']
        port_group_urn = self.params['portGroupUrn']
        mac = self.params['mac']
        sequence_num = self.params['sequenceNum']
        virt_io = self.params['virtIo']
        port_id = self.params['portId']
        nic_config = self.params['nicConfig']
        enable_security_group = self.params['enableSecurityGroup']
        security_group_id = self.params['securityGroupId']
        nic_specification = self.params['nicSpecification']
        connect_at_power_on = self.params['connectAtPowerOn']
        link_status = self.params['linkStatus']
        enable_security_group = self.params['enableSecurityGroup']
        security_group_id = self.params['securityGroupId']
        data = {
            'name': name,
            'portGroupUrn': port_group_urn,
            'mac': mac,
            'sequenceNum': sequence_num,
            'virtIo': virt_io,
            'portId': port_id,
            'nicConfig': nic_config,
            'enableSecurityGroup': enable_security_group,
            'securityGroupId': security_group_id,
            'nicSpecification': nic_specification,
            'connectAtPowerOn': connect_at_power_on,
            'linkStatus': link_status
        }
        url = self.client.url_generator.vm_virtual_nics(
            self.client.site_id, vm_id)
        return self.client.post(url, normalize(data))

    def do_modify(self):
        vm_id = self.params['vm_id']
        nic_id = self.params['nic_id']
        name = self.params['name']
        port_group_urn = self.params['portGroupUrn']
        mac = self.params['mac']
        nic_config = self.params['nicConfig']
        neutron_port_id = self.params['neutronPortId']
        data = {
            'name': name,
            'portGroupUrn': port_group_urn,
            'mac': mac,
            'neutronPortId': neutron_port_id,
            'nicConfig': nic_config,
        }
        url = self.client.url_generator.vm_nics(
            self.client.site_id, vm_id, nic_id)
        return self.client.put(url, normalize(data))

    def do_config(self):
        vm_id = self.params['vm_id']
        nic_id = self.params['nic_id']
        nic_specification = self.params['nicSpecification']
        data = {
            'nicSpecification': nic_specification,
        }
        url = self.client.url_generator.vm_nics_network(
            self.client.site_id, vm_id, nic_id)
        return self.client.put(url, normalize(data))

    def do_delete(self):
        vm_id = self.params['vm_id']
        nic_id = self.params['nic_id']
        url = self.client.url_generator.vm_virtual_nics(
            self.client.site_id, vm_id, nic_id)
        return self.client.delete(url)

    def do_config_sg(self):
        vm_id = self.params['vm_id']
        nic_id = self.params['nic_id']
        enable_security_group = self.params['enableSecurityGroup']
        security_group_id = self.params['securityGroupId']
        enable_security_group = self.params['enableSecurityGroup']
        security_group_id = self.params['securityGroupId']
        data = {
            'enableSecurityGroup': enable_security_group,
            'securityGroupId': security_group_id,
        }
        url = self.client.url_generator.vm_nics_sg(
            self.client.site_id, vm_id, nic_id)
        return self.client.put(url, normalize(data))

    def do_config_conn(self):
        vm_id = self.params['vm_id']
        nic_ids = self.params['nicIds']
        connect_at_power_on = self.params['connectAtPowerOn']
        link_status = self.params['linkStatus']
        data = {
            'nicIds': nic_ids,
            'linkStatus': link_status,
            'connectAtPowerOn': connect_at_power_on,
        }
        url = self.client.url_generator.vm_virtual_nics_link(
            self.client.site_id, vm_id)
        return self.client.put(url, data)

    def do_modify_pg(self):
        vm_id = self.params['vm_id']
        nic_id = self.params['nic_id']
        port_group_urn = self.params['portGroupUrn']
        data = {
            'portGroupUrn': port_group_urn,
        }
        url = self.client.url_generator.vm_nics_pg(
            self.client.site_id, vm_id, nic_id)
        return self.client.put(url, data)


def run_module():
    # define available arguments/parameters a user can pass to the module
    module_args = FcModuleBase.args()
    module_args.update(
        action=dict(type='str', required=True),
        vm_id=dict(type='str', required=False),
        nic_id=dict(type='str', required=False),
        nicIds=dict(type='list', required=False),
        limit=dict(type='int', required=False),
        offset=dict(type='int', required=False),
        name=dict(type='str', required=False),
        portGroupUrn=dict(type='str', required=False),
        mac=dict(type='str', required=False),
        sequenceNum=dict(type='str', required=False),
        virtIo=dict(type=int, required=False),
        portId=dict(type='int', required=False),
        nicConfig=dict(type='dict', required=False),
        enableSecurityGroup=dict(type='bool', required=False),
        securityGroupId=dict(type='int', required=False),
        nicSpecification=dict(type='dict', required=False),
        connectAtPowerOn=dict(type='bool', required=False),
        linkStatus=dict(type='str', required=False),
        neutronPortId=dict(type='str', required=False),
    )
    module = AnsibleModule(
        argument_spec=module_args,
        supports_check_mode=True
    )
    fc_vm_nic_manager = FcVmNicManager(module)
    fc_vm_nic_manager.execute()


def main():
    run_module()


if __name__ == '__main__':
    main()
