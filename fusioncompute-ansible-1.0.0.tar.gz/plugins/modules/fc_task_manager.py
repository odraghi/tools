#!/usr/bin/env python
# -*- coding:utf-8 -*-
#  Copyright (c) Huawei Technologies Co., Ltd. 2024-2024. All rights reserved.
import time
from http import HTTPStatus
from enum import Enum

from ansible.module_utils.basic import AnsibleModule
from ansible_collections.huawei.fusioncompute.plugins.module_utils.core.fusincompute import logger
from ansible_collections.huawei.fusioncompute.plugins.module_utils.param_validator import hostname_validator_fn
from ansible_collections.huawei.fusioncompute.plugins.module_utils.decorator import action_injector, validator_injector
from ansible_collections.huawei.fusioncompute.plugins.module_utils.basic import FcAttrValidator, FcModuleBase
from ansible_collections.huawei.fusioncompute.plugins.module_utils.core.parameter_normalization import normalize
from ansible_collections.huawei.fusioncompute.plugins.module_utils.entity.enum.basic import FcTaskStatus

ANSIBLE_METADATA = {
    'metadata_version': '1.0.0',
    'status': ['preview'],
    'supported_by': 'standard'
}

DOCUMENTATION = '''
---
module: huawei.fusioncompute.fc_task_manager

short_description: Manage FusionCompute tasks (query, pagination, cancel, complete)

version_added: "1.0.0"

description:
    - "This module manages tasks on FusionCompute. It supports querying task status, pagination, 
       canceling tasks, and completing tasks."
    - "The module can query the status of a specific task, list tasks with pagination, 
       cancel a running task, or wait for a task to complete."

options:
    action:
        description:
            - Specify the action to be performed. Supported actions are "query", "pagination", "cancel", and "complete".
        required: true
        choices: ['query', 'pagination', 'cancel', 'complete']

    # Additional parameters for specific actions
    task_id:
        description:
            - The ID of the task to query, cancel, or complete.
        required: false
    
    fc_pull_interval:
        description:
            - The interval (in seconds) between task status queries when completing a task.
        required: false
        default: 1
    
    fc_wait_timeout:
        description:
            - The maximum time (in seconds) to wait for a task to complete. Use -1 for no timeout.
        required: false
        default: -1
    
    limit:
        description:
            - The maximum number of tasks to return in pagination mode.
        required: false
    
    offset:
        description:
            - The starting index for pagination.
        required: false
    
    scope:
        description:
            - The scope of tasks to query in pagination mode.
        required: false
    
    type:
        description:
            - The type of tasks to query in pagination mode.
        required: false
    
    user:
        description:
            - The user associated with the tasks to query in pagination mode.
        required: false
    
    status:
        description:
            - The status of tasks to query in pagination mode.
        required: false
    
    startTime:
        description:
            - The start time for filtering tasks in pagination mode.
        required: false
    
    finishTime:
        description:
            - The finish time for filtering tasks in pagination mode.
        required: false
    
    taskUrns:
        description:
            - A list of task URNs to filter tasks in pagination mode.
        required: false
    
    cancelled:
        description:
            - Whether to include canceled tasks in pagination mode.
        required: false
    
    # Parameters inherited from FcModuleBase:
    fc_hostname:
        description:
            - Host name or IP address of the FusionCompute VRM.
        required: true
        type: str

    fc_port:
        description:
            - Port number to connect to the FusionCompute VRM. Default is 7443.
        required: false
        default: 7443
        type: int

    fc_token:
        description:
            - Token for authentication. If provided, the module will skip login and use this token for authentication.
        required: false
        type: str

    fc_username:
        description:
            - Username for FusionCompute authentication.
        required: false
        type: str

    fc_password:
        description:
            - Password for authentication on the FusionCompute VRM.
        required: false
        type: str
        no_log: true
    
    fc_site_id:
        description:
            - Site ID for FusionCompute. If provided, the module will skip retrieving  site id and use this site ID.
        required: false
        type: str

    fc_language:
        description:
            - Language used for communication with FusionCompute VRM. Default is 'en-US'.
        required: false
        default: 'en-US'
        type: str

    fc_verify:
        description:
            - Path to rootCA.crt file for SSL certificate verification. If empty, SSL verification will be disabled.
        required: false
        default: ''
        type: str

author:
    - Huawei Technologies Co., Ltd.
'''

EXAMPLES = '''
# Query the status of a task
- name: Query task status
    huawei.fusioncompute.fc_task_manager:
    action: query
    fc_hostname: "192.168.1.100"
    fc_token: "xxxx"
    task_id: "xxx"

# List tasks with pagination
- name: List tasks with pagination
  huawei.fusioncompute.fc_task_manager:
    action: pagination
    fc_hostname: "192.168.1.100"
    fc_token: "xxxx"
    limit: 10
    offset: 0
    user: "admin"

# Cancel a running task
- name: Cancel a task
  huawei.fusioncompute.fc_task_manager:
    action: cancel
    fc_hostname: "192.168.1.100"
    fc_token: "xxxx"
    task_id: "xxx"

# Wait for a task to complete
- name: Complete a task
  huawei.fusioncompute.fc_task_manager:
    action: complete
    fc_hostname: "192.168.1.100"
    fc_token: "xxxx"
    task_id: "xxx"
    fc_wait_timeout: 300
    fc_pull_interval: 5
'''

RETURN = '''
ret:
    description: The result of the operation, including HTTP status code and the token if login was successful
    type: dict
    returned: always
    contains:
        code:
            description: The HTTP status code of the operation
            type: int
        rsp:
            description: The response data from the operation (e.g., task details or status)
            type: dict
'''


class TaskManagerAction(Enum):
    query = 'query'
    pagination = 'pagination'
    cancel = 'cancel'
    complete = 'complete'


@action_injector(TaskManagerAction)
@validator_injector([FcAttrValidator('fc_hostname', hostname_validator_fn)])
class FcTaskManager(FcModuleBase):
    def __init__(self, module):
        super(FcTaskManager, self).__init__(module)

    def _query_task(self, task_id):
        url = self.client.url_generator.task(
            self.client.site_id, task_id)
        ret, rsp = self.client.get(url)
        return ret, rsp

    def _complete_task(self, task_id, timeout, interval, allow_faulty=True):
        """
        Completes a task by checking its status at regular intervals.

        :param task_id: The ID of the task to query
        :param timeout: The maximum time (in seconds) to wait for the task to complete
        :param interval: The time (in seconds) to wait between queries
        """
        start_time = time.time()
        while True:
            # Query the task status
            ret, rsp = self._query_task(task_id)
            if ret != HTTPStatus.OK and not allow_faulty:
                return ret, rsp
            if ret == HTTPStatus.OK:
                try:
                    status = FcTaskStatus(rsp['status'])
                except ValueError:
                    status = FcTaskStatus.unknown
                match status:
                    case FcTaskStatus.success:
                        return FcTaskStatus.success, rsp
                    case FcTaskStatus.running:
                        # just waiting
                        logger.debug(
                            "Task %s is running with rsp:%s", task_id, rsp)
                        pass
                    case FcTaskStatus.failed:
                        logger.warning(
                            "Task %s failed with rsp:%s", task_id, rsp)
                        return FcTaskStatus.failed, rsp
                    case _:
                        if not allow_faulty:
                            return FcTaskStatus.unknown, rsp
                        else:
                            pass
            # Check if the timeout has been reached
            if timeout != -1 and time.time() - start_time > timeout:
                logger.warning("Task %s timed out.", task_id)
                return FcTaskStatus.running, rsp
            # Wait for the next interval before querying again
            time.sleep(interval)

    def execute(self):
        validate_res = self.validate()
        if validate_res:
            logger.error(
                "fc task manager params validate failed %s", validate_res)
            self.module.fail_json(msg=validate_res)
        action: TaskManagerAction = self.action
        match action:
            case TaskManagerAction.query:
                task_id = self.params['task_id']
                ret, rsp = self._query_task(task_id)
            case TaskManagerAction.pagination:
                ret, rsp = self.do_pagination()
            case TaskManagerAction.cancel:
                task_id = self.params['task_id']
                url = self.client.url_generator.task_cancel(
                    self.client.site_id, task_id)
                ret, rsp = self.client.post(url, {})
            case TaskManagerAction.complete:
                # Note: will just exit module here.
                self.do_complete()
            case _:
                self.module.fail_json(
                    changed=False, msg='param action type invalid.')
        if ret not in [HTTPStatus.OK, HTTPStatus.NO_CONTENT]:
            self.module.fail_json(
                msg="Couldn't manage task: ret: %s, rsp: %s" % (ret, rsp.content))
        else:
            if ret == HTTPStatus.NO_CONTENT:
                rsp = ''
            self.module.exit_json(
                changed=(action in (TaskManagerAction.cancel,
                         TaskManagerAction.complete)),
                ret={'code': ret, 'rsp': rsp})

    def do_complete(self):
        task_id = self.params['task_id']
        fc_wait_timeout = self.params['fc_wait_timeout']
        fc_pull_interval = self.params['fc_pull_interval']
        ret_status, rsp = self._complete_task(
            task_id, fc_wait_timeout, fc_pull_interval)
        if ret_status == FcTaskStatus.success:
            self.module.exit_json(
                changed=True, ret={'code': HTTPStatus.OK, 'rsp': rsp}
            )
        else:
            self.module.fail_json(
                msg="Couldn't complete task: ret_status: %s, rsp: %s" % (
                    ret_status, rsp)
            )

    def do_pagination(self):
        limit = self.params['limit']
        offset = self.params['offset']
        scope = self.params['scope']
        type = self.params['type']
        user = self.params['user']
        status = self.params['status']
        start_time = self.params['startTime']
        finish_time = self.params['finishTime']
        task_urns = self.params['taskUrns']
        cancelled = self.params['cancelled']
        params = {
            'limit': limit,
            'offset': offset,
            'scope': scope,
            'type': type,
            'user': user,
            'status': status,
            'startTime': start_time,
            'finishTime': finish_time,
            'taskUrns': task_urns,
            'cancelled': cancelled
        }
        url = self.client.url_generator.task(
            self.client.site_id)
        return self.client.get(url, normalize(params))


def run_module():
    # define available arguments/parameters a user can pass to the module
    module_args = FcModuleBase.args()
    module_args.update(
        action=dict(type='str', required=True),
        task_id=dict(type='str', required=False),
        # for complete
        fc_pull_interval=dict(type='int', required=False, default=1),
        fc_wait_timeout=dict(type='int', required=False, default=-1),
        # for pagination
        limit=dict(type='int', required=False),
        offset=dict(type='int', required=False),
        scope=dict(type='str', required=False),
        type=dict(type='str', required=False),
        user=dict(type='str', required=False),
        status=dict(type='str', required=False),
        startTime=dict(type='str', required=False),
        finishTime=dict(type='str', required=False),
        taskUrns=dict(type='list', required=False),
        cancelled=dict(type='bool', required=False),
    )
    module = AnsibleModule(
        argument_spec=module_args,
        supports_check_mode=True
    )
    fc_task_manager = FcTaskManager(module)
    fc_task_manager.execute()


def main():
    run_module()


if __name__ == '__main__':
    main()
