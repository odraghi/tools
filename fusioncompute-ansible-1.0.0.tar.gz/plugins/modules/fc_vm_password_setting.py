#!/usr/bin/env python
# -*- coding:utf-8 -*-
#  Copyright (c) Huawei Technologies Co., Ltd. 2024-2024. All rights reserved.
from http import HTTPStatus

from ansible.module_utils.basic import AnsibleModule
from ansible_collections.huawei.fusioncompute.plugins.module_utils.core.fusincompute import logger
from ansible_collections.huawei.fusioncompute.plugins.module_utils.param_validator import hostname_validator_fn
from ansible_collections.huawei.fusioncompute.plugins.module_utils.decorator import validator_injector
from ansible_collections.huawei.fusioncompute.plugins.module_utils.basic import FcAttrValidator, FcModuleBase
from ansible_collections.huawei.fusioncompute.plugins.module_utils.core.parameter_normalization import normalize

ANSIBLE_METADATA = {
    'metadata_version': '1.0.0',
    'status': ['preview'],
    'supported_by': 'standard'
}

DOCUMENTATION = '''
---
module: huawei.fusioncompute.fc_vm_password_setting

short_description: Set password for FusionCompute VM

version_added: "1.0.0"

description:
    - "This module is used to set the password for a virtual machine (VM) in FusionCompute."
    - "It allows users to specify a VM ID, username, and password to change the VM password."

options:
    vm_id:
        description:
            - The ID of the virtual machine (VM) whose password is to be set.
        required: true
        type: str

    userName:
        description:
            - The username for which the password is being set.
        required: true
        type: str

    password:
        description:
            - The new password to be set for the specified username.
        required: true
        type: str
        no_log: true

    # Parameters inherited from FcModuleBase:
    fc_hostname:
        description:
            - Host name or IP address of the FusionCompute VRM.
        required: true
        type: str

    fc_port:
        description:
            - Port number to connect to the FusionCompute VRM. Default is 7443.
        required: false
        default: 7443
        type: int

    fc_token:
        description:
            - Token for authentication. If provided, the module will skip login and use this token for authentication.
        required: false
        type: str

    fc_username:
        description:
            - Username for FusionCompute authentication.
        required: false
        type: str

    fc_password:
        description:
            - Password for authentication on the FusionCompute VRM.
        required: false
        type: str
        no_log: true
    
    fc_site_id:
        description:
            - Site ID for FusionCompute. If provided, the module will skip retrieving  site id and use this site ID.
        required: false
        type: str

    fc_language:
        description:
            - Language used for communication with FusionCompute VRM. Default is 'en-US'.
        required: false
        default: 'en-US'
        type: str

    fc_verify:
        description:
            - Path to rootCA.crt file for SSL certificate verification. If empty, SSL verification will be disabled.
        required: false
        default: ''
        type: str

author:
    - Huawei Technologies Co., Ltd.
'''

EXAMPLES = '''
# Bind a PCI device to a VM
- name: Change vm password
  huawei.fusioncompute.fc_vm_password_setting:
    fc_hostname: "192.168.1.100"
    fc_token: "xxxx"
    vm_id: "i-xxxxxxxx"
    userName: "ansible"
    password: "xxxxxxxx"
  register: result

- name: Debug the result
  debug:
    var: result
'''

RETURN = '''
ret:
    description: The response from the FusionCompute API.
    type: dict
    returned: always
    contains:
        code:
            description: The HTTP status code of the operation.
            type: int
            returned: always
        rsp:
            description: The response body returned by the API.
            type: dict
            returned: always
'''


@validator_injector([FcAttrValidator('fc_hostname', hostname_validator_fn)])
class FcVmPasswordSetting(FcModuleBase):
    def __init__(self, module):
        super(FcVmPasswordSetting, self).__init__(module)

    def execute(self):
        validate_res = self.validate()
        if validate_res:
            logger.info("fc token manager validate failed %s", validate_res)
            self.module.fail_json(msg=validate_res)
        vm_id = self.params['vm_id']
        username = self.params['userName']
        password = self.params['password']
        data = {'userName': username,
                'password': password,
                }
        url = self.client.url_generator.vm_set_password(
            self.client.site_id, vm_id)
        ret, rsp = self.client.put(
            url,
            normalize(data)
        )
        if ret != HTTPStatus.OK:
            self.module.fail_json(
                msg="Couldn't set vm password: ret: %s, rsp: %s" % (ret, rsp.json()))
        else:
            self.module.exit_json(
                changed=True, ret={'code': ret, 'rsp': rsp})


def run_module():
    # define available arguments/parameters a user can pass to the module
    module_args = FcModuleBase.args()
    module_args.update(
        vm_id=dict(type='str', required=True),
        userName=dict(type='str', required=True),
        password=dict(type='str', required=True),
    )
    module = AnsibleModule(
        argument_spec=module_args,
        supports_check_mode=True
    )
    fc_vm_password_setting = FcVmPasswordSetting(module)
    fc_vm_password_setting.execute()


def main():
    run_module()


if __name__ == '__main__':
    main()
