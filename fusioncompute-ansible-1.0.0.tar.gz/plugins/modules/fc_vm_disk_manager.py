#!/usr/bin/env python
# -*- coding:utf-8 -*-
#  Copyright (c) Huawei Technologies Co., Ltd. 2024-2024. All rights reserved.
from http import HTTPStatus
from enum import Enum

from ansible.module_utils.basic import AnsibleModule
from ansible_collections.huawei.fusioncompute.plugins.module_utils.core.fusincompute import logger
from ansible_collections.huawei.fusioncompute.plugins.module_utils.param_validator import hostname_validator_fn
from ansible_collections.huawei.fusioncompute.plugins.module_utils.decorator import action_injector, validator_injector
from ansible_collections.huawei.fusioncompute.plugins.module_utils.basic import FcAttrValidator, FcModuleBase
from ansible_collections.huawei.fusioncompute.plugins.module_utils.core.parameter_normalization import normalize

ANSIBLE_METADATA = {
    'metadata_version': '1.0.0',
    'status': ['preview'],
    'supported_by': 'standard'
}

DOCUMENTATION = '''
---
module: huawei.fusioncompute.fc_vm_disk_manager

short_description: Manage disk operations for virtual machines (VMs) on Huawei FusionCompute.

version_added: "1.0.0"

description:
    - This module allows you to manage disk operations for virtual machines (VMs) on Huawei FusionCompute.
    - It supports attaching, detaching, creating, and changing I/O modes for VM disks.

options:
    action:
        description:
            - The action to perform.
            - Supported actions are 'attach', 'detach', 'create', 'create_attach', 'query', and 'change_io_mode'.
        required: true
        type: str
        choices: ['attach', 'detach', 'create', 'create_attach', 'query', 'change_io_mode']

    vm_id:
        description:
            - The ID of the virtual machine (VM) for which the disk operation is to be performed.
        required: true
        type: str

    volumeId:
        description:
            - The ID of the volume to be managed.
        required: false
        type: str

    name:
        description:
            - The name of the disk to be created or attached.
        required: false
        type: str

    quantityGB:
        description:
            - The size of the disk in gigabytes (GB).
        required: false
        type: int

    datastoreUrn:
        description:
            - The URN (Uniform Resource Name) of the datastore where the disk will be created.
        required: false
        type: str

    isThin:
        description:
            - Whether the disk should be thin-provisioned.
        required: false
        type: bool

    type:
        description:
            - The type of disk to be created or attached.
        required: false
        type: str

    indepDisk:
        description:
            - Whether the disk is independent.
        required: false
        type: bool

    persistentDisk:
        description:
            - Whether the disk is persistent.
        required: false
        type: bool

    volType:
        description:
            - The type of volume to be created or attached.
        required: false
        type: int

    sequenceNum:
        description:
            - The sequence number of the disk.
        required: false
        type: int

    pciType:
        description:
            - The PCI type of the disk.
        required: false
        type: str

    scsiCommandPassthrough:
        description:
            - Whether SCSI command passthrough is enabled for the disk.
        required: false
        type: bool

    ioMode:
        description:
            - The I/O mode for the disk.
            - Required for 'change_io_mode' action.
        required: false
        type: str

    accessMode:
        description:
            - The access mode for the disk.
        required: false
        type: int

    volumeFormat:
        description:
            - The format for the disk.
        required: false
        type: str

    blockIoHangTimeout:
        description:
            - The block I/O hang timeout for the disk.
        required: false
        type: int

    encrypted:
        description:
            - Whether the disk is encrypted.
        required: false
        type: int

    storageProtocol:
        description:
            - The storage protocol for the disk.
        required: false
        type: str

    volUrn:
        description:
            - The URN (Uniform Resource Name) of the volume to be attached or detached.
        required: false
        type: str

    isFormat:
        description:
            - Whether to format the disk when detaching it.
        required: false
        type: bool

    # Parameters inherited from FcModuleBase:
    fc_hostname:
        description:
            - Host name or IP address of the FusionCompute VRM.
        required: true
        type: str

    fc_port:
        description:
            - Port number to connect to the FusionCompute VRM. Default is 7443.
        required: false
        default: 7443
        type: int

    fc_token:
        description:
            - Token for authentication. If provided, the module will skip login and use this token for authentication.
        required: false
        type: str

    fc_username:
        description:
            - Username for FusionCompute authentication.
        required: false
        type: str

    fc_password:
        description:
            - Password for authentication on the FusionCompute VRM.
        required: false
        type: str
        no_log: true
    
    fc_site_id:
        description:
            - Site ID for FusionCompute. If provided, the module will skip retrieving  site id and use this site ID.
        required: false
        type: str

    fc_language:
        description:
            - Language used for communication with FusionCompute VRM. Default is 'en-US'.
        required: false
        default: 'en-US'
        type: str

    fc_verify:
        description:
            - Path to rootCA.crt file for SSL certificate verification. If empty, SSL verification will be disabled.
        required: false
        default: ''
        type: str

author:
    - Huawei Technologies Co., Ltd.
'''

EXAMPLES = '''
# Attach a disk to a VM
- name: Attach a disk to a VM
  huawei.fusioncompute.fc_vm_disk_manager:
    action: attach
    fc_hostname: "192.168.1.100"
    fc_token: "xxxx"
    vm_id: "i-xxxxxxxx"
    volUrn: "urn:sites:xxxxxx:volumes:xxx"
    quantityGB: 100
    datastoreUrn: "urn:sites:xxxxxx:datastores:xxx"
    isThin: true
    type: "data"
    indepDisk: false
    persistentDisk: true
    volType: 1
    sequenceNum: 1
    pciType: "pci"
    scsiCommandPassthrough: false
    ioMode: "readwrite"
    accessMode: 1
    blockIoHangTimeout: 60
    encrypted: 0
  register: result

# Detach a disk from a VM
- name: Detach a disk from a VM
  huawei.fusioncompute.fc_vm_disk_manager:
    action: detach
    fc_hostname: "192.168.1.100"
    fc_token: "xxxx"
    vm_id: "i-xxxxxxxx"
    volUrn: "urn:sites:xxxxxx:volumes:xxx"
    isFormat: false
  register: result

# attach a disk to a VM
- name: Detach a disk from a VM
  huawei.fusioncompute.fc_vm_disk_manager:
    action: attach
    fc_hostname: "192.168.1.100"
    fc_token: "xxxx"
    vm_id: "i-xxxxxxxx"
    volUrn: "urn:sites:xxxxxx:volumes:xxx"
  register: result

- name: Debug the result
  debug:
    var: result
'''

RETURN = '''
ret:
    description: The result of the operation, including HTTP status code and the token if login was successful
    type: dict
    returned: always
    contains:
        code:
            description: The HTTP status code of the operation
            type: int
        fc-token:
            description: The token returned if the action is login
            type: str
'''


class DiskAction(Enum):
    attach = 'attach'
    detach = 'detach'
    create = 'create'
    create_attach = 'create_attach'
    query = 'query'
    change_io_mode = 'change_io_mode'


@action_injector(DiskAction)
@validator_injector([FcAttrValidator('fc_hostname', hostname_validator_fn)])
class FcVmDiskManager(FcModuleBase):
    def __init__(self, module):
        super(FcVmDiskManager, self).__init__(module)

    def execute(self):
        validate_res = self.validate()
        if validate_res:
            logger.info("fc token manager validate failed %s", validate_res)
            self.module.fail_json(msg=validate_res)
        action: DiskAction = self.action
        match action:
            case DiskAction.create_attach:
                ret, rsp = self.do_create_attach()
            case DiskAction.attach:
                ret, rsp = self.do_attach()
            case DiskAction.detach:
                ret, rsp = self.do_detach()
            case DiskAction.change_io_mode:
                ret, rsp = self.do_change_io_mode()
            case _:
                self.module.fail_json(
                    changed=False, msg='param action type invalid.')
        if ret != HTTPStatus.OK:
            self.module.fail_json(
                msg="Couldn't manage vm disk: ret: %s, rsp: %s" % (ret, rsp.json()))
        else:
            self.module.exit_json(
                changed=(action != DiskAction.query), ret={'code': ret, 'rsp': rsp})

    def do_create_attach(self):
        vm_id = self.params['vm_id']
        name = self.params['name']
        quantity_gb = self.params['quantityGB']
        datastore_urn = self.params['datastoreUrn']
        is_thin = self.params['isThin']
        disk_type = self.params['type']
        indep_disk = self.params['indepDisk']
        persistent_disk = self.params['persistentDisk']
        vol_type = self.params['volType']
        sequence_num = self.params['sequenceNum']
        pci_type = self.params['pciType']
        scsi_command_passthrough = self.params['scsiCommandPassthrough']
        io_mode = self.params['ioMode']
        access_mode = self.params['accessMode']
        volume_format = self.params['volumeFormat']
        block_io_hang_timeout = self.params['blockIoHangTimeout']
        encrypted = self.params['encrypted']
        storage_protocol = self.params['storageProtocol']
        workload_type_id = self.params['workloadTypeId']
        data = {
            'name': name,
            'quantityGB': quantity_gb,
            'datastoreUrn': datastore_urn,
            'isThin': is_thin,
            'type': disk_type,
            'indepDisk': indep_disk,
            'persistentDisk': persistent_disk,
            'volType': vol_type,
            'sequenceNum': sequence_num,
            'pciType': pci_type,
            'scsiCommandPassthrough': scsi_command_passthrough,
            'ioMode': io_mode,
            'accessMode': access_mode,
            'volumeFormat': volume_format,
            'blockIoHangTimeout': block_io_hang_timeout,
            'encrypted': encrypted,
            'storageProtocol': storage_protocol,
            'workloadTypeId': workload_type_id,
        }
        url = self.client.url_generator.vm_vol_create_attach(
            self.client.site_id, vm_id)
        return self.client.post(url, normalize(data))

    def do_attach(self):
        vm_id = self.params['vm_id']
        quantity_gb = self.params['quantityGB']
        datastore_urn = self.params['datastoreUrn']
        is_thin = self.params['isThin']
        disk_type = self.params['type']
        indep_disk = self.params['indepDisk']
        persistent_disk = self.params['persistentDisk']
        vol_type = self.params['volType']
        sequence_num = self.params['sequenceNum']
        pci_type = self.params['pciType']
        scsi_command_passthrough = self.params['scsiCommandPassthrough']
        io_mode = self.params['ioMode']
        access_mode = self.params['accessMode']
        block_io_hang_timeout = self.params['blockIoHangTimeout']
        encrypted = self.params['encrypted']
        storage_protocol = self.params['storageProtocol']
        vol_urn = self.params['volUrn']
        data = {
            'volUrn': vol_urn,
            'quantityGB': quantity_gb,
            'datastoreUrn': datastore_urn,
            'isThin': is_thin,
            'type': disk_type,
            'indepDisk': indep_disk,
            'persistentDisk': persistent_disk,
            'volType': vol_type,
            'sequenceNum': sequence_num,
            'pciType': pci_type,
            'scsiCommandPassthrough': scsi_command_passthrough,
            'ioMode': io_mode,
            'accessMode': access_mode,
            'blockIoHangTimeout': block_io_hang_timeout,
            'encrypted': encrypted,
            'storageProtocol': storage_protocol,
        }
        url = self.client.url_generator.vm_vol_attach(
            self.client.site_id, vm_id)
        return self.client.post(url, normalize(data))

    def do_detach(self):
        vm_id = self.params['vm_id']
        vol_urn = self.params['volUrn']
        is_format = self.params['isFormat']
        data = {
            'volUrn': vol_urn,
            'isFormat': is_format,
        }
        url = self.client.url_generator.vm_vol_detach(
            self.client.site_id, vm_id)
        return self.client.post(url, normalize(data))

    def do_change_io_mode(self):
        vm_id = self.params['vm_id']
        io_mode = self.params['ioMode']
        volume_id = self.params['volumeId']
        data = {
            'ioMode': io_mode,
            'volumeId': volume_id,
        }
        url = self.client.url_generator.vm_vol_io_mode(
            self.client.site_id, vm_id)
        return self.client.put(url, normalize(data))


def run_module():
    # define available arguments/parameters a user can pass to the module
    module_args = FcModuleBase.args()
    module_args.update(
        action=dict(type='str', required=True),
        vm_id=dict(type='str', required=False),
        volumeId=dict(type='str', required=False),
        name=dict(type='str', required=False),
        quantityGB=dict(type='int', required=False),
        datastoreUrn=dict(type='str', required=False),
        isThin=dict(type='bool', required=False),
        type=dict(type='str', required=False),
        indepDisk=dict(type='bool', required=False),
        persistentDisk=dict(type='bool', required=False),
        volType=dict(type='int', required=False),
        sequenceNum=dict(type='int', required=False),
        pciType=dict(type='str', required=False),
        scsiCommandPassthrough=dict(type='bool', required=False),
        ioMode=dict(type='str', required=False),
        accessMode=dict(type='int', required=False),
        volumeFormat=dict(type='str', required=False),
        blockIoHangTimeout=dict(type='int', required=False),
        encrypted=dict(type='int', required=False),
        storageProtocol=dict(type='str', required=False),
        workloadTypeId=dict(type='int', required=False),
        domainPassword=dict(type='str', required=False),
        nicSpecification=dict(type='list', required=False),
        ouName=dict(type='str', required=False),
        runOnce=dict(type='list', required=False),
        isUpdateVmSid=dict(type='bool', required=False),
        grubPassword=dict(type='str', required=False),
        volUrn=dict(type='str', required=False),
        isFormat=dict(type='bool', required=False),

    )
    module = AnsibleModule(
        argument_spec=module_args,
        supports_check_mode=True
    )
    fc_vm_disk_manager = FcVmDiskManager(module)
    fc_vm_disk_manager.execute()


def main():
    run_module()


if __name__ == '__main__':
    main()
