#!/usr/bin/env python
# -*- coding:utf-8 -*-
#  Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.
from urllib3.util.ssl_ import create_urllib3_context
from ansible_collections.huawei.fusioncompute.plugins.module_utils.basic import FcAttrValidator, FcModuleBase
from ansible_collections.huawei.fusioncompute.plugins.module_utils.decorator import action_injector, validator_injector
from ansible_collections.huawei.fusioncompute.plugins.module_utils.param_validator import hostname_validator_fn
from ansible_collections.huawei.fusioncompute.plugins.module_utils.core.fusincompute import logger
from ansible.module_utils.basic import AnsibleModule
from enum import Enum
from http import HTTPStatus
import json
import os
from urllib.parse import ParseResult, urlparse
import urllib3

from ansible_collections.huawei.fusioncompute.plugins.module_utils.core.cna_client import CnaClient
from ansible_collections.huawei.fusioncompute.plugins.module_utils.core.global_config import GlobalConfig
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)


ANSIBLE_METADATA = {
    'metadata_version': '1.0.1',
    'status': ['preview'],
    'supported_by': 'huawei'
}

DOCUMENTATION = '''
---
module: huawei.fusioncompute.fc_ds_file_manager

short_description: Manage ISO files in Huawei FusionCompute datastores.

version_added: "1.0.1"

description:
    - This module supports uploading, deleting, querying, and paginating ISO files in Huawei FusionCompute datastores.

options:
    action:
        description:
            - The datastore file operation to perform.
        required: true
        type: str
        choices: ['upload_iso', 'delete_iso', 'pagination_by_ds', 'query_iso']

    ds_id:
        description:
            - The datastore ID where the ISO file is located or will be uploaded.
        required: true
        type: str

    filename:
        description:
            - The name of the ISO file to upload, delete, or query.
        required: false
        type: str

    file_id:
        description:
            - The file ID to delete directly. If not specified, the module attempts to find the file by name.
        required: false
        type: str

    file_url:
        description:
            - "The URL or local path to fetch the ISO file for uploading. Supported schemes: file://, https://."
        required: false
        type: str

    is_overwrite:
        description:
            - Whether to overwrite the ISO file if it already exists in the datastore.
        required: false
        default: false
        type: bool

    offset:
        description:
            - The offset for pagination when listing files.
        required: false
        default: 0
        type: int

    limit:
        description:
            - The number of ISO files to return per page. Use -1 to fetch all.
        required: false
        default: 15
        type: int

    cna_ca_file:
        description:
            - CA file path to communicate with CNA (path on CNA: /etc/galax/certs/nginx/rootCA.crt)
        required: false
        type: str
    
    fc_params:
        description:
            - Parameters for image handling.
            - "fc_chunk_size: Upload chunk size in MB (default: 10)."
            - "fc_pull_script: Script for downloading remote ISO files."
        required: false
        type: dict

    # Parameters inherited from FcModuleBase:
    fc_hostname:
        description:
            - Host name or IP address of the FusionCompute VRM.
        required: true
        type: str

    fc_port:
        description:
            - Port number to connect to the FusionCompute VRM. Default is 7443.
        required: false
        default: 7443
        type: int

    fc_token:
        description:
            - Token for authentication. If provided, the module will skip login and use this token for authentication.
        required: false
        type: str

    fc_username:
        description:
            - Username for FusionCompute authentication.
        required: false
        type: str

    fc_password:
        description:
            - Password for authentication on the FusionCompute VRM.
        required: false
        type: str
        no_log: true

    fc_site_id:
        description:
            - Site ID for FusionCompute. If provided, the module will skip retrieving  site id and use this site ID.
        required: false
        type: str

    fc_language:
        description:
            - Language used for communication with FusionCompute VRM. Default is 'en-US'.
        required: false
        default: 'en-US'
        type: str

    fc_verify:
        description:
            - Path to rootCA.crt file for SSL certificate verification. If empty, SSL verification will be disabled.
        required: false
        default: ''
        type: str

author:
    - Huawei Technologies Co., Ltd.
'''

EXAMPLES = '''
# Upload ISO from local file with overwrite
- name: Upload ISO file to FusionCompute
  huawei.fusioncompute.fc_ds_file_manager:
    action: upload_iso
    fc_hostname: 192.168.1.100
    fc_token: "xxxxx"
    ds_id: "datastore-uuid"
    filename: "my_image.iso"
    file_url: "file:///var/lib/images/my_image.iso"
    is_overwrite: true
    fc_params:
      fc_chunk_size: 20

# Delete ISO file by name
- name: Delete ISO file
  huawei.fusioncompute.fc_ds_file_manager:
    action: delete_iso
    fc_hostname: 192.168.1.100
    fc_token: "xxxxx"
    ds_id: "datastore-uuid"
    filename: "my_image.iso"
'''

RETURN = '''
ret:
    description: The response from the FusionCompute API.
    type: dict
    returned: always
    contains:
        code:
            description: The HTTP status code returned by the API.
            type: int
            returned: always
        rsp:
            description: The response body.
            type: dict
            returned: always
'''


class DsFileManagerAction(Enum):
    upload_iso = 'upload_iso'
    pagination_by_ds = 'pagination_by_ds'
    delete_iso = 'delete_iso'
    query_iso = 'query_iso'


@action_injector(DsFileManagerAction)
@validator_injector([FcAttrValidator('fc_hostname', hostname_validator_fn)])
class FcDsFileManager(FcModuleBase):
    def __init__(self, module):
        super(FcDsFileManager, self).__init__(module)

    def execute(self):
        validate_res = self.validate()
        if validate_res:
            logger.info('fc ds file manager validate failed %s', validate_res)
            self.module.fail_json(msg=validate_res)
        self.auto_cleans = []
        action: DsFileManagerAction = self.action
        match action:
            case DsFileManagerAction.upload_iso:
                file_info = self.upload_iso()
                if file_info:
                    self.module.exit_json(changed=True, ret={
                        'iso_file_info': file_info})
                else:
                    self.module.fail_json(
                        changed=False, msg='upload iso error')
            case DsFileManagerAction.delete_iso:
                ret = self.delete_iso()
                self.module.exit_json(changed=ret, ret={
                    'flag': ret})
            case DsFileManagerAction.pagination_by_ds:
                total, file_infos = self.pagination_by_ds()
                self.module.exit_json(changed=True, ret={
                    'files': file_infos, 'total': total})
            case DsFileManagerAction.query_iso:
                file_info = self.query_iso()
                self.module.exit_json(changed=True, ret={
                    'file': file_info})

    def pagination_ds_files(self, ds_id, offset, limit):
        if limit == -1:
            all_files = self.get_ds_files(ds_id)
            return len(all_files), all_files[offset:]

        ds_url = self.client.url_generator.ds_file(self.client.site_id, ds_id)
        params = {
            'scope': f'urn%3Asites%3A{self.client.site_id}%3Adatastores%3A{ds_id}',
            'limit': limit,
            'offset': offset,
            'page': 1,
            'dataStoreID': ds_id,
        }
        ret, rsp = self.client.get(ds_url, params)
        if ret != HTTPStatus.OK:
            return 0, []
        return rsp['total'], rsp['fileUnits']

    def get_ds_files(self, ds_id, page_size=15):
        all_files = []
        offset = 0
        while True:
            total, files = self.pagination_ds_files(ds_id, offset, page_size)
            all_files += files
            if len(all_files) == total:
                break
            offset += len(files)
        return all_files

    def query_file(self, ds_id, filename, page_size=15):
        all_files = self.get_ds_files(ds_id, page_size)
        for file in all_files:
            if file['name'] == filename:
                return file
        return None

    def delete_ds_file(self, ds_id, file_id):
        ds_file_url = self.client.url_generator.ds_file(
            self.client.site_id, ds_id, file_id)
        ret, _ = self.client.delete(ds_file_url)
        return ret == HTTPStatus.OK

    def query_iso(self):
        ds_id = self.params['ds_id']
        filename = self.params['filename']
        if not filename:
            logger.error('file name empty when querying iso')
            return None
        return self.query_file(ds_id, filename)

    def delete_iso(self):
        ds_id = self.params['ds_id']
        file_id = self.params['file_id']
        filename = self.params['filename']
        if file_id:
            return self.delete_ds_file(ds_id, file_id)
        elif filename:
            file_info = self.query_file(ds_id, filename)
            if not file_info:
                return False
            return self.delete_ds_file(ds_id, file_info['fileId'])

    def pagination_by_ds(self):
        ds_id = self.params['ds_id']
        offset = self.params['offset']
        limit = self.params['limit']

        return self.pagination_ds_files(ds_id, offset, limit)

    def upload_iso(self):
        try:
            filename = self.params['filename']
            ds_id = self.params['ds_id']
            ca_path = self.params['cna_ca_file']
            global_config = GlobalConfig()
            is_force_verify = global_config.get(
                'ssl_force_verification', 'true') != 'false'
            if is_force_verify and not ca_path:
                err_msg = 'Must give valid certifacte path.'
                logger.error(err_msg)
                raise ValueError(err_msg)
            is_overwrite = self.params['is_overwrite'] or False
            page_size = self.params['fc_params'].get('fc_page_size', 15)
            file_info = self.query_file(ds_id, filename, page_size)
            if not is_overwrite and file_info:
                return file_info
            elif file_info:
                file_id = file_info['fileId']
                if not self.delete_ds_file(ds_id, file_id):
                    logger.error('cannot delete file: %s', file_info['name'])
                    return None
            _, iso_path = self.fetch_iso_file()
            context = self.build_context(iso_path)
            ret = self.apply_upload_for_ds(context)
            if ret != HTTPStatus.OK:
                self.clean_tmps()
                return None
            with CnaClient(context['cna_ip'], ca_path) as client:
                client.auth_node()
                self.upload_iso_file(context, client)
                self.clean_tmps()
                file_info = self.query_file(context['ds_id'], context['name'])
                return file_info

        except Exception as e:
            logger.exception(e)
            self.clean_tmps()
            return None

    def build_context(self, iso_path):
        context = {
            'name': self.params['filename'],
            'ds_id': self.params['ds_id'],
            'iso_path': iso_path,
            'chunk_size': self.params['fc_params'].get('fc_chunk_size', 10)*1024*1024,
            'total_size': os.path.getsize(iso_path),
            'uploaded_size': 0,
        }
        return context

    def get_file_pull_fn(self, params):
        return pull_fn_wrap(params.get('fc_pull_script'))

    def fetch_file(self, file_url):
        file_url_res: ParseResult = urlparse(file_url)
        logger.debug('file_url: %s', file_url_res)
        file_res = {}
        if file_url_res.scheme == 'file':
            file_res['auto_clean'] = self.params.get(
                'fc_auto_clean', False)
            file_res['path'] = file_url_res.path
        else:
            file_pull_fn = self.get_file_pull_fn(self.params)
            if not file_pull_fn:
                return None
            logger.debug('file_pull_fn: %s', file_pull_fn)
            auto_clean, path = file_pull_fn(file_url, self.params)
            file_res['auto_clean'] = auto_clean
            file_res['path'] = path
            logger.debug('auto_clean is %s, path is %s',
                         auto_clean, path)
        self.add_auto_clean(file_res['auto_clean'], file_res['path'])
        return file_res['auto_clean'], file_res['path']

    def fetch_iso_file(self):
        return self.fetch_file(self.params['file_url'])

    def add_auto_clean(self, auto_clean, file_path):
        self.auto_cleans.append((auto_clean, file_path))

    def clean_tmps(self):
        for auto_clean, file_path in self.auto_cleans:
            if auto_clean and os.path.exists(file_path):
                os.remove(file_path)
        self.auto_cleans.clear()

    def update_context(self, context, rsp):
        context['uploadURL'] = rsp['uploadURL']
        context['token'] = rsp['token']
        context['cna_ip'] = rsp['trustURL'].split(':')[1][2:]

    def apply_upload_for_ds(self, context):
        ds_id = context['ds_id']
        name = context['name']
        size = context['total_size']
        apply_upload_url = self.client.url_generator.ds_apply_upload(
            self.client.site_id, ds_id)
        ret, rsp = self.client.get(
            apply_upload_url, {'name': name, 'size': size, 'siteID': self.client.site_id, 'dataStoreID': ds_id})
        if ret != HTTPStatus.OK:
            logger.error('apply upload for ds error, rsp: %s', rsp.context)
            return ret
        self.update_context(context, rsp)
        return HTTPStatus.OK

    def upload_iso_file(self, context, cna_client: CnaClient):
        url = context['uploadURL']
        full_url = f"{url}?client=html5&name={context['name']}&size={context['total_size']}"
        auth_token = context['token']
        chunk_size = context['chunk_size']
        file_path = context['iso_path']
        # Send the POST request with the file content as the body (in chunks)

        def upload_file_in_chunks(file_path, chunk_size, full_url):
            file_size = context['total_size']
            with open(file_path, 'rb') as f:
                start = 0
                while start < file_size:
                    end = min(start + chunk_size - 1, file_size - 1)
                    chunk_data = f.read(end - start + 1)
                    headers = {
                        "Content-Range": f"bytes {start}-{end+1}/{file_size}",
                        "Content-Length": str(end - start + 1),
                        'Content-Type': 'application/octet-stream; charset=UTF-8',
                        'x_upload_access': auth_token,
                        'Accept-Language': 'zh-CN,zh;q=0.9,en;q=0.8',
                    }
                    response, content = cna_client.upload_ds_file_chunk(
                        full_url, headers, chunk_data)
                    if response.status != HTTPStatus.OK or not json.loads(content).get('success'):
                        raise Exception(f"Failed to upload chunk {start}-{end}: "
                                        f"{response.status} {content}")
                    start = end + 1
        upload_file_in_chunks(file_path, chunk_size, full_url)


def pull_fn_wrap(fc_pull_script):
    def fn(path, params):
        import subprocess
        args = ["python3", fc_pull_script, path, json.dumps(params)]
        result = subprocess.run(args, capture_output=True, text=True)
        stdout = result.stdout
        returncode = result.returncode
        if returncode != 0:
            return False, ''
        auto_clean, res_path = stdout.strip().split(' ')
        return auto_clean == 'True', res_path
    return fn


def run_module():
    # define available arguments/parameters a user can pass to the module
    module_args = FcModuleBase.args()
    module_args.update(
        action=dict(type='str', required=True),
        ds_id=dict(type='int', required=False),
        file_id=dict(type='int', required=False),
        offset=dict(type='int', required=False, default=0),
        limit=dict(type='int', required=False, default=-1),
        filename=dict(type='str', required=False),
        file_url=dict(type='str', required=False),
        is_overwrite=dict(type='bool', required=False, default=False),
        cna_ca_file=dict(type='str', required=False),
        fc_params=dict(type='dict', required=False, default={}),
    )
    module = AnsibleModule(
        argument_spec=module_args,
        supports_check_mode=True
    )
    fc_ds_file_manager = FcDsFileManager(module)
    fc_ds_file_manager.execute()


def main():
    run_module()


if __name__ == '__main__':
    main()
