#!/usr/bin/env python
# -*- coding:utf-8 -*-
#  Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.
from ansible_collections.huawei.fusioncompute.plugins.module_utils.basic import FcAttrValidator, FcModuleBase
from ansible_collections.huawei.fusioncompute.plugins.module_utils.decorator import action_injector, validator_injector
from ansible_collections.huawei.fusioncompute.plugins.module_utils.param_validator import hostname_validator_fn
from ansible_collections.huawei.fusioncompute.plugins.module_utils.core.fusincompute import logger
from ansible.module_utils.basic import AnsibleModule
from ansible_collections.huawei.fusioncompute.plugins.module_utils.core.parameter_normalization import normalize
from enum import Enum

ANSIBLE_METADATA = {
    'metadata_version': '1.0.1',
    'status': ['preview'],
    'supported_by': 'huawei'
}

DOCUMENTATION = '''
---
module: huawei.fusioncompute.fc_ds_file_manager

short_description: Manage folders in Huawei FusionCompute.

version_added: "1.0.1"

description:
    - This module manages folders in Huawei FusionCompute.
    - It supports creating, modifying, deleting, querying, and moving folders.
    - It also supports pagination listing, resource listing, and topology view of folders.

options:

    action:
        description:
            - Operation to perform on the folder.
        required: true
        type: str
        choices: [create, modify, move, delete, query, pagination, query_resource, query_topo]

    folder_id:
        description:
            - ID of the folder for actions like query, modify, delete, query_resource, and query_topo.
        required: false
        type: int

    name:
        description:
            - Folder name (used in create and modify).
        required: false
        type: str

    parentObjUrn:
        description:
            - Parent object URN under which the folder is created or moved.
        required: false
        type: str

    type:
        description:
            - Folder type used for creation or pagination query.
            - "The options are:"
            - "0: cluster folder"
            - "1: VM folder"
            - "2: storage folder"
        required: false
        type: str

    elementType:
        description:
            - Element type being moved (used in move).
        required: false
        type: str

    elementUrns:
        description:
            - List of element URNs to be moved (used in move).
        required: false
        type: list

    folderName:
        description:
            - Name filter for pagination queries.
        required: false
        type: str

    limit:
        description:
            - Pagination limit. Default is 120.
        required: false
        type: int
        default: 120

    offset:
        description:
            - Pagination offset. Default is 0.
        required: false
        type: int
        default: 0

    # Parameters inherited from FcModuleBase:
    fc_hostname:
        description:
            - Host name or IP address of the FusionCompute VRM.
        required: true
        type: str

    fc_port:
        description:
            - Port number to connect to the FusionCompute VRM. Default is 7443.
        required: false
        default: 7443
        type: int

    fc_token:
        description:
            - Token for authentication. If provided, the module will skip login and use this token for authentication.
        required: false
        type: str

    fc_username:
        description:
            - Username for FusionCompute authentication.
        required: false
        type: str

    fc_password:
        description:
            - Password for authentication on the FusionCompute VRM.
        required: false
        type: str
        no_log: true
    
    fc_site_id:
        description:
            - Site ID for FusionCompute. If provided, the module will skip retrieving  site id and use this site ID.
        required: false
        type: str

    fc_language:
        description:
            - Language used for communication with FusionCompute VRM. Default is 'en-US'.
        required: false
        default: 'en-US'
        type: str

    fc_verify:
        description:
            - Path to rootCA.crt file for SSL certificate verification. If empty, SSL verification will be disabled.
        required: false
        default: ''
        type: str

author:
    - Huawei Technologies Co., Ltd.
'''

EXAMPLES = '''
# Create a new folder
- name: Create folder
  huawei.fusioncompute.fc_folder_manager:
    action: create
    name: "vm-folder"
    parentObjUrn: "urn:sites:xxx"
    type: 1
    fc_hostname: "192.168.1.100"
    fc_token: "xxxx"

# Query folder info
- name: Query folder
  huawei.fusioncompute.fc_folder_manager:
    action: query
    folder_id: 1234
    fc_hostname: "192.168.1.100"
    fc_token: "xxxx"
'''

RETURN = '''
ret:
    description: API result from FusionCompute.
    type: dict
    returned: always
    contains:
        code:
            description: Status code.
            type: int
            returned: always
        rsp:
            description: Response content.
            type: dict
            returned: always
'''


class FolderManagerAction(Enum):
    create = 'create'
    modify = 'modify'
    move = 'move'
    delete = 'delete'
    query = 'query'
    pagination = 'pagination'
    query_resource = 'query_resource'
    query_topo = 'query_topo'


@action_injector(FolderManagerAction)
@validator_injector([FcAttrValidator('fc_hostname', hostname_validator_fn)])
class FcDsFileManager(FcModuleBase):
    def __init__(self, module):
        super(FcDsFileManager, self).__init__(module)

    def execute(self):
        validate_res = self.validate()
        if validate_res:
            logger.info('fc vm http import validate failed %s', validate_res)
            self.module.fail_json(msg=validate_res)
        self.auto_cleans = []
        action: FolderManagerAction = self.action
        match action:
            case FolderManagerAction.pagination:
                ret, rsp = self.pagination_folder()
            case FolderManagerAction.create:
                ret, rsp = self.create_folder()
            case FolderManagerAction.delete:
                ret, rsp = self.delete_folder()
            case FolderManagerAction.move:
                ret, rsp = self.move_folder()
            case FolderManagerAction.query:
                folder_id = self.params['folder_id']
                ret, rsp = self.query_folder(folder_id)
            case FolderManagerAction.modify:
                folder_id = self.params['folder_id']
                ret, rsp = self.modify_folder(folder_id)
            case FolderManagerAction.query_resource:
                folder_id = self.params['folder_id']
                ret, rsp = self.query_resource_info(folder_id)
            case FolderManagerAction.query_topo:
                folder_id = self.params['folder_id']
                ret, rsp = self.query_topo(folder_id)
            case _:
                self.module.fail_json(
                    changed=False, msg='param action type invalid.')
        self.module.exit_json(changed=ret, ret={
            'code': ret, 'rsp': rsp})

    def create_folder(self):
        params = ['name', 'parentObjUrn', 'type']
        data = self.exact_params(params)
        url = self.client.url_generator.folder_url(
            self.client.site_id)
        return self.client.post(url, normalize(data))

    def delete_folder(self, folder_id):
        folder_id = self.params['folder_id']
        url = self.client.url_generator.folder_url(
            self.client.site_id, folder_id)
        return self.client.delete(url)

    def query_folder(self, folder_id):
        folder_id = self.params['folder_id']
        url = self.client.url_generator.folder_url(
            self.client.site_id, folder_id)
        return self.client.get(url)

    def modify_folder(self, folder_id):
        params = ['name', 'parentObjUrn']
        data = self.exact_params(params)
        url = self.client.url_generator.folder_url(
            self.client.site_id, folder_id)
        return self.client.put(url, normalize(data))

    def move_folder(self):
        params = ['parentObjUrn', 'elementType', 'elementUrns']
        data = self.exact_params(params)
        url = self.client.url_generator.folder_move_url(
            self.client.site_id)
        return self.client.put(url, normalize(data))

    def pagination_folder(self):
        params = ['parentObjUrn', 'type', 'folderName', 'limit', 'offset']
        data = self.exact_params(params)
        url = self.client.url_generator.folder_url(
            self.client.site_id)
        return self.client.get(url, normalize(data))

    def query_resource_info(self, folder_id):
        url = self.client.url_generator.folder_resource_url(
            self.client.site_id, folder_id)
        return self.client.get(url)

    def query_topo(self, folder_id):
        url = self.client.url_generator.folder_topo_url(
            self.client.site_id, folder_id)
        return self.client.get(url)


def run_module():
    # define available arguments/parameters a user can pass to the module
    module_args = FcModuleBase.args()
    module_args.update(
        action=dict(type='str', required=True),
        folder_id=dict(type='int', required=False),
        name=dict(type='str', required=False),
        parentObjUrn=dict(type='str', required=False),
        type=dict(type='str', required=False),
        elementType=dict(type='str', required=False),
        elementUrns=dict(type='list', required=False),
        folderName=dict(type='str', required=False),
        limit=dict(type='int', required=False, default=120),
        offset=dict(type='int', required=False, default=0),
    )
    module = AnsibleModule(
        argument_spec=module_args,
        supports_check_mode=True
    )
    fc_folder_manager = FcDsFileManager(module)
    fc_folder_manager.execute()


def main():
    run_module()


if __name__ == '__main__':
    main()
