#!/usr/bin/env python
# -*- coding:utf-8 -*-
#  Copyright (c) Huawei Technologies Co., Ltd. 2024-2024. All rights reserved.
from http import HTTPStatus
from enum import Enum

from ansible.module_utils.basic import AnsibleModule
from ansible_collections.huawei.fusioncompute.plugins.module_utils.core.fusincompute import logger
from ansible_collections.huawei.fusioncompute.plugins.module_utils.param_validator import hostname_validator_fn
from ansible_collections.huawei.fusioncompute.plugins.module_utils.decorator import action_injector, validator_injector
from ansible_collections.huawei.fusioncompute.plugins.module_utils.basic import FcAttrValidator, FcModuleBase

ANSIBLE_METADATA = {
    'metadata_version': '1.0.0',
    'status': ['preview'],
    'supported_by': 'standard'
}

DOCUMENTATION = '''
---
module: huawei.fusioncompute.fc_vm_os_manager

short_description: Manage operating system (OS) information for virtual machines (VMs) on Huawei FusionCompute.

version_added: "1.0.0"

description:
    - This module allows you to query operating system (OS) information for virtual machines (VMs) on Huawei FusionCompute.
    - It supports querying a specific OS version or all OS versions.

options:
    action:
        description:
            - The action to perform.
            - Supported actions are 'query' to query a specific OS version and 'all' to query all OS versions.
        required: true
        type: str
        choices: ['query', 'all']

    os_id:
        description:
            - The ID of the operating system (OS) to query.
            - Required when action is 'query'.
        required: false
        type: str

    # Parameters inherited from FcModuleBase:
    fc_hostname:
        description:
            - Host name or IP address of the FusionCompute VRM.
        required: true
        type: str

    fc_port:
        description:
            - Port number to connect to the FusionCompute VRM. Default is 7443.
        required: false
        default: 7443
        type: int

    fc_token:
        description:
            - Token for authentication. If provided, the module will skip login and use this token for authentication.
        required: false
        type: str

    fc_username:
        description:
            - Username for FusionCompute authentication.
        required: false
        type: str

    fc_password:
        description:
            - Password for authentication on the FusionCompute VRM.
        required: false
        type: str
        no_log: true
    
    fc_site_id:
        description:
            - Site ID for FusionCompute. If provided, the module will skip retrieving  site id and use this site ID.
        required: false
        type: str

    fc_language:
        description:
            - Language used for communication with FusionCompute VRM. Default is 'en-US'.
        required: false
        default: 'en-US'
        type: str

    fc_verify:
        description:
            - Path to rootCA.crt file for SSL certificate verification. If empty, SSL verification will be disabled.
        required: false
        default: ''
        type: str

author:
    - Huawei Technologies Co., Ltd.
'''

EXAMPLES = '''
# Query a specific OS version
- name: Query a specific OS version
  huawei.fusioncompute.fc_vm_os_manager:
    action: query
    fc_hostname: "192.168.1.100"
    fc_token: "xxxx"
    os_id: "10026"
  register: result

# Query all OS versions
- name: Query all OS versions
  huawei.fusioncompute.fc_vm_os_manager:
    action: all
    fc_hostname: "192.168.1.100"
    fc_token: "xxxx"
  register: result

- name: Debug the result
  debug:
    var: result
'''

RETURN = '''
ret:
    description: The response from the FusionCompute API.
    type: dict
    returned: always
    contains:
        code:
            description: The HTTP status code of the operation.
            type: int
            returned: always
        rsp:
            description: The response body returned by the API.
            type: dict
            returned: always
'''


class OsManagerAction(Enum):
    query = 'query'
    all = 'all'


@action_injector(OsManagerAction)
@validator_injector([FcAttrValidator('fc_hostname', hostname_validator_fn)])
class FcVmOsManager(FcModuleBase):
    def __init__(self, module):
        super(FcVmOsManager, self).__init__(module)

    def execute(self):
        validate_res = self.validate()
        if validate_res:
            logger.info(
                "fc vm vmtools manager validate failed %s", validate_res)
            self.module.fail_json(msg=validate_res)
        action: OsManagerAction = self.action
        os_id = self.params['os_id']
        url = self.client.url_generator.os_query(
            self.client.site_id, os_id=None if action == OsManagerAction.all else os_id)
        ret, rsp = self.client.get(url)
        if ret != HTTPStatus.OK:
            self.module.fail_json(
                msg="Couldn't query vm os version info: ret: %s, rsp: %s" % (ret, rsp.json()))
        else:
            self.module.exit_json(
                changed=False, ret={'code': ret, 'rsp': rsp})


def run_module():
    # define available arguments/parameters a user can pass to the module
    module_args = FcModuleBase.args()
    module_args.update(
        action=dict(type='str', required=True),
        os_id=dict(type='str', required=False),
    )
    module = AnsibleModule(
        argument_spec=module_args,
        supports_check_mode=True
    )
    fc_vm_os_manager = FcVmOsManager(module)
    fc_vm_os_manager.execute()


def main():
    run_module()


if __name__ == '__main__':
    main()
