#!/usr/bin/env python
# -*- coding:utf-8 -*-
#  Copyright (c) Huawei Technologies Co., Ltd. 2024-2024. All rights reserved.
from http import HTTPStatus
from enum import Enum

from ansible.module_utils.basic import AnsibleModule
from ansible_collections.huawei.fusioncompute.plugins.module_utils.core.fusincompute import logger
from ansible_collections.huawei.fusioncompute.plugins.module_utils.param_validator import hostname_validator_fn
from ansible_collections.huawei.fusioncompute.plugins.module_utils.decorator import action_injector, validator_injector
from ansible_collections.huawei.fusioncompute.plugins.module_utils.basic import FcAttrValidator, FcModuleBase
from ansible_collections.huawei.fusioncompute.plugins.module_utils.core.parameter_normalization import normalize

ANSIBLE_METADATA = {
    'metadata_version': '1.0.0',
    'status': ['preview'],
    'supported_by': 'standard'
}

DOCUMENTATION = '''
---
module: huawei.fusioncompute.fc_vm_attr_manager

short_description: Manage virtual machine (VM) attributes on Huawei FusionCompute.

version_added: "1.0.0"

description:
    - This module allows you to manage attributes of virtual machines (VMs) on Huawei FusionCompute.
    - It supports querying VM attributes, modifying VM attributes, and querying custom attributes.

options:
    action:
        description:
            - The action to perform.
            - Supported actions are 'query', 'modify', and 'query_custom_attr'.
        required: true
        type: str
        choices: ['query', 'modify', 'query_custom_attr']

    vm_id:
        description:
            - The ID of the virtual machine (VM) to manage.
        required: true
        type: str

    listAllDisksStatus:
        description:
            - Whether to list the status of all disks when querying VM attributes.
            - Only applicable when action is 'query'.
        required: false
        type: bool
        default: false

    name:
        description:
            - The name of the VM.
        required: false
        type: str
    
    description:
        description:
            - The description of the VM.
        required: false
        type: str
    
    group:
        description:
            - The group to which the VM belongs.
        required: false
        type: str
    
    location:
        description:
            - The location of the VM.
        required: false
        type: str
    
    externalUuid:
        description:
            - The external UUID of the VM.
        required: false
        type: str
    
    isTemplate:
        description:
            - Whether the VM is a template.
        required: false
        type: bool
    
    cpu:
        description:
            - CPU configuration of the VM.
        required: false
        type: dict
    
    memory:
        description:
            - Memory configuration of the VM.
        required: false
        type: dict
    
    graphicsCard:
        description:
            - Graphics card configuration of the VM.
        required: false
        type: dict
    
    properties:
        description:
            - Additional properties of the VM.
        required: false
        type: dict
    
    osOptions:
        description:
            - Operating system options for the VM.
        required: false
        type: dict
    
    vncAccessInfo:
        description:
            - VNC access information for the VM.
        required: false
        type: dict
    
    publickey:
        description:
            - Public key for the VM.
        required: false
        type: dict
    
    isMultiDiskSpeedup:
        description:
            - Whether multi-disk speedup is enabled for the VM.
        required: false
        type: bool
    
    disk:
        description:
            - Disk configuration for the VM.
        required: false
        type: list
    
    nic:
        description:
            - Network interface card (NIC) configuration for the VM.
        required: false
        type: list
    
    resouceGroup:
        description:
            - The resource group to which the VM belongs.
        required: false
        type: str
    
    enableImc:
        description:
            - Whether IMC (Integrated Management Controller) is enabled for the VM.
        required: false
        type: bool
    
    imcSetting:
        description:
            - IMC settings for the VM.
        required: false
        type: str
    
    vtpm:
        description:
            - vTPM (Virtual Trusted Platform Module) configuration for the VM.
        required: false
        type: dict

    # Parameters inherited from FcModuleBase:
    fc_hostname:
        description:
            - Host name or IP address of the FusionCompute VRM.
        required: true
        type: str

    fc_port:
        description:
            - Port number to connect to the FusionCompute VRM. Default is 7443.
        required: false
        default: 7443
        type: int

    fc_token:
        description:
            - Token for authentication. If provided, the module will skip login and use this token for authentication.
        required: false
        type: str

    fc_username:
        description:
            - Username for FusionCompute authentication.
        required: false
        type: str

    fc_password:
        description:
            - Password for authentication on the FusionCompute VRM.
        required: false
        type: str
        no_log: true
    
    fc_site_id:
        description:
            - Site ID for FusionCompute. If provided, the module will skip retrieving  site id and use this site ID.
        required: false
        type: str

    fc_language:
        description:
            - Language used for communication with FusionCompute VRM. Default is 'en-US'.
        required: false
        default: 'en-US'
        type: str

    fc_verify:
        description:
            - Path to rootCA.crt file for SSL certificate verification. If empty, SSL verification will be disabled.
        required: false
        default: ''
        type: str

author:
    - Huawei Technologies Co., Ltd.
'''

EXAMPLES = '''
# Query VM attributes
- name: Query VM attributes
  huawei.fusioncompute.fc_vm_attr_manager:
    action: query
    fc_hostname: "192.168.1.100"
    fc_token: "xxxx"
    vm_id: "i-xxxxxxxx"
    listAllDisksStatus: true
  register: result

# Modify VM attributes
- name: Modify VM attributes
  huawei.fusioncompute.fc_vm_attr_manager:
    action: modify
    fc_hostname: "192.168.1.100"
    fc_token: "xxxx"
    vm_id: "i-xxxxxxxx"
    name: "new-vm-name"
    description: "Updated VM description"
  register: result

# Query custom VM attributes
- name: Query custom VM attributes
  huawei.fusioncompute.fc_vm_attr_manager:
    action: query_custom_attr
    fc_hostname: "192.168.1.100"
    fc_token: "xxxx"
    vm_id: "i-xxxxxxxx"
  register: result

- name: Debug the result
  debug:
    var: result
'''

RETURN = '''
ret:
    description: The response from the FusionCompute API.
    type: dict
    returned: always
    contains:
        code:
            description: The HTTP status code of the operation.
            type: int
            returned: always
        rsp:
            description: The response body returned by the API.
            type: dict
            returned: always
'''


class AttrManagerAction(Enum):
    query = 'query'
    modify = 'modify'
    query_custom_attr = 'query_custom_attr'


@action_injector(AttrManagerAction)
@validator_injector([FcAttrValidator('fc_hostname', hostname_validator_fn)])
class FcVmAttrManager(FcModuleBase):
    def __init__(self, module):
        super(FcVmAttrManager, self).__init__(module)

    def execute(self):
        validate_res = self.validate()
        if validate_res:
            logger.info(
                "fc vm vmtools manager validate failed %s", validate_res)
            self.module.fail_json(msg=validate_res)
        action: AttrManagerAction = self.action
        vm_id = self.params['vm_id']
        match action:
            case AttrManagerAction.modify:
                ret, rsp = self.do_modify(vm_id)
            case AttrManagerAction.query:
                list_all_disks_status = self.params['listAllDisksStatus']
                url = self.client.url_generator.vms_query(
                    self.client.site_id, vm_id, list_all_disks_status)
                ret, rsp = self.client.get(url)
            case AttrManagerAction.query_custom_attr:
                url = self.client.url_generator.vms_custom_attr(
                    self.client.site_id, vm_id)
                ret, rsp = self.client.get(url)
            case _:
                self.module.fail_json(
                    changed=False, msg='param action type invalid.')
        if ret != HTTPStatus.OK:
            self.module.fail_json(
                msg="Couldn't manage vm attribute: ret: %s, rsp: %s" % (ret, rsp.json()))
        else:
            self.module.exit_json(
                changed=(action in (AttrManagerAction.modify,)), ret={'code': ret, 'rsp': rsp})

    def do_modify(self, vm_id):
        name = self.params['name']
        description = self.params['description']
        group = self.params['group']
        location = self.params['location']
        external_uuid = self.params['externalUuid']
        is_template = self.params['isTemplate']
        cpu = self.params['cpu']
        memory = self.params['memory']
        graphics_card = self.params['graphicsCard']
        properties = self.params['properties']
        os_options = self.params['osOptions']
        vnc_access_info = self.params['vncAccessInfo']
        publickey = self.params['publickey']
        is_multi_disk_speedup = self.params['isMultiDiskSpeedup']
        disk = self.params['disk']
        nic = self.params['nic']
        resource_group = self.params['resouceGroup']
        enable_imc = self.params['enableImc']
        imc_setting = self.params['imcSetting']
        vtpm = self.params['vtpm']
                # Building the data dictionary
        data = {
                    'name': name,
                    'description': description,
                    'group': group,
                    'location': location,
                    'externalUuid': external_uuid,
                    'isTemplate': is_template,
                    'cpu': cpu,
                    'memory': memory,
                    'graphicsCard': graphics_card,
                    'properties': properties,
                    'osOptions': os_options,
                    'vncAccessInfo': vnc_access_info,
                    'publickey': publickey,
                    'isMultiDiskSpeedup': is_multi_disk_speedup,
                    'disk': disk,
                    'nic': nic,
                    'resourceGroup': resource_group,
                    'enableImc': enable_imc,
                    'imcSetting': imc_setting,
                    'vtpm': vtpm
                }
        url = self.client.url_generator.vms(
                    self.client.site_id,  vm_id)
        return self.client.put(url, normalize(data))


def run_module():
    # define available arguments/parameters a user can pass to the module
    module_args = FcModuleBase.args()
    module_args.update(
        action=dict(type='str', required=True),
        vm_id=dict(type='str', required=True),
        listAllDisksStatus=dict(type='bool', required=False, default=False),
        name=dict(type='str', required=False),
        description=dict(type='str', required=False),
        group=dict(type='str', required=False),
        location=dict(type='str', required=False),
        externalUuid=dict(type='str', required=False),
        isTemplate=dict(type='boolean', required=False),
        cpu=dict(type='dict', required=False),
        memory=dict(type='dict', required=False),
        graphicsCard=dict(type='dict', required=False),
        properties=dict(type='dict', required=False),
        osOptions=dict(type='dict', required=False),
        vncAccessInfo=dict(type='dict', required=False),
        publickey=dict(type='dict', required=False),
        isMultiDiskSpeedup=dict(type='boolean', required=False),
        disk=dict(type='list', required=False),
        nic=dict(type='list', required=False),
        resouceGroup=dict(type='str', required=False),
        enableImc=dict(type='bool', required=False),
        imcSetting=dict(type='str', required=False),
        vtpm=dict(type='dict', required=False),
    )
    module = AnsibleModule(
        argument_spec=module_args,
        supports_check_mode=True
    )
    fc_vm_attr_manager = FcVmAttrManager(module)
    fc_vm_attr_manager.execute()


def main():
    run_module()


if __name__ == '__main__':
    main()
