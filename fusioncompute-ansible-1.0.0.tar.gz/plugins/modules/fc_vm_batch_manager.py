#!/usr/bin/env python
# -*- coding:utf-8 -*-
#  Copyright (c) Huawei Technologies Co., Ltd. 2024-2024. All rights reserved.
from enum import Enum
from ansible.module_utils.basic import AnsibleModule
from http import HTTPStatus

from ansible_collections.huawei.fusioncompute.plugins.module_utils.core.fusincompute import logger
from ansible_collections.huawei.fusioncompute.plugins.module_utils.core.data_processor import DataProcessor
from ansible_collections.huawei.fusioncompute.plugins.module_utils.basic import FcAttrValidator, FcModuleBase
from ansible_collections.huawei.fusioncompute.plugins.module_utils.decorator import action_injector, validator_injector
from ansible_collections.huawei.fusioncompute.plugins.module_utils.param_validator import hostname_validator_fn


ANSIBLE_METADATA = {
    'metadata_version': '1.0.0',
    'status': ['preview'],
    'supported_by': 'huawei'
}

DOCUMENTATION = '''
---
module: huawei.fusioncompute.fc_batch_vm_deletion

short_description: This module handles batch VM deletion in FusionCompute.

version_added: "1.0.0"

description:
    - "This module allows batch deletion of virtual machines (VMs) in FusionCompute. It supports the deletion of 
       multiple VMs by specifying a list of VMs to delete."
    - "The module uses the FusionCompute API to perform the deletion and returns the status of the operation."

options:
    vm_list:
        description:
            - A list of virtual machines to delete. If not provided, the module will attempt to load this list 
              from a configuration file.
        required: false
        type: list

    is_format:
        description:
            - A flag to control the output format. Default is '0'. Set to '1' to return formatted results.
        required: false
        default: '0'
        type: str
    
    # Parameters inherited from FcModuleBase:
    fc_hostname:
        description:
            - Host name or IP address of the FusionCompute VRM.
        required: true
        type: str

    fc_port:
        description:
            - Port number to connect to the FusionCompute VRM. Default is 7443.
        required: false
        default: 7443
        type: int

    fc_token:
        description:
            - Token for authentication. If provided, the module will skip login and use this token for authentication.
        required: false
        type: str

    fc_username:
        description:
            - Username for FusionCompute authentication.
        required: false
        type: str

    fc_password:
        description:
            - Password for authentication on the FusionCompute VRM.
        required: false
        type: str
        no_log: true
    
    fc_site_id:
        description:
            - Site ID for FusionCompute. If provided, the module will skip retrieving  site id and use this site ID.
        required: false
        type: str

    fc_language:
        description:
            - Language used for communication with FusionCompute VRM. Default is 'en-US'.
        required: false
        default: 'en-US'
        type: str

    fc_verify:
        description:
            - Path to rootCA.crt file for SSL certificate verification. If empty, SSL verification will be disabled.
        required: false
        default: ''
        type: str

author:
    - Huawei Technologies Co., Ltd.
'''

EXAMPLES = '''
# Delete VMs in batch
- name: Batch delete VMs
  fc_batch_vm_deletion:
    fc_hostname: "192.168.1.100"
    fc_token: "xxxx"
    vm_list:
      - "urn:sites:xxxxxx:vms:1"
      - "urn:sites:xxxxxx:vms:2"
    is_format: '1'
    

# Delete VMs using configuration file
- name: Batch delete VMs using config file
  fc_batch_vm_deletion:
    fc_hostname: "192.168.1.100"
    fc_token: "xxxx"
    param_path: "/etc/vm_list_config.json"
'''

RETURN = '''
ret:
    description: The result of the operation, including HTTP status code and rsponse body
    type: dict
    returned: always
    contains:
        code:
            description: The HTTP status code of the operation
            type: int
        rsp:
            description: The response data returned from the FusionCompute API.
            type: dict
'''


class BatchManagerAction(Enum):
    delete = 'delete'


@action_injector(BatchManagerAction)
@validator_injector([FcAttrValidator('fc_hostname', hostname_validator_fn)])
class FcVmBatchManager(FcModuleBase):
    def __init__(self, module):
        super(FcVmBatchManager, self).__init__(module)

    def execute(self):
        validate_res = self.validate()
        if validate_res:
            logger.error(
                "fc vm batch manager params validate failed %s", validate_res)
            self.module.fail_json(msg=validate_res)
        action: BatchManagerAction = self.action
        match action:
            case BatchManagerAction.delete:
                ret, rsp = self.do_delete()
            case _:
                self.module.fail_json(
                    changed=False, msg='param action type invalid.')
        if ret != HTTPStatus.OK:
            self.module.fail_json(
                msg="Couldn't manage vms in batch: ret: %s, rsp: %s" % (ret, rsp.json()))
        self.module.exit_json(changed=True, ret=ret, rsp=rsp)

    def do_delete(self):
        vm_list = self.params['vmList']
        if vm_list is None:
            param_dict = DataProcessor().load_config(self.params['param_path'])
            vm_list = param_dict.get('vmList', [])
        is_format = self.params['is_format'] or '0'
        url = self.client.url_generator.vm_batch_deletion(self.client.site_id)
        data = {"vmList": vm_list, 'is_format': is_format}
        return self.client.post(url, data)

def run_module():
    # define available arguments/parameters a user can pass to the module
    module_args = FcModuleBase.args()
    module_args.update(
        action=dict(type='str', required=True),
        vmList=dict(type='list', required=False),
        is_format=dict(type='str', required=False, default='0'),
        param_path=dict(type='str', required=False),
    )
    module = AnsibleModule(
        argument_spec=module_args,
        supports_check_mode=True
    )
    fc_vm_batch_manager = FcVmBatchManager(module)
    fc_vm_batch_manager.execute()


def main():
    run_module()


if __name__ == '__main__':
    main()
