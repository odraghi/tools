#!/usr/bin/env python
# -*- coding:utf-8 -*-
#  Copyright (c) Huawei Technologies Co., Ltd. 2024-2024. All rights reserved.
from enum import Enum
from http import HTTPStatus
from ansible.module_utils.basic import AnsibleModule
from ansible_collections.huawei.fusioncompute.plugins.module_utils.basic import FcModuleBase
from ansible_collections.huawei.fusioncompute.plugins.module_utils.param_validator import hostname_validator_fn
from ansible_collections.huawei.fusioncompute.plugins.module_utils.decorator import action_injector, validator_injector
from ansible_collections.huawei.fusioncompute.plugins.module_utils.basic import FcAttrValidator, FcModuleBase

ANSIBLE_METADATA = {
    'metadata_version': '1.0.0',
    'status': ['preview'],
    'supported_by': 'community'
}

DOCUMENTATION = '''
---
module: huawei.fusioncompute.fc_site_config_manager

short_description: Manage advanced configurations for sites on Huawei FusionCompute.

version_added: "1.0.0"

description:
    - This module allows you to manage advanced configurations for sites on Huawei FusionCompute.
    - It supports querying all advanced configurations and modifying specific configurations.

options:
    action:
        description:
            - The action to perform.
            - Supported actions are 'query_all' to retrieve all advanced configurations and 'modify' 
              to update configurations.
        required: true
        type: str
        choices: ['query_all', 'modify']

    items:
        description:
            - A list of configuration items to modify. Required when action is 'modify'.
            - Each item should be a dictionary containing the configuration key-value pairs.
        required: false
        type: list

    # Parameters inherited from FcModuleBase:
    fc_hostname:
        description:
            - Host name or IP address of the FusionCompute VRM.
        required: true
        type: str

    fc_port:
        description:
            - Port number to connect to the FusionCompute VRM. Default is 7443.
        required: false
        default: 7443
        type: int

    fc_token:
        description:
            - Token for authentication. If provided, the module will skip login and use this token for authentication.
        required: false
        type: str

    fc_username:
        description:
            - Username for FusionCompute authentication.
        required: false
        type: str

    fc_password:
        description:
            - Password for authentication on the FusionCompute VRM.
        required: false
        type: str
        no_log: true
    
    fc_site_id:
        description:
            - Site ID for FusionCompute. If provided, the module will skip retrieving  site id and use this site ID.
        required: false
        type: str

    fc_language:
        description:
            - Language used for communication with FusionCompute VRM. Default is 'en-US'.
        required: false
        default: 'en-US'
        type: str

    fc_verify:
        description:
            - Path to rootCA.crt file for SSL certificate verification. If empty, SSL verification will be disabled.
        required: false
        default: ''
        type: str

author:
    - Huawei Technologies Co., Ltd.
'''

EXAMPLES = '''
# Query all advanced configurations
- name: Query all advanced configurations
  huawei.fusioncompute.fc_site_config_manager:
    action: query_all
    fc_hostname: "192.168.1.100"
    fc_token: "xxxx"
  register: result

# Modify advanced configurations
- name: Modify advanced configurations
  huawei.fusioncompute.fc_site_config_manager:
    action: modify
    fc_hostname: "192.168.1.100"
    fc_token: "xxxx"
    items:
        - key: "config_key_1"
        value: "new_value_1"
        - key: "config_key_2"
        value: "new_value_2"
  register: result

- name: Debug the result
  debug:
    var: result
'''

RETURN = '''
ret:
    description: The response from the FusionCompute API.
    type: dict
    returned: always
    contains:
        code:
            description: The HTTP status code returned by the API.
            type: int
            returned: always
        rsp:
            description: The response body returned by the API.
            type: dict
            returned: always
'''


class SiteConfigManagerAction(Enum):
    query_all = 'query_all'
    modify = 'modify'


@action_injector(SiteConfigManagerAction)
@validator_injector([FcAttrValidator('fc_hostname', hostname_validator_fn)])
class FcSiteConfigManager(FcModuleBase):
    def __init__(self, module):
        super(FcSiteConfigManager, self).__init__(module)

    def execute(self):
        action: SiteConfigManagerAction = self.action
        match action:
            case SiteConfigManagerAction.modify:
                items = self.params['items']
                ret, rsp = self.client.put(
                    self.client.url_generator.advanced_config(self.client.site_id), {"items": items})
            case SiteConfigManagerAction.query_all:
                ret, rsp = self.client.get(
                    self.client.url_generator.advanced_config(self.client.site_id))
            case _:
                self.module.fail_json(
                    changed=False, msg='param action type invalid.')
        if ret != HTTPStatus.OK:
            self.module.fail_json(
                msg="Couldn't manage site advanced config: ret: %s, rsp: %s" % (ret, rsp.json()))
        self.module.exit_json(
            changed=(action == SiteConfigManagerAction.modify),  ret={'code': ret, 'rsp': rsp})


def run_module():
    # define available arguments/parameters a user can pass to the module
    module_args = FcModuleBase.args()
    module_args.update(
        action=dict(type='str', required=True),
        items=dict(type='list', required=False),
    )
    module = AnsibleModule(
        argument_spec=module_args,
        supports_check_mode=True
    )
    fc_site_config_manager = FcSiteConfigManager(module)
    fc_site_config_manager.execute()


def main():
    run_module()


if __name__ == '__main__':
    main()
