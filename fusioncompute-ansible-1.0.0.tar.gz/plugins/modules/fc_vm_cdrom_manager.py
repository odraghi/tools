#!/usr/bin/env python
# -*- coding:utf-8 -*-
#  Copyright (c) Huawei Technologies Co., Ltd. 2024-2024. All rights reserved.
from http import HTTPStatus
from enum import Enum

from ansible.module_utils.basic import AnsibleModule
from ansible_collections.huawei.fusioncompute.plugins.module_utils.core.fusincompute import logger
from ansible_collections.huawei.fusioncompute.plugins.module_utils.param_validator import hostname_validator_fn
from ansible_collections.huawei.fusioncompute.plugins.module_utils.decorator import action_injector, validator_injector
from ansible_collections.huawei.fusioncompute.plugins.module_utils.basic import FcAttrValidator, FcModuleBase
from ansible_collections.huawei.fusioncompute.plugins.module_utils.core.parameter_normalization import normalize

ANSIBLE_METADATA = {
    'metadata_version': '1.0.0',
    'status': ['preview'],
    'supported_by': 'standard'
}

DOCUMENTATION = '''
---
module: huawei.fusioncompute.fc_vm_cdrom_manager

short_description: Manage CD/DVD-ROM operations for virtual machines (VMs) on Huawei FusionCompute.

version_added: "1.0.0"

description:
    - This module allows you to manage CD/DVD-ROM operations for virtual machines (VMs) on Huawei FusionCompute.
    - It supports mounting and unmounting ISO images to/from VM CD/DVD-ROM drives.

options:
    action:
        description:
            - The action to perform.
            - Supported actions are 'mount' to mount an ISO image and 'unmount' to unmount the current ISO image.
        required: true
        type: str
        choices: ['mount', 'unmount']

    vm_id:
        description:
            - The ID of the virtual machine (VM) for which the CD/DVD-ROM operation is to be performed.
        required: true
        type: str

    devicePath:
        description:
            - The path to the ISO image to be mounted.
            - Required when action is 'mount'.
        required: false
        type: str

    username:
        description:
            - The username for authentication if the ISO image is stored on a remote server.
            - Required when action is 'mount' and the ISO image is on a remote server.
        required: false
        type: str

    password:
        description:
            - The password for authentication if the ISO image is stored on a remote server.
            - Required when action is 'mount' and the ISO image is on a remote server.
        required: false
        type: str
        no_log: true

    protocol:
        description:
            - The protocol used to access the ISO image (e.g., 'nfs', 'cifs').
            - Required when action is 'mount' and the ISO image is on a remote server.
        required: false
        type: str

    # Parameters inherited from FcModuleBase:
    fc_hostname:
        description:
            - Host name or IP address of the FusionCompute VRM.
        required: true
        type: str

    fc_port:
        description:
            - Port number to connect to the FusionCompute VRM. Default is 7443.
        required: false
        default: 7443
        type: int

    fc_token:
        description:
            - Token for authentication. If provided, the module will skip login and use this token for authentication.
        required: false
        type: str

    fc_username:
        description:
            - Username for FusionCompute authentication.
        required: false
        type: str

    fc_password:
        description:
            - Password for authentication on the FusionCompute VRM.
        required: false
        type: str
        no_log: true
    
    fc_site_id:
        description:
            - Site ID for FusionCompute. If provided, the module will skip retrieving  site id and use this site ID.
        required: false
        type: str

    fc_language:
        description:
            - Language used for communication with FusionCompute VRM. Default is 'en-US'.
        required: false
        default: 'en-US'
        type: str

    fc_verify:
        description:
            - Path to rootCA.crt file for SSL certificate verification. If empty, SSL verification will be disabled.
        required: false
        default: ''
        type: str

author:
    - Huawei Technologies Co., Ltd.
'''

EXAMPLES = '''
# Mount an ISO image to a VM
- name: Mount an ISO image to a VM
  huawei.fusioncompute.fc_vm_cdrom_manager:
    action: mount
    fc_hostname: "192.168.1.100"
    fc_token: "xxxx"
    vm_id: "i-xxxxxxxx"
    device_path: '1@ansible-111.iso'
    protocol: 'file'
  register: result

# Unmount the current ISO image from a VM
- name: Unmount the current ISO image from a VM
  huawei.fusioncompute.fc_vm_cdrom_manager:
    action: unmount
    fc_hostname: "192.168.1.100"
    fc_token: "xxxx"
    vm_id: "i-xxxxxxxx"
  register: result

- name: Debug the result
  debug:
    var: result
'''

RETURN = '''
ret:
    description: The response from the FusionCompute API.
    type: dict
    returned: always
    contains:
        code:
            description: The HTTP status code of the operation.
            type: int
            returned: always
        rsp:
            description: The response body returned by the API.
            type: dict
            returned: always
'''


class CdromManagerAction(Enum):
    mount = 'mount'
    unmount = 'unmount'


@action_injector(CdromManagerAction)
@validator_injector([FcAttrValidator('fc_hostname', hostname_validator_fn)])
class FcVmCdromManager(FcModuleBase):
    def __init__(self, module):
        super(FcVmCdromManager, self).__init__(module)

    def execute(self):
        validate_res = self.validate()
        if validate_res:
            logger.info(
                "fc vm cdrom manager validate failed %s", validate_res)
            self.module.fail_json(msg=validate_res)
        action: CdromManagerAction = self.action
        vm_id = self.params['vm_id']
        url = self.client.url_generator.vm_cdrom(
            self.client.site_id, vm_id, is_mount=action == CdromManagerAction.mount)
        match action:
            case CdromManagerAction.mount:
                device_path = self.params['devicePath']
                username = self.params['username']
                password = self.params['password']
                protocol = self.params['protocol']
                # Building the data dictionary
                data = {
                    'devicePath': device_path,
                    'username': username,
                    'password': password,
                    'protocol': protocol
                }
                ret, rsp = self.client.post(url, normalize(data))
            case CdromManagerAction.unmount:
                ret, rsp = self.client.post(url, data={})
            case _:
                self.module.fail_json(
                    changed=False, msg='param action type invalid.')
        if ret != HTTPStatus.OK:
            self.module.fail_json(
                msg="Couldn't manage vm cd rom: ret: %s, rsp: %s" % (ret, rsp.json()))
        else:
            self.module.exit_json(
                changed=True, ret={'code': ret, 'rsp': rsp})


def run_module():
    # define available arguments/parameters a user can pass to the module
    module_args = FcModuleBase.args()
    module_args.update(
        action=dict(type='str', required=True),
        vm_id=dict(type='str', required=True),
        devicePath=dict(type='str', required=False),
        username=dict(type='str', required=False),
        password=dict(type='str', required=False, no_log=True),
        protocol=dict(type='str', required=False),
    )
    module = AnsibleModule(
        argument_spec=module_args,
        supports_check_mode=True
    )
    fc_vm_cdrom_manager = FcVmCdromManager(module)
    fc_vm_cdrom_manager.execute()


def main():
    run_module()


if __name__ == '__main__':
    main()
