#!/usr/bin/env python
# -*- coding:utf-8 -*-
#  Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.
from enum import Enum
from http import HTTPStatus
import json
import os
import tempfile
from urllib.parse import ParseResult, urlparse
import requests
import shutil
import ipaddress

from ansible.module_utils.basic import AnsibleModule
from ansible_collections.huawei.fusioncompute.plugins.module_utils.core.fusincompute import logger
from ansible_collections.huawei.fusioncompute.plugins.module_utils.param_validator import hostname_validator_fn
from ansible_collections.huawei.fusioncompute.plugins.module_utils.decorator import action_injector, validator_injector
from ansible_collections.huawei.fusioncompute.plugins.module_utils.basic import FcAttrValidator, FcModuleBase
from ansible_collections.huawei.fusioncompute.plugins.module_utils.ocp.ignition_handler \
    import generate_ignition, generate_ignition_from_config, merge_ignition

ANSIBLE_METADATA = {
    'metadata_version': '1.0.1',
    'status': ['preview'],
    'supported_by': 'huawei'
}

DOCUMENTATION = '''
---
module: huawei.fusioncompute.fc_ocp_manager

short_description: Module for managing OpenShift deployment artifacts in Huawei FusionCompute, including Ignition and ISO preparation.

version_added: "1.0.1"

description:
    - This module provides automation for preparing OpenShift cluster installation files on FusionCompute, including Ignition configuration, ISO injection, and kernel command-line generation.

options:

    action:
        description:
            - The action to perform for managing OpenShift deployment content.
        required: true
        type: str
        choices:
            - prepare_ignition
            - prepare_iso
            - update_ignition
            - generate_cmdline

    ignition_config:
        description:
            - A dictionary describing the configuration needed for Ignition or command-line generation.
            - Required fields vary depending on the action.
            - Required for actions - prepare_ignition, update_ignition, generate_cmdline.
            - "Sub-options:"
            - "**ip**: Static IP address to assign to the VM."
            - "**netmask**: CIDR format netmask or prefix length (e.g., 24)."
            - "**gateway**: Default gateway address."
            - "**dns_servers**: DNS servers, separated by semicolons."
            - "**users**: List of user dicts for the Ignition config"
            - "**name** (str): Username."
            - "**password** (str, optional): Password string."
            - "**public_key_content** (str): content of SSH public key file."
        required: false
        type: dict

    iso_path:
        description:
            - Destination path to save the injected ISO file.
            - Required for prepare_iso action.
        required: false
        type: str

    iso_url:
        description:
            - URL to fetch the original CoreOS ISO file.
            - "Supports local files (file://), HTTP(S), or scripts defined in fc_pull_script."
            - Required for prepare_iso if ISO is not available locally.
        required: false
        type: str

    ignition_path:
        description:
            - Path to write the generated Ignition configuration file.
            - Required for prepare_ignition and prepare_iso actions.
        required: false
        type: str

    fc_params:
        description:
            - Parameters for image handling.
            - "fc_chunk_size: Upload chunk size in MB (default: 10)."
            - "fc_pull_script: Script for downloading remote ISO files."
        required: false
        type: dict

    # Parameters inherited from FcModuleBase:
    fc_hostname:
        description:
            - Host name or IP address of the FusionCompute VRM.
        required: true
        type: str

    fc_port:
        description:
            - Port number to connect to the FusionCompute VRM. Default is 7443.
        required: false
        default: 7443
        type: int

    fc_token:
        description:
            - Token for authentication. If provided, the module will skip login and use this token for authentication.
        required: false
        type: str

    fc_username:
        description:
            - Username for FusionCompute authentication.
        required: false
        type: str

    fc_password:
        description:
            - Password for authentication on the FusionCompute VRM.
        required: false
        type: str
        no_log: true

    fc_site_id:
        description:
            - Site ID for FusionCompute. If provided, the module will skip retrieving  site id and use this site ID.
        required: false
        type: str

    fc_language:
        description:
            - Language used for communication with FusionCompute VRM. Default is 'en-US'.
        required: false
        default: 'en-US'
        type: str

    fc_verify:
        description:
            - Path to rootCA.crt file for SSL certificate verification. If empty, SSL verification will be disabled.
        required: false
        default: ''
        type: str

author:
    - Huawei Technologies Co., Ltd.
'''

EXAMPLES = '''
# Prepare injected ISO with ignition
- name: Prepare CoreOS ISO with embedded ignition
  huawei.fusioncompute.fc_ocp_manager:
    action: prepare_iso
    fc_hostname: 192.168.1.100
    fc_token: "xxxx"
    iso_url: "file:///demo/fcos.iso"
    ignition_path: "/tmp/controller.ign"
    iso_path: "/tmp/fcos-injected.iso"
'''

RETURN = '''
ret:
    description: The result of the executed action.
    type: dict
    returned: always
    contains:
        igniton_config:
            description: The generated Ignition configuration (if applicable).
            type: dict
            returned: when action == prepare_ignition
        dst_iso_file:
            description: The file path of the resulting ISO file with embedded Ignition.
            type: str
            returned: when action == prepare_iso
        result:
            description: The generated command-line string or result of update operation.
            type: str
            returned: when action == generate_cmdline or update_ignition
'''


class OcpManagerAction(Enum):
    prepare_ignition = 'prepare_ignition'
    prepare_iso = 'prepare_iso'
    update_ignition = 'update_ignition'
    generate_cmdline = 'generate_cmdline'


@action_injector(OcpManagerAction)
@validator_injector([FcAttrValidator('fc_hostname', hostname_validator_fn)])
class FcOcpManager(FcModuleBase):
    def __init__(self, module):
        super(FcOcpManager, self).__init__(module)

    def execute(self):
        validate_res = self.validate()
        if validate_res:
            logger.info('fc ocp manager validate failed %s', validate_res)
            self.module.fail_json(msg=validate_res)
        self.auto_cleans = []
        action: OcpManagerAction = self.action
        match action:
            case OcpManagerAction.prepare_ignition:
                res = self.prepare_ignition()
                if res:
                    self.module.exit_json(changed=True, ret={
                        'igniton_config': res})
                else:
                    self.module.fail_json(msg='fail to prepare igniton')
            case OcpManagerAction.prepare_iso:
                dst_iso_file = self.prepare_iso()
                self.module.exit_json(changed=True, ret={
                    'dst_iso_file': dst_iso_file})
            case OcpManagerAction.update_ignition:
                ret = self.update_ignition()
                if ret:
                    self.module.exit_json(changed=True, ret={
                        'result': ret})
                else:
                    self.module.fail_json(
                        msg='update igntion failed, maybe confilict attrs exists')
            case OcpManagerAction.generate_cmdline:
                ret = self.generate_cmdline()
                self.module.exit_json(changed=True, ret={
                    'result': ret})

    def netmask_to_cidr(self, cidr):
        # convert CIDR prefix to full netmask
        return str(ipaddress.IPv4Network(f"0.0.0.0/{cidr}").netmask)

    def do_generate_cmdline(self, vmconfig):
        nic = vmconfig
        ip = nic.get("ip", "")
        gateway = nic.get("gateway", "")
        netmask = self.netmask_to_cidr(nic.get("netmask", 24))
        iface = nic.get("nic_name", "enp4s1")
        dns_servers = nic.get("dns_servers", "")
        dns_list = dns_servers.split(";")

        ip_part = f"ip={ip}::{gateway}:{netmask}::{iface}:none"

        # append multiple nameserver=
        dns_part = " ".join(
            [f"nameserver={dns.strip()}" for dns in dns_list if dns.strip()])

        return f"{ip_part} {dns_part}"

    def generate_cmdline(self):
        vmconfig = self.params['ignition_config']
        return self.do_generate_cmdline(vmconfig)

    def fetch_file(self, file_url):
        file_url_res: ParseResult = urlparse(file_url)
        logger.debug('file_url: %s', file_url_res)
        file_res = {}
        if file_url_res.scheme == 'file':
            file_res['auto_clean'] = self.params.get(
                'fc_auto_clean', False)
            file_res['path'] = file_url_res.path
        else:
            file_pull_fn = self.get_file_pull_fn(self.params)
            auto_clean, path = file_pull_fn(file_url, self.params)
            file_res['auto_clean'] = auto_clean
            file_res['path'] = path
            logger.debug('auto_clean is %s, path is %s',
                         auto_clean, path)
        self.add_auto_clean(file_res['auto_clean'], file_res['path'])
        return file_res['auto_clean'], file_res['path']

    def fetch_iso_file(self):
        if os.path.exists(self.params['iso_path']):
            return False, self.params['iso_path']
        return self.fetch_file(self.params['iso_url'])

    def fetch_controller_ign_file(self):
        return False, self.params['ignition_path']

    def add_auto_clean(self, auto_clean, file_path):
        self.auto_cleans.append((auto_clean, file_path))

    def clean_tmps(self):
        for auto_clean, file_path in self.auto_cleans:
            if auto_clean and os.path.exists(file_path):
                os.remove(file_path)
        self.auto_cleans.clear()

    def inject_ignition(self, iso_path, ign_path):
        with open(ign_path) as f:
            ign_content = f.read()
        logger.debug(
            'inject ignition file to iso: %s, ign_path: %s, content: %s', iso_path, ign_path, ign_content)
        import subprocess
        # coreos-installer iso ignition embed [OPTIONS] <ISO>
        result = subprocess.run(['coreos-installer', 'iso', 'ignition', 'embed',
                                '-f', '-i', ign_path, iso_path], capture_output=True, text=True)
        logger.debug(result.stdout)
        return result.returncode

    def get_ign_user(self, user):
        res = {'name': user['name']}
        if 'password' in user:
            res['password'] = user['password']
        res['authorized_key'] = user['public_key_content']
        return res

    def prepare_ignition(self):
        try:
            raw_ignition_config = self.params['ignition_config']
            ignition_output_path = self.params['ignition_path']
            ign_configs = self.get_ignition(raw_ignition_config)
            return generate_ignition_from_config(ign_configs, ignition_output_path)
        except Exception as e:
            logger.error('prepare ignition error: %s', e)
            return None

    def get_ignition(self, raw_ignition_config):
        logger.debug('raw: %s', raw_ignition_config)
        attrs = ['ip', 'netmask', 'gateway', 'dns_servers']
        ign_configs = {}
        for attr in attrs:
            if raw_ignition_config.get(attr) is not None:
                ign_configs[attr] = raw_ignition_config.get(attr)
        ign_configs['users'] = []
        for user in raw_ignition_config['users']:
            ign_configs['users'].append(self.get_ign_user(user))
        return ign_configs

    def prepare_iso(self):
        try:
            _, iso_path = self.fetch_iso_file()
            _, ign_file_path = self.fetch_controller_ign_file()
            logger.debug('iso_path: %s, ign_file_path: %s',
                         iso_path, ign_file_path)
            if self.inject_ignition(iso_path, ign_file_path):
                logger.error(
                    'inject ignition file error: iso_path: %s, filename', iso_path, f.name)
                self.clean_tmps()
                return ''
            dst_iso_path = self.params['iso_path']
            if not os.path.exists(dst_iso_path) or not os.path.samefile(iso_path, dst_iso_path):
                os.makedirs(os.path.dirname(dst_iso_path),
                            mode=0o750, exist_ok=True)
                shutil.copy(iso_path, dst_iso_path)
            self.clean_tmps()
            return dst_iso_path
        except Exception as e:
            logger.error('prepare iso error: %s', e)
            self.clean_tmps()
            return ''

    def update_ignition(self):
        config = self.params['ignition_config']
        ign_path = self.params['ignition_path']
        ignition = self.get_ignition(config)
        ignition = generate_ignition_from_config(ignition)
        original_ign = None
        with open(ign_path) as f:
            original_ign = json.load(f)
            logger.debug('original_ign: %s,ign: %s',
                         original_ign, ignition)
            if not merge_ignition(original_ign, ignition):
                return None
        with open(ign_path, 'w') as f:
            json.dump(original_ign, f, indent=4)
        return original_ign

    def pull_vol_files(self, file_items, params):
        vol_files = {}
        for file_item in file_items:
            try:
                file_url: ParseResult = urlparse(file_item['path'])
                logger.debug('file_url: %s', file_url)
                vol_res = {}
                vol_res['size'] = file_item['size']
                if file_url.scheme == 'file':
                    if os.path.getsize(file_url.path) != file_item['size']:
                        raise Exception(
                            'file size invalid for %s' % file_item)
                    vol_res['auto_clean'] = file_item.get(
                        'fc_auto_clean', False)
                    vol_res['path'] = file_url.path
                    vol_files[file_item['deviceId']] = vol_res
                else:
                    vol_pull_fn = self.get_file_pull_fn(params)
                    logger.debug('vol_pull_fn: %s', vol_pull_fn)
                    auto_clean, path = vol_pull_fn(file_item['path'], params)
                    vol_res['auto_clean'] = auto_clean
                    vol_res['path'] = path
                    logger.debug('auto_clean is %s, path is %s',
                                 auto_clean, path)
                    vol_files[file_item['deviceId']] = vol_res
                    if os.path.getsize(path) != file_item['size']:
                        logger.error('different size,%s, %s',
                                     os.path.getsize(path), file_item['size'])
                        raise Exception(
                            'file size invalid for %s' % file_item)
            except Exception as e:
                logger.exception(e)
                self.clean_files(vol_files)
                self.module.fail_json(
                    msg='Invalid schema for url: %s' % file_item['path'])
        return vol_files

    def get_file_pull_fn(self, params):
        return pull_fn_wrap(params.get('fc_pull_script'))

    def clean_files(self, vol_files: dict):
        for vol_info in vol_files.values():
            if not vol_info['auto_clean']:
                continue
            logger.debug('clean file, path is %s', vol_info['path'])
            if os.path.exists(vol_info['path']):
                os.remove(vol_info['path'])


def pull_fn_wrap(fc_pull_script):
    def fn(path, params):
        import subprocess
        args = ["python3", fc_pull_script, path, json.dumps(params)]
        result = subprocess.run(args, capture_output=True, text=True)
        stdout = result.stdout
        returncode = result.returncode
        if returncode != 0:
            return False, ''
        auto_clean, res_path = stdout.strip().split(' ')
        return auto_clean == 'True', res_path
    return fn



def run_module():
    # define available arguments/parameters a user can pass to the module
    module_args = FcModuleBase.args()
    module_args.update(
        action=dict(type='str', required=True),
        iso_url=dict(type='str', required=False),
        iso_path=dict(type='str', required=False),
        ignition_config=dict(type='dict', required=False),
        ignition_path=dict(type='str', required=False),
        fc_params=dict(type='dict', required=False, default={}),
    )
    module = AnsibleModule(
        argument_spec=module_args,
        supports_check_mode=True
    )
    fc_ocp_manager = FcOcpManager(module)
    fc_ocp_manager.execute()


def main():
    run_module()


if __name__ == '__main__':
    main()
