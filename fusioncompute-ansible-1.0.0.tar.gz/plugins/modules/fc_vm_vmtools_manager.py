#!/usr/bin/env python
# -*- coding:utf-8 -*-
#  Copyright (c) Huawei Technologies Co., Ltd. 2024-2024. All rights reserved.
from http import HTTPStatus
from enum import Enum

from ansible.module_utils.basic import AnsibleModule
from ansible_collections.huawei.fusioncompute.plugins.module_utils.core.fusincompute import logger
from ansible_collections.huawei.fusioncompute.plugins.module_utils.param_validator import hostname_validator_fn
from ansible_collections.huawei.fusioncompute.plugins.module_utils.decorator import action_injector, validator_injector
from ansible_collections.huawei.fusioncompute.plugins.module_utils.basic import FcAttrValidator, FcModuleBase

ANSIBLE_METADATA = {
    'metadata_version': '1.0.0',
    'status': ['preview'],
    'supported_by': 'standard'
}

DOCUMENTATION = '''
---
module: huawei.fusioncompute.fc_vm_vmtools_manager

short_description: Manage FusionCompute VM tools (mount/unmount)

version_added: "1.0.0"

description:
    - "This module is used to mount or unmount the VM tools for a FusionCompute virtual machine (VM)."
    - "It supports mounting or unmounting the tools, depending on the action specified."

options:
    vm_id:
        description:
            - The ID of the virtual machine (VM) for which the tools will be mounted or unmounted.
        required: true
        type: str

    action:
        description:
            - The action to perform. 
            - Supported values are
            - "'mount': Mount the VM tools."
            - "'unmount': Unmount the VM tools."
        required: true
        type: str
        choices: ['mount', 'unmount']
    
    # Parameters inherited from FcModuleBase:
    fc_hostname:
        description:
            - Host name or IP address of the FusionCompute VRM.
        required: true
        type: str

    fc_port:
        description:
            - Port number to connect to the FusionCompute VRM. Default is 7443.
        required: false
        default: 7443
        type: int

    fc_token:
        description:
            - Token for authentication. If provided, the module will skip login and use this token for authentication.
        required: false
        type: str

    fc_username:
        description:
            - Username for FusionCompute authentication.
        required: false
        type: str

    fc_password:
        description:
            - Password for authentication on the FusionCompute VRM.
        required: false
        type: str
        no_log: true
    
    fc_site_id:
        description:
            - Site ID for FusionCompute. If provided, the module will skip retrieving  site id and use this site ID.
        required: false
        type: str

    fc_language:
        description:
            - Language used for communication with FusionCompute VRM. Default is 'en-US'.
        required: false
        default: 'en-US'
        type: str

    fc_verify:
        description:
            - Path to rootCA.crt file for SSL certificate verification. If empty, SSL verification will be disabled.
        required: false
        default: ''
        type: str

author:
    - Huawei Technologies Co., Ltd.
'''

EXAMPLES = '''
# Example 1: Mount VM tools for a VM
- name: Mount VM tools for a VM
  fc_vm_vmtools_manager:
    action: "mount"
    vm_id: "i-xxxxxxxx"
    fc_hostname: "192.168.1.100"

# Example 2: Unmount VM tools for a VM
- name: Unmount VM tools for a VM
  fc_vm_vmtools_manager:
    action: "unmount"
    vm_id: "i-xxxxxxxx"
    fc_hostname: "192.168.1.100"
    fc_token: "xxxx"
  register: result

- name: Debug the result
  debug:
    var: result
'''

RETURN = '''
ret:
    description: The response from the FusionCompute API.
    type: dict
    returned: always
    contains:
        code:
            description: The HTTP status code of the operation.
            type: int
            returned: always
        rsp:
            description: The response body returned by the API.
            type: dict
            returned: always
'''


class VmToolsAction(Enum):
    mount = 'mount'
    unmount = 'unmount'


@action_injector(VmToolsAction)
@validator_injector([FcAttrValidator('fc_hostname', hostname_validator_fn)])
class FcVmVmtoolsManager(FcModuleBase):
    def __init__(self, module):
        super(FcVmVmtoolsManager, self).__init__(module)

    def execute(self):
        validate_res = self.validate()
        if validate_res:
            logger.info(
                "fc vm vmtools manager validate failed %s", validate_res)
            self.module.fail_json(msg=validate_res)
        action: VmToolsAction = self.action
        vm_id = self.params['vm_id']
        url = self.client.url_generator.vm_vmtools(
            self.client.site_id, vm_id, is_mount=action == VmToolsAction.mount)
        ret, rsp = self.client.post(url, {})
        if ret != HTTPStatus.OK:
            self.module.fail_json(
                msg="Couldn't mount vmtools: ret: %s, rsp: %s" % (ret, rsp.json()))
        else:
            self.module.exit_json(
                changed=True, ret={'code': ret, 'rsp': rsp})


def run_module():
    # define available arguments/parameters a user can pass to the module
    module_args = FcModuleBase.args()
    module_args.update(
        action=dict(type='str', required=True),
        vm_id=dict(type='str', required=True),
    )
    module = AnsibleModule(
        argument_spec=module_args,
        supports_check_mode=True
    )
    fc_vm_vmtools_manager = FcVmVmtoolsManager(module)
    fc_vm_vmtools_manager.execute()


def main():
    run_module()


if __name__ == '__main__':
    main()
