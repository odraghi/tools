#!/usr/bin/env python
# -*- coding:utf-8 -*-
#  Copyright (c) Huawei Technologies Co., Ltd. 2024-2024. All rights reserved.
from http import HTTPStatus
from enum import Enum

from ansible.module_utils.basic import AnsibleModule
from requests import Response
from ansible_collections.huawei.fusioncompute.plugins.module_utils.core.fusincompute import logger
from ansible_collections.huawei.fusioncompute.plugins.module_utils.param_validator import hostname_validator_fn
from ansible_collections.huawei.fusioncompute.plugins.module_utils.decorator import action_injector, validator_injector
from ansible_collections.huawei.fusioncompute.plugins.module_utils.basic import FcAttrValidator, FcModuleBase
from ansible_collections.huawei.fusioncompute.plugins.module_utils.core.parameter_normalization import normalize

ANSIBLE_METADATA = {
    'metadata_version': '1.0.0',
    'status': ['preview'],
    'supported_by': 'standard'
}

DOCUMENTATION = '''
---
module: huawei.fusioncompute.fc_vm_lifecycle_manager

short_description: Manage the lifecycle of virtual machines (VMs) on Huawei FusionCompute.

version_added: "1.0.0"

description:
    - This module allows you to manage the lifecycle of virtual machines (VMs) on Huawei FusionCompute.
    - It supports creating, starting, stopping, deleting, restarting, hibernating, converting to template and converting to VM.

options:
    action:
        description:
            - The action to perform.
            - Supported actions are 'create', 'start', 'stop', 'delete', 'restart', 'hibernate', 'convert_to_vm', 'convert_to_template'.
        required: true
        type: str
        choices: ['create', 'start', 'stop', 'delete', 'restart', 'hibernate', 'convert_to_vm', 'convert_to_template']

    vm_id:
        description:
            - The ID of the virtual machine (VM) to manage.
            - Required for all actions except 'create'.
        required: false
        type: str

    name:
        description:
            - The name of the VM to be created.
            - Required for 'create' action.
        required: false
        type: str
    arch:
        description:
            - The architecture of the VM (e.g., 'x86', 'arm').
        required: false
        type: str
    description:
        description:
            - The description of the VM.
        required: false
        type: str
    group:
        description:
            - The group to which the VM belongs.
        required: false
        type: str
    location:
        description:
            - The location of the VM.
            - Required for 'create' action.
        required: false
        type: str
    isBindingHost:
        description:
            - Whether the VM is bound to a specific host.
        required: false
        type: bool
    vmConfig:
        description:
            - The configuration of the VM (e.g., CPU, memory, disks).
            - Required for 'create' action.
        required: false
        type: dict
    autoBoot:
        description:
            - Whether the VM should automatically boot after creation.
        required: false
        type: bool
    osOptions:
        description:
            - The operating system options for the VM.
        required: false
        type: dict
    vncAccessInfo:
        description:
            - The VNC access information for the VM.
        required: false
        type: dict
    occupiedVm:
        description:
            - Whether the VM is occupied.
        required: false
        type: bool
    uuid:
        description:
            - The UUID of the VM.
        required: false
        type: str
    externalUuid:
        description:
            - The external UUID of the VM.
        required: false
        type: str
    securityGroupSet:
        description:
            - The security group settings for the VM.
        required: false
        type: dict
    isMultiDiskSpeedup:
        description:
            - Whether multi-disk speedup is enabled for the VM.
        required: false
        type: bool
    parentObjUrn:
        description:
            - The URN of the parent object (e.g., template or snapshot).
        required: false
        type: str
    resourceGroup:
        description:
            - The resource group to which the VM belongs.
        required: false
        type: str
    enableImc:
        description:
            - Whether IMC (Integrated Management Controller) is enabled for the VM.
        required: false
        type: bool
    imcSetting:
        description:
            - The IMC settings for the VM.
        required: false
        type: str
    floppyFile:
        description:
            - The floppy file for the VM.
        required: false
        type: str
    floppyProtocol:
        description:
            - The protocol used for the floppy file (e.g., 'nfs', 'cifs').
        required: false
        type: str
    customProperties:
        description:
            - Custom properties for the VM.
        required: false
        type: dict

    mode:
        description:
            - The mode for stopping or restarting the VM (e.g., 'soft', 'hard').
        required: false
        type: str

    isReserveDisks:
        description:
            - Whether to reserve the disks when deleting the VM.
        required: false
        type: int
    isFormat:
        description:
            - Whether to format the disks when deleting the VM.
        required: false
        type: int
    holdTime:
        description:
            - The hold time before deleting the VM (in seconds).
        required: false
        type: int
    isOnlyDeleteDisksInDB:
        description:
            - Whether to only delete the disks in the database.
        required: false
        type: int
    isDeleteShareDisks:
        description:
            - Whether to delete shared disks.
        required: false
        type: int
    vmBin:
        description:
            - The VM bin file.
        required: false
        type: str

    url:
        description:
            - The URL for VM resources (if applicable).
        required: false
        type: str

    protocol:
        description:
            - The protocol used for accessing VM resources.
        required: false
        type: str

    glanceConfig:
        description:
            - Configuration for Glance integration (image management).
        required: false
        type: dict

    s3Config:
        description:
            - Configuration for S3 storage integration.
        required: false
        type: dict

    username:
        description:
            - The username for authentication.
        required: false
        type: str

    password:
        description:
            - The password for authentication.
        required: false
        type: str
        no_log: true

    publickey:
        description:
            - The public key for SSH authentication.
        required: false
        type: str

    vmCustomization:
        description:
            - Customization options for the VM (e.g., hostname, network settings).
        required: false
        type: dict

    isTemplate:
        description:
            - Whether the VM is a template.
        required: false
        type: bool

    vmId:
        description:
            - The VM ID.
        required: false
        type: str

    recover:
        description:
            - Whether to recover a deleted VM.
        required: false
        type: bool

    cdRomProtocol:
        description:
            - The protocol used for the CD-ROM.
        required: false
        type: str

    cdRomFileId:
        description:
            - The ID of the CD-ROM file.
        required: false
        type: int

    cdRomDevicePath:
        description:
            - The device path for the CD-ROM.
        required: false
        type: str

    cdRomAttachAtPowerOn:
        description:
            - Whether the CD-ROM is attached at power-on.
        required: false
        type: bool

    vmCategory:
        description:
            - The category of the VM.
        required: false
        type: int

    format:
        description:
            - The format of the VM image.
        required: false
        type: str

    isOverwrite:
        description:
            - Whether to overwrite an existing VM image.
        required: false
        type: bool

    imageFormat:
        description:
            - The format of the image (e.g., QCOW2, RAW).
        required: false
        type: str

    registerType:
        description:
            - The registration type for the VM.
        required: false
        type: int

    updateOption:
        description:
            - The update option for the VM.
        required: false
        type: int

    srcInstanceId:
        description:
            - The source instance ID for cloning.
        required: false
        type: str

    status:
        description:
            - The current status of the VM.
        required: false
        type: str

    datastoreUrn:
        description:
            - The URN of the datastore where the VM is stored.
        required: false
        type: str

    speed:
        description:
            - The speed configuration for the VM.
        required: false
        type: int

    isSrcTemplate:
        description:
            - Whether the VM is a source template.
        required: false
        type: bool

    isEnableIntegrity:
        description:
            - Whether integrity verification is enabled.
        required: false
        type: bool
        
    # Parameters inherited from FcModuleBase:
    fc_hostname:
        description:
            - Host name or IP address of the FusionCompute VRM.
        required: true
        type: str

    fc_port:
        description:
            - Port number to connect to the FusionCompute VRM. Default is 7443.
        required: false
        default: 7443
        type: int

    fc_token:
        description:
            - Token for authentication. If provided, the module will skip login and use this token for authentication.
        required: false
        type: str

    fc_username:
        description:
            - Username for FusionCompute authentication.
        required: false
        type: str

    fc_password:
        description:
            - Password for authentication on the FusionCompute VRM.
        required: false
        type: str
        no_log: true
    
    fc_site_id:
        description:
            - Site ID for FusionCompute. If provided, the module will skip retrieving  site id and use this site ID.
        required: false
        type: str

    fc_language:
        description:
            - Language used for communication with FusionCompute VRM. Default is 'en-US'.
        required: false
        default: 'en-US'
        type: str

    fc_verify:
        description:
            - Path to rootCA.crt file for SSL certificate verification. If empty, SSL verification will be disabled.
        required: false
        default: ''
        type: str

author:
    - Huawei Technologies Co., Ltd.
'''

EXAMPLES = '''
# Create a VM
vars:
    action: 'create'
    name: "VM for Ansible"
    description: ""
    location: "urn:sites:xxxxxx:hosts:xxx"
    parentObjUrn: "urn:sites:xxxxxx"
    enableImc: false
    isBindingHost: false
    osOptions:
      osType: "Linux"
      osVersion: 10008
    vmConfig:
      cpu:
        cpuHotPlug: 0
        cpuPolicy: "shared"
        cpuThreadPolicy: "prefer"
        weight: 1000
        quantity: 2
        limit: 0
        reservation: 0
        coresPerSocket: 1
      memory:
        quantityMB: 4096
        hugePage: "4K"
        limit: 0
        reservation: 0
        weight: 40960
      disks:
        - datastoreUrn: "urn:sites:xxxxxx:datastores:xxx"
          quantityGB: 1
          sequenceNum: 1
          type: "normal"
          indepDisk: false
          persistentDisk: true
          isThin: false
          volType: 1
          pciType: "VIRTIO"
          bootOrder: -1
          encrypted: "0"
          storageProtocol: "0"
      nics:
        - enableSecurityGroup: false
          portGroupUrn: "urn:sites:xxxxxx:dvswitchs:xxxx:portgroups:xxxx"
          sequenceNum: 0
          virtIo: 1
          bootOrder: -1
          connectAtPowerOn: true
          linkStatus: "disconnected"
          nicConfig:
            vringbuf: 256
            queues: 1
      graphicsCard:
        type: "cirrus"
        size: 4
      properties:
        antivirusMode: ""
        isAutoAdjustNuma: false
        bootFirmware: "BIOS"
        bootFirmwareTime: 0
        bootOption: "disk"
        clockMode: "synchClock"
        vmVncKeymapSetting: 7
        isHpet: false
        isEnableHa: false
        evsAffinity: false
        secureVmType: ""
        realtime: false
        isEnableMemVol: false
        isEnableFt: false
        isAutoUpgrade: true
        emulatorResType: null
        dpiVmType: ""
        cdRomBootOrder: -1
        attachType: false
        enableWatchDog: false
        isSecureBoot: false
        migrateSetting: "passThrough"
        enableKae: false
        reoverByHost: false
        enableSpice: false
    gpuGroups: []
    autoBoot: true
    isSrcTemplate: false
    isEnableIntegrity: false
- name: Create a VM
  huawei.fusioncompute.fc_vm_lifecycle_manager:
    action: create
    fc_hostname: "192.168.1.100"
    fc_token: "xxxx"
    name: "{{ name }}"
    description: "{{ description }}"
    location: "{{ location }}"
    parentObjUrn: "{{ parentObjUrn }}"
    enableImc: "{{ enableImc }}"
    isBindingHost: "{{ isBindingHost }}"
    osOptions: "{{ osOptions }}"
    vmConfig: "{{ vmConfig }}"
    autoBoot: "{{ autoBoot }}"
  register: result

# Start a VM
- name: Start a VM
  huawei.fusioncompute.fc_vm_lifecycle_manager:
    action: start
    fc_hostname: "192.168.1.100"
    fc_token: "xxxx"
    vm_id: "i-xxxxxxxx"
  register: result

# Stop a VM
- name: Stop a VM
  huawei.fusioncompute.fc_vm_lifecycle_manager:
    action: stop
    fc_hostname: "192.168.1.100"
    fc_token: "xxxx"
    vm_id: "i-xxxxxxxx"
    mode: "soft"
  register: result

- name: Debug the result
  debug:
    var: result
'''

RETURN = '''
ret:
    description: The response from the FusionCompute API.
    type: dict
    returned: always
    contains:
        code:
            description: The HTTP status code of the operation.
            type: int
            returned: always
        rsp:
            description: The response body returned by the API.
            type: dict
            returned: always
'''


class LifecycleManagerAction(Enum):
    create = 'create'
    start = 'start'
    stop = 'stop'
    delete = 'delete'
    restart = 'restart'
    hibernate = 'hibernate'
    convert2vm = 'convert_to_vm'
    convert2template = 'convert_to_template'

    do_import = 'do_import'
    clone = 'clone'
    register = 'register'
    export = 'export'


@action_injector(LifecycleManagerAction)
@validator_injector([FcAttrValidator('fc_hostname', hostname_validator_fn)])
class FcVmLifecycleManager(FcModuleBase):
    def __init__(self, module):
        super(FcVmLifecycleManager, self).__init__(module)

    def execute(self):
        validate_res = self.validate()
        if validate_res:
            logger.error(
                "fc vm lifecycle manager params validate failed %s", validate_res)
            self.module.fail_json(msg=validate_res)
        action: LifecycleManagerAction = self.action
        vm_id = self.params['vm_id']
        match action:
            case LifecycleManagerAction.create:
                ret, rsp = self.do_create()
            case LifecycleManagerAction.start:
                ret, rsp = self.do_start()
            case LifecycleManagerAction.stop:
                ret, rsp = self.do_stop()
            case LifecycleManagerAction.delete:
                ret, rsp = self.do_delete()
            case LifecycleManagerAction.restart:
                ret, rsp = self.do_restart()
            case LifecycleManagerAction.hibernate:
                ret, rsp = self.do_hibernate()
            case LifecycleManagerAction.convert2template | LifecycleManagerAction.convert2vm:
                ret, rsp = self.do_convert(action)
            case LifecycleManagerAction.do_import:
                ret, rsp = self.do_import()
            case LifecycleManagerAction.export:
                ret, rsp = self.do_export()
            case LifecycleManagerAction.clone:
                ret, rsp = self.do_clone()
            case LifecycleManagerAction.register:
                ret, rsp = self.do_register()
            case _:
                self.module.fail_json(
                    changed=False, msg='param action type invalid.')
        if ret != HTTPStatus.OK:
            self.module.fail_json(
                msg="Couldn't manage vm lifecycle: ret: %s, rsp: %s" % (ret, rsp.json()))
        else:
            self.module.exit_json(
                changed=True, ret={'code': ret, 'rsp': rsp})

    def do_convert(self, action):
        vm_id = self.params['vm_id']
        url = self.client.url_generator.vms(
            self.client.site_id, vm_id)
        data = {
            'isTemplate': action == LifecycleManagerAction.convert2template,
        }
        return self.client.put(url, data)

    def do_hibernate(self):
        vm_id = self.params['vm_id']
        url = self.client.url_generator.vms_hibernate(
            self.client.site_id, vm_id)
        return self.client.post(url, {})

    def do_restart(self):
        vm_id = self.params['vm_id']
        mode = self.params['mode']
        params = {
            'mode': mode,
        }
        url = self.client.url_generator.vms_restart(
            self.client.site_id, vm_id)
        return self.client.post(url, normalize(params))

    def do_stop(self):
        vm_id = self.params['vm_id']
        mode = self.params['mode']
        data = {
            'mode': mode,
        }
        url = self.client.url_generator.vms_stop(
            self.client.site_id, vm_id)
        return self.client.post(url, normalize(data))

    def do_start(self):
        vm_id = self.params['vm_id']
        url = self.client.url_generator.vms_start(
            self.client.site_id, vm_id)
        return self.client.post(url, {})

    def do_delete(self):
        vm_id = self.params['vm_id']
        params = ['isReserveDisks', 'isFormat', 'holdTime',
                  'isOnlyDeleteDisksInDB', 'isDeleteShareDisks', 'vmBin',
                  ]
        data = self.exact_params(params)
        url = self.client.url_generator.vms(self.client.site_id, vm_id)
        return self.client.delete(url, normalize(data))

    def do_create(self):
        params = ['name', 'arch', 'description', 'group', 'location',
                  'isBindingHost', 'vmConfig', 'autoBoot', 'osOptions',
                  'vncAccessInfo', 'occupiedVm', 'uuid', 'externalUuid',
                  'securityGroupSet', 'isMultiDiskSpeedup', 'parentObjUrn',
                  'resourceGroup', 'enableImc', 'imcSetting', 'floppyFile',
                  'cdRomProtocol', 'cdRomFileId', 'cdRomDevicePath',
                  'cdRomAttachAtPowerOn', 'floppyProtocol', 'customProperties',
                  ]
        data = self.exact_params(params)
        url = self.client.url_generator.vms(
            self.client.site_id)
        return self.client.post(url, normalize(data))

    def do_import(self):
        params = ['name', 'arch', 'description', 'group', 'location',
                  'vmConfig', 'osOptions', 'fileItems', 'url', 'protocol',
                  'glanceConfig', 's3Config', 'username', 'password',
                  'autoBoot', 'publickey', 'vmCustomization', 'vncAccessInfo',
                  'floppyProtocol', 'customProperties', 'isTemplate', 'vmId',
                  'uuid', 'isBindingHost', 'securityGroupSet', 'recover', 'isMultiDiskSpeedup',
                  'resourceGroup', 'enableImc', 'imcSetting', 'floppyFile', 'floppyProtocol',
                  'cdRomProtocol', 'cdRomFileId', 'cdRomDevicePath', 'cdRomAttachAtPowerOn',
                  'customProperties', 'vmCategory',
                  ]
        data = self.exact_params(params)
        url = self.client.url_generator.vms_import(
            self.client.site_id)
        return self.client.post(url, normalize(data))

    def do_export(self):
        vm_id = self.params['vm_id']
        params = ['name', 'format', 'url', 'protocol',
                  'glanceConfig', 's3Config', 'username', 'password',
                  'isOverwrite', 'vmConfig', 'imageFormat',
                  ]
        data = self.exact_params(params)
        url = self.client.url_generator.vms_export(
            self.client.site_id, vm_id)
        return self.client.post(url, normalize(data))

    def do_clone(self):
        vm_id = self.params['vm_id']
        params = ['name', 'arch', 'description', 'group', 'location',
                  'isBindingHost', 'vmConfig', 'osOptions', 'isTemplate',
                  'autoBoot', 'isLinkClone', 'vmCustomizationId', 'regionInfo',
                  'vmCustomization', 'publickey', 'vncAccessInfo', 'fileMode',
                  'drDrillOption', 'uuid', 'isMultiDiskSpeedup', 'fileNames',
                  'vmDatas', 'version', 'clonedVmUUID', 'parentObjUrn',
                  'enableImc', 'imcSetting', 'floppyFile', 'floppyProtocol',
                  'cdRomProtocol', 'cdRomFileId', 'cdRomDevicePath', 'cdRomAttachAtPowerOn',
                  'customProperties', 'isSrcTemplate', 'isEnableIntegrity',
                  ]
        data = self.exact_params(params)
        url = self.client.url_generator.vms_clone(
            self.client.site_id, vm_id)
        return self.client.post(url, normalize(data))

    def do_register(self):
        params = ['name', 'uuid', 'description', 'group', 'location',
                  'isBindingHost', 'vmConfig', 'osOptions', 'isTemplate',
                  'registerType', 'vmCustomization', 'updateOption', 'isMultiDiskSpeedup',
                  'customProperties', 'autoBoot', 'floppyFile', 'floppyProtocol',
                  'srcInstanceId', 'status', 'datastoreUrn', 'speed',
                  ]
        data = self.exact_params(params)
        url = self.client.url_generator.vms_register(
            self.client.site_id)
        return self.client.post(url, normalize(data))


def run_module():
    # define available arguments/parameters a user can pass to the module
    module_args = FcModuleBase.args()
    module_args.update(
        action=dict(type='str', required=True),
        vm_id=dict(type='str', required=False),
        name=dict(type='str', required=False), arch=dict(type='str', required=False),
        description=dict(type='str', required=False), group=dict(type='str', required=False),
        location=dict(type='str', required=False), isBindingHost=dict(type='bool', required=False),
        vmConfig=dict(type='dict', required=False), autoBoot=dict(type='bool', required=False),
        osOptions=dict(type='dict', required=False), vncAccessInfo=dict(type='dict', required=False),
        occupiedVm=dict(type='bool', required=False), uuid=dict(type='str', required=False),
        externalUuid=dict(type='str', required=False), securityGroupSet=dict(type='dict', required=False),
        isMultiDiskSpeedup=dict(type='bool', required=False), parentObjUrn=dict(type='str', required=False),
        resourceGroup=dict(type='str', required=False), enableImc=dict(type='bool', required=False),
        imcSetting=dict(type='str', required=False), floppyFile=dict(type='str', required=False),
        floppyProtocol=dict(type='str', required=False), customProperties=dict(type='dict', required=False),
        mode=dict(type='str', required=False), isReserveDisks=dict(type='int', required=False),
        isFormat=dict(type='int', required=False), holdTime=dict(type='int', required=False),
        isOnlyDeleteDisksInDB=dict(type='int', required=False), isDeleteShareDisks=dict(type='int', required=False),
        vmBin=dict(type='str', required=False), url=dict(type='str', required=False),
        protocol=dict(type='str', required=False), glanceConfig=dict(type='dict', required=False),
        s3Config=dict(type='dict', required=False), username=dict(type='str', required=False),
        password=dict(type='str', required=False, no_log=True), publickey=dict(type='str', required=False),
        vmCustomization=dict(type='dict', required=False), isTemplate=dict(type='bool', required=False),
        vmId=dict(type='str', required=False), recover=dict(type='bool', required=False),
        cdRomProtocol=dict(type='str', required=False), cdRomFileId=dict(type='int', required=False),
        cdRomDevicePath=dict(type='str', required=False), cdRomAttachAtPowerOn=dict(type='bool', required=False),
        vmCategory=dict(type='int', required=False), format=dict(type='str', required=False),
        isOverwrite=dict(type='bool', required=False), imageFormat=dict(type='str', required=False),
        registerType=dict(type='int', required=False), updateOption=dict(type='int', required=False),
        srcInstanceId=dict(type='str', required=False), status=dict(type='str', required=False),
        datastoreUrn=dict(type='str', required=False), speed=dict(type='int', required=False),
        isSrcTemplate=dict(type='bool', required=False), isEnableIntegrity=dict(type='bool', required=False),
    )
    module = AnsibleModule(
        argument_spec=module_args,
        supports_check_mode=True
    )
    fc_vm_lifecycle_manager = FcVmLifecycleManager(module)
    fc_vm_lifecycle_manager.execute()


def main():
    run_module()


if __name__ == '__main__':
    main()
