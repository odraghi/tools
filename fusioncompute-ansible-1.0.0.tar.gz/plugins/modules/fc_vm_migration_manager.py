#!/usr/bin/env python
# -*- coding:utf-8 -*-
#  Copyright (c) Huawei Technologies Co., Ltd. 2024-2024. All rights reserved.
from http import HTTPStatus
from enum import Enum

from ansible.module_utils.basic import AnsibleModule
from ansible_collections.huawei.fusioncompute.plugins.module_utils.core.fusincompute import logger
from ansible_collections.huawei.fusioncompute.plugins.module_utils.param_validator import hostname_validator_fn
from ansible_collections.huawei.fusioncompute.plugins.module_utils.decorator import action_injector, validator_injector
from ansible_collections.huawei.fusioncompute.plugins.module_utils.basic import FcAttrValidator, FcModuleBase
from ansible_collections.huawei.fusioncompute.plugins.module_utils.core.parameter_normalization import normalize

ANSIBLE_METADATA = {
    'metadata_version': '1.0.0',
    'status': ['preview'],
    'supported_by': 'standard'
}

DOCUMENTATION = '''
---
module: huawei.fusioncompute.fc_vm_migration_manager

short_description: Manage virtual machine (VM) migration on Huawei FusionCompute.

version_added: "1.0.0"

description:
    - This module allows you to manage the migration of virtual machines (VMs) on Huawei FusionCompute.
    - It supports full migration, host migration, storage migration, and cross-site migration.

options:
    action:
        description:
            - The action to perform.
            - Supported actions are 'migrate_full', 'migrate_host', 'migrate_storage', and 'migrate_cross_site'.
        required: true
        type: str
        choices: ['migrate_full', 'migrate_host', 'migrate_storage', 'migrate_cross_site']

    vm_id:
        description:
            - The ID of the virtual machine (VM) to be migrated.
        required: true
        type: str

    location:
        description:
            - The destination location for the migration.
        required: false
        type: str

    srcLocation:
        description:
            - The source location for the migration.
        required: false
        type: str

    isBindingHost:
        description:
            - Whether the VM is bound to a specific host after migration.
        required: false
        type: bool

    disks:
        description:
            - The list of disks to be migrated.
        required: false
        type: list

    speed:
        description:
            - The speed of the migration.
        required: false
        type: str

    migrateVmTimeOut:
        description:
            - The timeout for the migration operation (in seconds).
        required: false
        type: int

    isFrequencyReduce:
        description:
            - Whether to reduce the frequency of migration operations.
        required: false
        type: bool

    frequencyReduceLimit:
        description:
            - The limit for frequency reduction during migration.
        required: false
        type: int

    migrateTransmitPolicy:
        description:
            - The transmission policy for the migration.
        required: false
        type: str

    enableMemoryCompression:
        description:
            - Whether to enable memory compression during host migration.
        required: false
        type: bool

    resourceGroup:
        description:
            - The resource group for the migration.
        required: false
        type: str

    # Parameters inherited from FcModuleBase:
    fc_hostname:
        description:
            - Host name or IP address of the FusionCompute VRM.
        required: true
        type: str

    fc_port:
        description:
            - Port number to connect to the FusionCompute VRM. Default is 7443.
        required: false
        default: 7443
        type: int

    fc_token:
        description:
            - Token for authentication. If provided, the module will skip login and use this token for authentication.
        required: false
        type: str

    fc_username:
        description:
            - Username for FusionCompute authentication.
        required: false
        type: str

    fc_password:
        description:
            - Password for authentication on the FusionCompute VRM.
        required: false
        type: str
        no_log: true
    
    fc_site_id:
        description:
            - Site ID for FusionCompute. If provided, the module will skip retrieving  site id and use this site ID.
        required: false
        type: str

    fc_language:
        description:
            - Language used for communication with FusionCompute VRM. Default is 'en-US'.
        required: false
        default: 'en-US'
        type: str

    fc_verify:
        description:
            - Path to rootCA.crt file for SSL certificate verification. If empty, SSL verification will be disabled.
        required: false
        default: ''
        type: str

author:
    - Huawei Technologies Co., Ltd.
'''

EXAMPLES = '''
vars:
    action: 'migrate_full'
    vm_id: 'i-xxxxxxxx'
    isBindingHost: false
    migrateVmTimeOut: 60
    location: "urn:sites:xxxxxx:hosts:xxx"
    srcLocation: "urn:sites:xxxxxx:hosts:xxx"
    speed: "fast"
    disks:
      - datastoreUrn: "urn:sites:xxxxxx:datastores:xxx"
        volumeUrn: "urn:sites:xxxxxx:volumes:xxx"
        migrateType: 1
        encrypted: "0"
    migrateTransmitPolicy: "NONE"
    isFrequencyReduce: false
    frequencyReduceLimit: 30
# Perform a full migration of a VM
- name: Perform a full migration of a VM
  huawei.fusioncompute.fc_vm_migration_manager:
    action: migrate_full
    fc_hostname: "192.168.1.100"
    fc_token: "xxxx"
    vm_id: '{{vm_id}}'
    isBindingHost: '{{isBindingHost}}'
    migrateVmTimeOut: '{{migrateVmTimeOut}}'
    location: '{{location}}'
    srcLocation: '{{srcLocation}}'
    speed: '{{speed}}'
    disks: '{{disks}}'
    migrateTransmitPolicy: '{{migrateTransmitPolicy}}'
    isFrequencyReduce: '{{isFrequencyReduce}}'
    frequencyReduceLimit: '{{frequencyReduceLimit}}'
  register: result

# Perform a host migration of a VM
- name: Perform a host migration of a VM
  huawei.fusioncompute.fc_vm_migration_manager:
    action: migrate_host
    fc_hostname: "192.168.1.100"
    fc_token: "xxxx"
    vm_id: '{{vm_id}}'
    migrateVmTimeOut: '{{migrateVmTimeOut}}'
    location: '{{location}}'
    srcLocation: '{{srcLocation}}'
    migrateTransmitPolicy: '{{migrateTransmitPolicy}}'
    isFrequencyReduce: '{{isFrequencyReduce}}'
    frequencyReduceLimit: '{{frequencyReduceLimit}}'
  register: result

- name: Debug the result
  debug:
    var: result
'''

RETURN = '''
ret:
    description: The response from the FusionCompute API.
    type: dict
    returned: always
    contains:
        code:
            description: The HTTP status code of the operation.
            type: int
            returned: always
        rsp:
            description: The response body returned by the API.
            type: dict
            returned: always
'''


class MigrationManagerAction(Enum):
    migrate_full = 'migrate_full'
    migrate_host = 'migrate_host'
    migrate_storage = 'migrate_storage'
    migrate_cross_site = 'migrate_cross_site'


@action_injector(MigrationManagerAction)
@validator_injector([FcAttrValidator('fc_hostname', hostname_validator_fn)])
class FcVmMigrationManager(FcModuleBase):
    def __init__(self, module):
        super(FcVmMigrationManager, self).__init__(module)

    def execute(self):
        validate_res = self.validate()
        if validate_res:
            logger.error(
                "fc vm migration manager params validate failed %s", validate_res)
            self.module.fail_json(msg=validate_res)
        action: MigrationManagerAction = self.action
        vm_id = self.params['vm_id']
        match action:
            case MigrationManagerAction.migrate_full:
                ret, rsp = self.do_migrate_full()
            case MigrationManagerAction.migrate_host:
                ret, rsp = self.do_migrate_host()
            case MigrationManagerAction.migrate_storage:
                ret, rsp = self.do_migrate_storage()
            case _:
                self.module.fail_json(
                    changed=False, msg='param action type invalid.')
        if ret != HTTPStatus.OK:
            self.module.fail_json(
                msg="Couldn't manage vm migration: ret: %s, rsp: %s" % (ret, rsp.json()))
        else:
            self.module.exit_json(
                changed=True, ret={'code': ret, 'rsp': rsp})

    def do_migrate_storage(self):
        vm_id = self.params['vm_id']
        disks = self.params['disks']
        speed = self.params['speed']
        is_frequency_reduce = self.params['isFrequencyReduce']
                # Create the data dictionary with camelCase keys
        params = {
                    'disks': disks,
                    'speed': speed,
                    'isFrequencyReduce': is_frequency_reduce,
                }
        url = self.client.url_generator.vms_migrate_storage(
                    self.client.site_id, vm_id)
        return self.client.post(url, normalize(params))

    def do_migrate_host(self):
        vm_id = self.params['vm_id']
        location = self.params['location']
        src_location = self.params['srcLocation']
        is_binding_host = self.params['isBindingHost']
        enable_memory_compression = self.params['enableMemoryCompression']
        is_frequency_reduce = self.params['isFrequencyReduce']
        frequency_reduce_limit = self.params['frequencyReduceLimit']
        resource_group = self.params['resourceGroup']
        migrate_vm_timeout = self.params['migrateVmTimeOut']
        migrate_transmit_policy = self.params['migrateTransmitPolicy']
                # Create the data dictionary with camelCase keys
        params = {
                    'location': location,
                    'srcLocation': src_location,
                    'isBindingHost': is_binding_host,
                    'enableMemoryCompression': enable_memory_compression,
                    'isFrequencyReduce': is_frequency_reduce,
                    'frequencyReduceLimit': frequency_reduce_limit,
                    'resourceGroup': resource_group,
                    'migrateVmTimeOut': migrate_vm_timeout,
                    'migrateTransmitPolicy': migrate_transmit_policy
                }
        url = self.client.url_generator.vms_migrate_host(
                    self.client.site_id, vm_id)
        return self.client.post(url, normalize(params))

    def do_migrate_full(self):
        vm_id = self.params['vm_id']
        location = self.params['location']
        src_location = self.params['srcLocation']
        is_binding_host = self.params['isBindingHost']
        disks = self.params['disks']
        speed = self.params['speed']
        migrate_vm_timeout = self.params['migrateVmTimeOut']
        is_frequency_reduce = self.params['isFrequencyReduce']
        frequency_reduce_limit = self.params['frequencyReduceLimit']
        migrate_transmit_policy = self.params['migrateTransmitPolicy']
                # Create the data dictionary with camelCase keys
        params = {
                    'location': location,
                    'srcLocation': src_location,
                    'isBindingHost': is_binding_host,
                    'disks': disks,
                    'speed': speed,
                    'migrateVmTimeOut': migrate_vm_timeout,
                    'isFrequencyReduce': is_frequency_reduce,
                    'frequencyReduceLimit': frequency_reduce_limit,
                    'migrateTransmitPolicy': migrate_transmit_policy,
                }
        url = self.client.url_generator.vms_migrate_full(
                    self.client.site_id, vm_id)
        return self.client.post(url, normalize(params))


def run_module():
    # define available arguments/parameters a user can pass to the module
    module_args = FcModuleBase.args()
    module_args.update(
        action=dict(type='str', required=True),
        vm_id=dict(type='str', required=True),
        # migrate
        location=dict(type='str', required=False),
        srcLocation=dict(type='str', required=False),
        isBindingHost=dict(type='bool', required=False),
        enableMemoryCompression=dict(type='bool', required=False),
        isFrequencyReduce=dict(type='bool', required=False),
        frequencyReduceLimit=dict(type='int', required=False),
        migrateVmTimeOut=dict(type='int', required=False),
        migrateTransmitPolicy=dict(type='str', required=False),
        resourceGroup=dict(type='str', required=False),
        disks=dict(type='list', required=False),
        speed=dict(type='str', required=False),
    )
    module = AnsibleModule(
        argument_spec=module_args,
        supports_check_mode=True
    )
    fc_vm_migration_manager = FcVmMigrationManager(module)
    fc_vm_migration_manager.execute()


def main():
    run_module()


if __name__ == '__main__':
    main()
