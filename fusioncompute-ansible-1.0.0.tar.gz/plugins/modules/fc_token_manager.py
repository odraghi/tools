#!/usr/bin/env python
# -*- coding:utf-8 -*-
#  Copyright (c) Huawei Technologies Co., Ltd. 2024-2024. All rights reserved.
from http import HTTPStatus
from enum import Enum

from ansible.module_utils.basic import AnsibleModule
from ansible_collections.huawei.fusioncompute.plugins.module_utils.core.fusincompute import logger
from ansible_collections.huawei.fusioncompute.plugins.module_utils.param_validator import hostname_validator_fn
from ansible_collections.huawei.fusioncompute.plugins.module_utils.decorator import action_injector, validator_injector
from ansible_collections.huawei.fusioncompute.plugins.module_utils.basic import FcAttrValidator, FcModuleBase

ANSIBLE_METADATA = {
    'metadata_version': '1.0.0',
    'status': ['preview'],
    'supported_by': 'huawei'
}

DOCUMENTATION = '''
---
module: huawei.fusioncompute.fc_token_manager

short_description: Manage FusionCompute tokens (login/logout)

version_added: "1.0.0"

description:
    - "This module manages FusionCompute tokens. It supports login and logout actions."
    - "The module can log in to FusionCompute to obtain an authentication token, and it can log 
       out to invalidate the token."

options:
    action:
        description:
            - Specify the action to be performed. Supported actions are "login" and "logout".
        required: true
        choices: ['login', 'logout']
    
    # Parameters inherited from FcModuleBase:
    fc_hostname:
        description:
            - Host name or IP address of the FusionCompute VRM.
        required: true
        type: str

    fc_port:
        description:
            - Port number to connect to the FusionCompute VRM. Default is 7443.
        required: false
        default: 7443
        type: int

    fc_token:
        description:
            - Token for authentication. If provided, the module will skip login and use this token for authentication.
        required: false
        type: str

    fc_username:
        description:
            - Username for FusionCompute authentication.
        required: false
        type: str

    fc_password:
        description:
            - Password for authentication on the FusionCompute VRM.
        required: false
        type: str
        no_log: true
    
    fc_site_id:
        description:
            - Site ID for FusionCompute. If provided, the module will skip retrieving  site id and use this site ID.
        required: false
        type: str

    fc_language:
        description:
            - Language used for communication with FusionCompute VRM. Default is 'en-US'.
        required: false
        default: 'en-US'
        type: str

    fc_verify:
        description:
            - Path to rootCA.crt file for SSL certificate verification. If empty, SSL verification will be disabled.
        required: false
        default: ''
        type: str

author:
    - Huawei Technologies Co., Ltd.
'''

EXAMPLES = '''
# Log in and obtain a token
- name: Log in to FusionCompute
  huawei.fusioncompute.fc_token_manager:
    action: login
    fc_hostname: "192.168.1.100"
    fc_username: "admin"
    fc_password: "xxxxxx"
    fc_verify: "path_to_ca_file"
    fc_language: "en-US"

# Log out and invalidate the token
- name: Log out from FusionCompute
  huawei.fusioncompute.fc_token_manager:
    action: logout
    fc_hostname: "192.168.1.100"
    fc_token: "xxxx"
    fc_verify: "path_to_ca_file"
    fc_language: "en-US"
'''

RETURN = '''
ret:
    description: The result of the operation, including HTTP status code and the token if login was successful
    type: dict
    returned: always
    contains:
        code:
            description: The HTTP status code of the operation
            type: int
        fc_token:
            description: The token returned if the action is login
            type: str
'''


class TokenAction(Enum):
    login = 'login'
    logout = 'logout'


@action_injector(TokenAction)
@validator_injector([FcAttrValidator('fc_hostname', hostname_validator_fn)])
class FcTokenManager(FcModuleBase):
    def __init__(self, module):
        super(FcTokenManager, self).__init__(module)

    def execute(self):
        validate_res = self.validate()
        if validate_res:
            logger.info("fc token manager validate failed %s", validate_res)
            self.module.fail_json(msg=validate_res)
        action: TokenAction = self.action
        match action:
            case TokenAction.login:
                ret_code = HTTPStatus.OK if self.client.fc_token is not None else HTTPStatus.INTERNAL_SERVER_ERROR
                self.module.exit_json(changed=True, ret={
                                      'code': ret_code, 'fc_token': self.client.fc_token, 'fc_site_id': self.client.site_id})
            case TokenAction.logout:
                ret_code = self.client.logout()
                self.module.exit_json(changed=True, ret={'code': ret_code})
            case _:
                self.module.fail_json(
                    changed=False, msg='param action type invalid.')


def run_module():
    # define available arguments/parameters a user can pass to the module
    module_args = FcModuleBase.args()
    module_args.update(
        action=dict(type='str', required=True),
    )
    module = AnsibleModule(
        argument_spec=module_args,
        supports_check_mode=True
    )
    fc_token_manager = FcTokenManager(module)
    fc_token_manager.execute()


def main():
    run_module()


if __name__ == '__main__':
    main()
