#!/usr/bin/env python
# -*- coding:utf-8 -*-
#  Copyright (c) Huawei Technologies Co., Ltd. 2024-2024. All rights reserved.
from http import HTTPStatus
from enum import Enum

from ansible.module_utils.basic import AnsibleModule
from ansible_collections.huawei.fusioncompute.plugins.module_utils.core.fusincompute import logger
from ansible_collections.huawei.fusioncompute.plugins.module_utils.entity.enum.basic import BindAction
from ansible_collections.huawei.fusioncompute.plugins.module_utils.param_validator import hostname_validator_fn
from ansible_collections.huawei.fusioncompute.plugins.module_utils.decorator import action_injector, validator_injector
from ansible_collections.huawei.fusioncompute.plugins.module_utils.basic import FcAttrValidator, FcModuleBase
from ansible_collections.huawei.fusioncompute.plugins.module_utils.core.parameter_normalization import normalize

ANSIBLE_METADATA = {
    'metadata_version': '1.0.0',
    'status': ['preview'],
    'supported_by': 'standard'
}

DOCUMENTATION = '''
---
module: huawei.fusioncompute.fc_vm_pci_device_binding

short_description: Manage FusionCompute VM PCI device binding (bind/unbind)

version_added: "1.0.0"

description:
    - "This module supports binding and unbinding PCI devices for FusionCompute VMs."
    - "Supported actions include: bind and unbind PCI devices to/from a VM."
    - "If 'unbind' action is selected, the format option specifies whether to format the device."

options:
    action:
        description:
            - The action to perform, either 'bind' or 'unbind'.
        required: true
        type: str
        choices: ['bind', 'unbind']

    vm_id:
        description:
            - The ID of the virtual machine (VM) for which the PCI device binding is to be configured.
        required: true
        type: str

    pci_id:
        description:
            - The ID of the PCI device to unbind from the VM.
        required: false
        type: str

    pciUrn:
        description:
            - The URN of the PCI device to bind to the VM when 'bind' action is selected.
        required: false
        type: str

    format:
        description:
            - Whether to format the PCI device when unbinding.
            - This option is only used during the 'unbind' action.
            - If true, the device will be formatted during unbinding; otherwise, it will not.
        required: false
        type: bool
        default: false

    # Parameters inherited from FcModuleBase:
    fc_hostname:
        description:
            - Host name or IP address of the FusionCompute VRM.
        required: true
        type: str

    fc_port:
        description:
            - Port number to connect to the FusionCompute VRM. Default is 7443.
        required: false
        default: 7443
        type: int

    fc_token:
        description:
            - Token for authentication. If provided, the module will skip login and use this token for authentication.
        required: false
        type: str

    fc_username:
        description:
            - Username for FusionCompute authentication.
        required: false
        type: str

    fc_password:
        description:
            - Password for authentication on the FusionCompute VRM.
        required: false
        type: str
        no_log: true
    
    fc_site_id:
        description:
            - Site ID for FusionCompute. If provided, the module will skip retrieving  site id and use this site ID.
        required: false
        type: str

    fc_language:
        description:
            - Language used for communication with FusionCompute VRM. Default is 'en-US'.
        required: false
        default: 'en-US'
        type: str

    fc_verify:
        description:
            - Path to rootCA.crt file for SSL certificate verification. If empty, SSL verification will be disabled.
        required: false
        default: ''
        type: str

author:
    - Huawei Technologies Co., Ltd.
'''

EXAMPLES = '''
# Example 1: Bind a PCI device to a VM
- name: Bind PCI device to VM
  huawei.fusioncompute.fc_vm_pci_device_bind:
    action: bind
    fc_hostname: "192.168.1.100"
    fc_token: "xxxx"
    vm_id: "i-xxxxxxxx"
    pciUrn: "urn:sites:xxxxxx:pcis:x"
    

# Example 2: Unbind a PCI device from a VM
- name: Unbind PCI device from VM
  huawei.fusioncompute.fc_vm_pci_device_bind:
    action: unbind
    fc_hostname: "192.168.1.100"
    fc_token: "xxxx"
    vm_id: "i-xxxxxxxx"
    pci_id: "2"

- name: Debug the result
  debug:
    var: result
'''

RETURN = '''
ret:
    description: The response from the FusionCompute API.
    type: dict
    returned: always
    contains:
        code:
            description: The HTTP status code of the operation.
            type: int
            returned: always
        rsp:
            description: The response body returned by the API.
            type: dict
            returned: always
'''


@action_injector(BindAction)
@validator_injector([FcAttrValidator('fc_hostname', hostname_validator_fn)])
class FcVmPciDeviceBinding(FcModuleBase):
    def __init__(self, module):
        super(FcVmPciDeviceBinding, self).__init__(module)

    def execute(self):
        validate_res = self.validate()
        if validate_res:
            logger.info("fc token manager validate failed %s", validate_res)
            self.module.fail_json(msg=validate_res)
        action: BindAction = self.action
        vm_id = self.params['vm_id']
        pci_id = self.params['pci_id']
        pci_urn = self.params['pciUrn']
        format = self.params['format']

        url = self.client.url_generator.pcis(
            self.client.site_id, vm_id, pci_id, format)
        match action:
            case BindAction.bind:
                ret, rsp = self.client.post(
                    url, {'pciUrn': pci_urn}
                )
            case BindAction.unbind:
                ret, rsp = self.client.delete(url)
        if ret != HTTPStatus.OK:
            self.module.fail_json(
                msg="Couldn't bind vm pci device: ret: %s, rsp: %s" % (ret, rsp.json()))
        else:
            self.module.exit_json(
                changed=True, ret={'code': ret, 'rsp': rsp})


def run_module():
    # define available arguments/parameters a user can pass to the module
    module_args = FcModuleBase.args()
    module_args.update(
        action=dict(type='str', required=True),
        vm_id=dict(type='str', required=True),
        pci_id=dict(type='str', required=False),
        pciUrn=dict(type='str', required=False),
        format=dict(type='bool', required=False),
    )
    module = AnsibleModule(
        argument_spec=module_args,
        supports_check_mode=True
    )
    fc_vm_pci_device_binding = FcVmPciDeviceBinding(module)
    fc_vm_pci_device_binding.execute()


def main():
    run_module()


if __name__ == '__main__':
    main()
