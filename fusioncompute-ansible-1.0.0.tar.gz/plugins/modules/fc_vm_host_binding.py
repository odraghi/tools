#!/usr/bin/env python
# -*- coding:utf-8 -*-
#  Copyright (c) Huawei Technologies Co., Ltd. 2024-2024. All rights reserved.
from http import HTTPStatus
from enum import Enum

from ansible.module_utils.basic import AnsibleModule
from ansible_collections.huawei.fusioncompute.plugins.module_utils.core.fusincompute import logger
from ansible_collections.huawei.fusioncompute.plugins.module_utils.entity.enum.basic import BindAction
from ansible_collections.huawei.fusioncompute.plugins.module_utils.param_validator import hostname_validator_fn
from ansible_collections.huawei.fusioncompute.plugins.module_utils.decorator import action_injector, validator_injector
from ansible_collections.huawei.fusioncompute.plugins.module_utils.basic import FcAttrValidator, FcModuleBase
from ansible_collections.huawei.fusioncompute.plugins.module_utils.core.parameter_normalization import normalize

ANSIBLE_METADATA = {
    'metadata_version': '1.0.0',
    'status': ['preview'],
    'supported_by': 'standard'
}

DOCUMENTATION = '''
---
module: huawei.fusioncompute.fc_vm_host_bind

short_description: Manage host binding for virtual machines (VMs) on Huawei FusionCompute.

version_added: "1.0.0"

description:
    - This module allows you to bind or unbind a virtual machine (VM) to a specific host on Huawei FusionCompute.
    - It supports binding a VM to a host or unbinding it from the current host.

options:
    action:
        description:
            - The action to perform.
            - Supported actions are 'bind' to bind a VM to a host and 'unbind' to unbind it from the current host.
        required: true
        type: str
        choices: ['bind', 'unbind']

    vm_id:
        description:
            - The ID of the virtual machine (VM) to be bound or unbound.
        required: true
        type: str

    urn:
        description:
            - The URN (Uniform Resource Name) of the host to which the VM should be bound.
            - Required when action is 'bind'.
        required: false
        type: str

    # Parameters inherited from FcModuleBase:
    fc_hostname:
        description:
            - Host name or IP address of the FusionCompute VRM.
        required: true
        type: str

    fc_port:
        description:
            - Port number to connect to the FusionCompute VRM. Default is 7443.
        required: false
        default: 7443
        type: int

    fc_token:
        description:
            - Token for authentication. If provided, the module will skip login and use this token for authentication.
        required: false
        type: str

    fc_username:
        description:
            - Username for FusionCompute authentication.
        required: false
        type: str

    fc_password:
        description:
            - Password for authentication on the FusionCompute VRM.
        required: false
        type: str
        no_log: true
    
    fc_site_id:
        description:
            - Site ID for FusionCompute. If provided, the module will skip retrieving  site id and use this site ID.
        required: false
        type: str

    fc_language:
        description:
            - Language used for communication with FusionCompute VRM. Default is 'en-US'.
        required: false
        default: 'en-US'
        type: str

    fc_verify:
        description:
            - Path to rootCA.crt file for SSL certificate verification. If empty, SSL verification will be disabled.
        required: false
        default: ''
        type: str

author:
    - Huawei Technologies Co., Ltd.
'''

EXAMPLES = '''
# Bind a VM to a host
- name: Bind a VM to a host
  huawei.fusioncompute.fc_vm_host_bind:
    action: bind
    fc_hostname: "192.168.1.100"
    fc_token: "xxxx"
    vm_id: "i-xxxxxxxx"
    urn: "urn:sites:xxxxxx:hosts:xxx"
  register: result

# Unbind a VM from its current host
- name: Unbind a VM from its current host
  huawei.fusioncompute.fc_vm_host_bind:
    action: unbind
    fc_hostname: "192.168.1.100"
    fc_token: "xxxx"
    vm_id: "i-xxxxxxxx"
  register: result

- name: Debug the result
  debug:
    var: result
'''

RETURN = '''
ret:
    description: The result of the operation, including HTTP status code and the token if login was successful
    type: dict
    returned: always
    contains:
        code:
            description: The HTTP status code of the operation
            type: int
        fc-token:
            description: The token returned if the action is login
            type: str
'''


@action_injector(BindAction)
@validator_injector([FcAttrValidator('fc_hostname', hostname_validator_fn)])
class FcVmHostBinding(FcModuleBase):
    def __init__(self, module):
        super(FcVmHostBinding, self).__init__(module)

    def execute(self):
        validate_res = self.validate()
        if validate_res:
            logger.info("fc vm host binding validate failed %s", validate_res)
            self.module.fail_json(msg=validate_res)
        action: BindAction = self.action
        vm_id = self.params['vm_id']
        urn = self.params['urn']
        data = {'bindingHostFlag': action == BindAction.bind,
                'urn': urn if action == BindAction.bind else ''}
        url = self.client.url_generator.vm_bind_host(
            self.client.site_id, vm_id)
        ret, rsp = self.client.put(url, normalize(data))
        if ret != HTTPStatus.OK:
            self.module.fail_json(
                msg="Couldn't bind vm to host: ret: %s, rsp: %s" % (ret, rsp.json()))
        else:
            self.module.exit_json(
                changed=True, ret={'code': ret, 'rsp': rsp})


def run_module():
    # define available arguments/parameters a user can pass to the module
    module_args = FcModuleBase.args()
    module_args.update(
        action=dict(type='str', required=True),
        vm_id=dict(type='str', required=True),
        urn=dict(type='str', required=False),
    )
    module = AnsibleModule(
        argument_spec=module_args,
        supports_check_mode=True
    )
    fc_vm_host_bind = FcVmHostBinding(module)
    fc_vm_host_bind.execute()


def main():
    run_module()


if __name__ == '__main__':
    main()
